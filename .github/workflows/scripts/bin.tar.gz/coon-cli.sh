#!/bin/sh

# General
CUR_DIR=$(cd "$(dirname "$0" 2>/dev/null)";pwd)
LOCAL_ROOT="/usr/local"
LOCAL_LIB_ROOT="$LOCAL_ROOT/lib"
APPLICATION_ROOT="/usr/share/applications"
INITD_ROOT="/etc/init.d"
SYSCTL_CONF="/etc/sysctl.conf"
SYSCTL_ROOT="/etc/sysctl.d"
LD_SO_CONF="/etc/ld.so.conf"
LD_SO_CONF_D="/etc/ld.so.conf.d"
SUPERVISOR_CONF_ROOT="/etc/supervisor/conf.d"
SUPERVISOR_CONF_EXT="conf"
DATA_ROOT="/data"
DOWNLOAD_ROOT="$DATA_ROOT/downloads"
APP_VERSION="1.20190814.0000"
APP_NAME_FULL="Coon Command-Line Interface for Linux / Unix"
APP_NAME="coon-cli"
APP_URL="coonhub.com/$APP_NAME/"
APP_BIN_URL="https://x.coonhub.com/coon-cli.sh"
APP_BIN_PATH="/usr/sbin/$APP_NAME"
APP_ROOT="$LOCAL_ROOT/$APP_NAME"
APP_PROFILE="/etc/.$APP_NAME"
APP_CACHE_DIR="/tmp/.${APP_NAME}"

# Swap
SWAP_FILE_SIZE_DEFAULT="0"
SWAP_FILE="/swapfile"

# User
USER_NAME="root"
USER_HOME_PATH="/root"
USER_PWD_DEFAULT="_123456_"

# Timezone
TIMEZONE="${TIMEZONE:-Asia/Shanghai}"

# Nginx
WWW_ROOT="${WWW_ROOT:-/www}"
HTML_ROOT="$WWW_ROOT/html"
NGINX_CONF_ROOT="/etc/nginx"
NGINX_ADDON="$NGINX_CONF_ROOT/sites-addon"
NGINX_SITES="$NGINX_CONF_ROOT/sites-available"
NGINX_APP_CACHE_DIR="$APP_CACHE_DIR/nginx"
NGINX_SOURCE_MODULE_ROOT="$NGINX_APP_CACHE_DIR/module"
NGINX_SOURCE_DEPEND_ROOT="$NGINX_APP_CACHE_DIR/depend"
NGINX_PREFIX="/usr/share/nginx"
# OpenResty
OPENRESTY_PREFIX="/usr/share/openresty"

# PHP Options
PHP_MEMORY_LIMIT="${PHP_MEMORY_LIMIT:-512M}"
PHP_UPLOAD_MAX_FILESIZE="${PHP_UPLOAD_MAX_FILESIZE:-50M}"
PHP_MAX_FILE_UPLOADS="200"
PHP_MAX_EXECUTION_TIME="600"
PHP_POST_MAX_SIZE="100M"
PHP_PHPMYADMIN_ROOT="$WWW_ROOT/phpmyadmin"

# MySQL
MYSQL_PWD_DEFAULT="root"

# VNC Options
VNC_DISPLAY_DEPTH="16"
VNC_PORT=${VNC_PORT:-5901}
VNC_HTTP_PORT="6081"
VNC_NOVNC_ROOT="/usr/share/noVNC"

# FRP
FRP_ROOT="$LOCAL_ROOT/frp"
FRP_CONF_ROOT="/etc/frp"

#NFS
NFS_CONF="/etc/exports"

# POSTFIX
POSTFIX_CONF_ROOT="/etc/postfix"
POSTFIX_CONF_MAIN="$POSTFIX_CONF_ROOT/main.cf"

# ARIA2
ARIA2_CONF_ROOT="/etc/aria2"
ARIA2_CONF="$ARIA2_CONF_ROOT/aria2.conf"
ARIA2_SESSION="$ARIA2_CONF_ROOT/aria2.session"
ARIA2_WEB_ROOT="$WWW_ROOT/aria2"

# LUAJIT
LUAJIT_ROOT="$LOCAL_ROOT/luajit"

REGULAR_URL="https?://[-+=~_.:/!@#\$%&a-zA-Z0-9]+"
SYMBOL_SELECTED="<-"
DELIMITER="::::"

lang() {
	lang_en
}

lang_en() {
	LANG_SELECT_DEFAULT="# Press "Enter" to select \"$SYMBOL_SELECTED\""
	LANG_NOT_SUPPORT_OS="Only support for Ubuntu / Debian / Mint / Alpine / CentOS"
	LANG_NOT_SUPPORT_FUNCTION="This function does not support ${OS_RELEASE} ${OS_VERSION} ($OS_ARCH)"
	LANG_NOT_DETECT_ARCH="Could not detect OS architecture"
	LANG_NOT_FOUND_LATEST_KERNEL="Could not found last kernel realse"
	LANG_CONFIRM_UPDATE_KERNEL="Are you want to kernel now?"
	LANG_UPDATEING_PACKAGE_LIST="Updating packages list"
	LANG_FAIL_UPDATE_PACKAGE_LIST="Fail to update packages list"
	LANG_INSTALLING="Installing"
	LANG_INITIALIZING_MODULE="Initializing module"
	LANG_FAIL_INSTALL_PACKAGE="Fail to install packages"
	LANG_USER_PASSWORD="User Password"
	LANG_PASSWORD_FORMAT="6 characters min and 16 characters max"
	LANG_SKIP="Skip"
	LANG_NOT_VALID_PASSWORD="Not a valid password!"
	LANG_CREATE_NEW_USER="Create A User"
	LANG_USER_NAME_FORMAT_MUST_BE="3 chars min and 32 chars max (a-z_-)"
	LANG_USER_NAME="User Name"
	LANG_NOT_VALID_USER_NAME="Not a valid user name!"
	LANG_PORT="Port"
	LANG_NOT_VALID_PORT="Not a valid port!"
	LANG_NOT_VALID_IP="Not a valid IP address"
	LANG_KERNEL_IS_UP_TO_DATE="Kernel version is already up to date"
	LANG_KERNEL_VERSION="Kernel Version"
	LANG_REQUIRE_MIN_VERSION="require min kernel version"
	LANG_OS_REQUIRE="Require OS"
	LANG_ALREADY_ENABLED="is already enabled"
	LANG_ENABLE="Enable"
	LANG_DISABLE="Disable"
	LANG_BBR_DEC="Google TCP BBR congestion control algorithm"
	LANG_TFO_DEC="TCP Fast Open"
	LANG_HELP_KERNEL_UPDATE_TO_LATEST="Update kernel to latest version"
	LANG_HELP_THIS_UPDATE="Update $APP_NAME"
	LANG_HELP_THIS_INSTALL="Install $APP_NAME to $APP_BIN_PATH"
	LANG_THIS_UPDATE_SUCCESS="$APP_NAME has been updated"
	LANG_THIS_UPDATE_FAIL="$APP_NAME fail to update"
	LANG_THIS_INSTALL_SUCCESS="$APP_NAME success to install"
	LANG_THIS_INSTALL_FAIL="$APP_NAME failed to install"
	LANG_CONFIRM_REBOOT_NOW="Must reboot to take effect. Reboot now"
	LANG_PASSWORD="Password"
	LANG_UPDATED_BT_TRACKER="Updated <%1%> bt-tracker list"
	LANG_DOWNLOADING="Downloading"
	LANG_FAIL_TO_DOWNLOAD="Fail to download"
	LANG_UPDATED="Updated"
	LANG_DISPLAY_RESOLUTION="Display Rsolution"
	LANG_NOT_VALID_RSOLUTION="Not a valid rsolution"
	LANG_VNC_PASSWORD_ALREADY_SET="VNC Password already set"
	LANG_OR="or"
	LANG_NOT_GET_PHP_VERSION="Could not get php version"
	LANG_CAN_NOT_GET="Can not get"
	LANG_VERSION="version"
	LANG_ENABLED="Enabled"
	LANG_DISABLED="Disabled"
	LANG_MUST_RUN_WITH_ROOT="You have run with root user"
	LANG_NOT_FOUND_FILE="Not find file"
	LANG_SUCCESS_TO_ENABLE="Success to enable"
	LANG_FAIL_TO_ENABLE="Fail to enable"
	LANG_SUCCESS_TO_DISABLE="Success to disable"
	LANG_FAIL_TO_DISABLE="Fail to disable"
	LANG_UP_TIME="Up Time"
	LANG_LOAD_AVERAGE="Load Average"
	LANG_SERVER_TIME="Server Time"
	LANG_OS_VERSION="OS Version"
	LANG_OS_BASED_ON="OS Based On"
	LANG_MEMORY_USED="Memory Used"
	LANG_DISK_USED="Disk Used"
	LANG_SWAP_USED="Used Swap"
	LANG_VIRT_TYPE="Virtualization"
	LANG_CPU="CPU"
	LANG_GEOIP_UPDATE_HELP="Update / Install GeoIP Database"
	LANG_GEOIP_QUERY_HELP="Query a IP or External IP"
	LANG_HAVE_TO_INSTALL_APP_FIRST="Have to install <%1%> first."
	LANG_DATABASE="Database"
	LANG_FAIL_TO_GET="Fail to get"
	LANG_CHECKING="Checking"
	LANG_HAS_BEEN_USING="<%1%> has been using."
	LANG_FOUND_RESULT="Found <%1%> results."
	LANG_OUTPUT_AS_JSON="output as JSON format"
	LANG_INSTALLED="Installed"
	LANG_STABLE="Stable"
	LANG_MAINLINE="Mainline"
	LANG_MD5_WAS_NOT_MATCH="MD5 was not match."
	LANG_ALREADY_UP_TO_DATE="Current <%1%> version was already up to date."
	LANG_HAS_BEEN_UPDATED="<%1%> has been updated."
	LANG_ALREADY_INSTALLED="<%1%> was already installed."
	LANG_NOT_FIND_VERSION="Could not find version"
	# FRP
	LANG_FRP_HELP_CREATE="create a FRP client"
	LANG_FRP_HELP_LOCAL="client local port"
	LANG_FRP_HELP_EXPOSE="server side expose port (default: local port)"
	LANG_FRP_HELP_TYPE="protocol type (default: tcp)"
	LANG_FRP_HELP_SERVER="create a FRP server"
	LANG_FRP_HELP_HOST="FRP server host (default port: 7000)"
	LANG_FRP_HELP_REMOVE="remove client or server"
	LANG_FRP_HELP_LIST="list client / server"
	LANG_FRP_HELP_UI="step by step with ui"
	LANG_FRP_HELP_CREATE_CLIENT="Create FRP Client"
	LANG_FRP_HELP_CREATE_SERVER="Create FRP Server"
	# INSTALL
	LANG_INSTALL_ORIGIN="Install package directly without preset"
	# INFO
	LANG_INFO_FIELD="Show a field info"
	LANG_INFO_ALL="Show all info"
	# SPEEDTEST
	LANG_SPEEDTEST_TEST="test network speed"
	LANG_SPEEDTEST_LIST="list speedtest servers"
	LANG_SPEEDTEST_MATCH_COUNTRY="match country name"
	LANG_SPEEDTEST_MATCH_CITY="match city name"
	LANG_SPEEDTEST_MATCH_ISP="match ISP name"
	LANG_SPEEDTEST_MATCH_ID="match server id"
	LANG_SPEEDTEST_DOWNLOAD_ONLY="test download speed only"
	LANG_SPEEDTEST_UPLOAD_ONLY="test upload speed only"
	LANG_SPEEDTEST_SINGLE="test with single connection"
	LANG_SPEEDTEST_HTTPS="Use HTTPS instead of HTTP"
	# DISKTEST
	LANG_DISKTEST_SIZE="File size for writing with dd command"
	LANG_DISKTEST_MEMORY="Write to memory instead (/dev/shm)"
	# BUILD
	LANG_BUILD_APP_FIRST="Please build <%1%> first."
	# RANDOM
	LANG_RANDOM_LENGTH="String length (>=1)"
	LANG_RANDOM_UPPER="String with Upper Case"
	LANG_RANDOM_LOWER="String with Lower Case"
	LANG_RANDOM_SYMBOL="String with Symbol"
	LANG_RANDOM_DIGIT="String with Digit"
	LANG_RANDOM_ONLY_WITH="Only with your input"
	# REPO
	LANG_FAIL_INSTALL_REPO="Fail to install repo"
	LANG_SUCCESS_TO_REMOTE_REPO="Success to remove repo"
	LANG_FAIL_TO_REMOTE_REPO="Fail to remove repo"
}

string_with_args() {
	REPLACE_STRING="$1"
	[ "$#" -gt 1 ] || return 1
	i=1
	while true
	do
		[ "$i" = "$#" ] && break
		REPLACE_STRING=$(echo "$REPLACE_STRING" | sed -E "s/<%$i%>/$(eval "echo \$$((i+1))")/g")
		i=$((i+1))
	done
	echo "$REPLACE_STRING"
	return 0
}

string_by_columns() {
	PRINT_DELIMS="$2"
	PRINT_LENGTH="$3"
	PRINT_ALIGN="$4"
	HEADER=$(echo "$1" | awk -F"${PRINT_DELIMS:-( |	)}" "
	NF>1 {
		for(i=1;i<=NF;i++){w[i] = (length(\$i) > w[i] ? length(\$i) : w[i]); COLUMNS=NF>=i?NF:i}
	}
	END{
		for(i=1;i<=COLUMNS;i++){HEAD=i>1?HEAD\"${PRINT_DELIMS:-	}\"w[i]:w[i]} print HEAD
	}")
	[ -z "$HEADER" ] && echo "$1" && return 1
	PRINT_COLUMNS=$(cat <<-EOF
	$HEADER
	$1
	EOF
	)
	echo "$PRINT_COLUMNS" | awk -F"${PRINT_DELIMS:-( |	)}" "
	BEGIN{
		ALIGN=\"$PRINT_ALIGN\"
		(ALIGN!=\"lr\" || ALIGN!=\"rr\" || ALIGN!=\"rl\") && ALIGN=\"ll\"
		ALIGN=\"ll\" && A_F=\"l\" && A_O=\"l\"
		ALIGN=\"lr\" && A_F=\"l\" && A_O=\"r\"
		ALIGN=\"rr\" && A_F=\"r\" && A_O=\"r\"
		ALIGN=\"rl\" && A_F=\"r\" && A_O=\"l\"
		LENGTH=\"$PRINT_LENGTH\"
		INDENT = LENGTH ~ /^\+[1-9][0-9]*$/ ? LENGTH : 0
	}
	NR==1{
		for(i=1;i<=NF;i++){
			w[i]=i==NF?0:(LENGTH~/^[1-9][0-9]*\$/?LENGTH:\$i)
		}
	}
	NR>1{
		LINE=\"\"
		for(i=1;i<=NF;i++){
			ALIGN=i==1?A_F:A_O
			SPACE=\"\"
			for(j=1;j<=w[i]-length(\$i)+INDENT;j++){SPACE=j>1?SPACE\" \":\" \"}
			FIELD=ALIGN==\"r\"?SPACE \$i:\$i SPACE
			LINE=i>1?LINE FIELD:FIELD
		}
		print LINE
	}"
	# awk ... printf("%*s",24,$i)}'
	return 0
}

multiple_threads() {
	THREADS=${THREADS:-10}
	PIDS=""
	while read INDEX
	do
		echo "[INFO] $INDEX" >&2
		while true
		do
			[ -z "$PIDS" ] && PID_COUNT="0" || PID_COUNT=$(echo "$PIDS" | tr '|' '\n' | wc -l)
			if [ "$PID_COUNT" -ge $((THREADS-1)) ]; then
				PIDS=$(ps aux | awk "\$2~/^($PIDS)\$/{print \$2}" | tr '\n' '|' | awk '{gsub(/\|$/,"",$0); print $0}')
			else
				# === Function ===
				func "$INDEX" &
				PID=${!}
				PIDS="$([ -z "$PIDS" ] || echo "${PIDS}|")${PID}"
				break
			fi
		done
	done <<-EOF
	$(seq 10)
	EOF
	while true; do [ -z "$(ps aux | awk "\$2~/^($PIDS)\$/{print \$2}")" ] && break; done
}

define_pkg() {
	PKG_VNC="x11vnc xvfb"
	PKG_FONT="fonts-wqy-microhei"
	PKG_INPUT="dbus-x11"
	PKG_BROWSER="firefox"
	PKG_ARCHIVER="xarchiver"
	PKG_XFCE="xfce4 xfce4-terminal"
	PKG_LXDE="lxde"
	# PKG_LXQT="lxqt pcmanfm-qt openbox obconf-qt compton compton-conf"
	PKG_LXQT="lxqt"
	PKG_NGINX="nginx"
	PKG_PHP="php-fpm php-cli php-common php-curl php-json php-mbstring php-gd php-mysql php-pgsql php-sqlite3 php-redis php-odbc php-zip php-bz2 php-mcrypt php-intl php-sybase php-pspell php-bcmath php-interbase php-recode php-readline php-gmp php-pear php-xdebug php-all-dev php-xml php-xmlrpc php-cgi php-imap php-soap php-ldap php-fxsl php-opcache php-apcu"
	PKG_MYSQL="mysql-server mysql-client"
	PKG_NODEJS="nodejs"
	PKG_MONGODB="mongodb-org"
	PKG_RETHINKDB="rethinkdb"
	PKG_BASE="software-properties-common psmisc bc jq uuid-runtime curl axel git zip unzip unrar lbzip2 supervisor screen tmux htop cpulimit openssh-server pwgen sudo vim net-tools rsync imagemagick"
	PKG_BUILD="binutils gcc gcc-c++ cmake"
	PKG_XSLT_LIB="libxslt-devel"
	PKG_XML2_LIB="libxml2-devel"
	PKG_UUID_LIB="libuuid-devel "
	PKG_PCRE_LIB="pcre-devel"
	PKG_ZLIB_LIB="zlib-devel"
	PKG_SSL_LIB="openssl-devel"
	PKG_GD_LIB="gd-devel"
	PKG_TOOL_LIB="libtool"
	PKG_GEOIP_LIB="geoip-devel"
	PKG_PAM_LIB="pam-devel"
	PKG_SASS_LIB="libsass-devel"
	PKG_PERL_LIB="perl-libs"
	PKG_PQ_LIB="postgresql-devel"
	PKG_AVFORMAT_LIB="libavformat-devel"
	PKG_SWSCALE_LIB="libswscale-devel"
	PKG_AVFILTER_LIB="libavfilter-devel"
	PKG_YAJL_LIB="libyajl-devel"
	PKG_LDAP_LIB="openldap-devel"
	PKG_MAKE_AUTOCONF="make autoconf"
	PKG_NFS="nfs-utils"
	PKG_IPERF="iperf3"
	PKG_WINE="winehq-stable"
	PKG_WINE_EXTRA="winetricks"
	PKG_DOCKER="docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin"
	PKG_MMDB="mmdb-bin"
	case "$OS_BASE" in
		"debian")
			[ "$HOST_IS_VPS" = "1" ] || PKG_LXQT="$PKG_LXQT connman-"
			PKG_BUILD="make build-essential"
			PKG_UUID_LIB="uuid-dev"
			PKG_PCRE_LIB="libpcre3-dev"
			PKG_ZLIB_LIB="zlib1g-dev"
			PKG_SSL_LIB="libssl-dev"
			PKG_GD_LIB2="libgd2-xpm-dev"
			PKG_GD_LIB="libgd-dev"
			PKG_GEOIP_LIB="libgeoip-dev"
			# PKG_PAM_LIB="libpam0g-dev"
			PKG_PAM_LIB="libpam-dev"
			PKG_SASS_LIB="libsass-dev"
			PKG_PERL_LIB="libperl-dev"
			PKG_PQ_LIB="libpq-dev"
			PKG_AVFORMAT_LIB="libavformat-dev"
			PKG_SWSCALE_LIB="libswscale-dev"
			PKG_AVFILTER_LIB="libavfilter-dev"
			PKG_YAJL_LIB="libyajl-dev"
			PKG_LDAP_LIB="libldap2-dev"
			PKG_NGINX="nginx-extras"
			PKG_COMPILE="$PKG_BUILD libncurses5-dev autotools-dev libltdl-dev libtool $PKG_MAKE_AUTOCONF autopoint automake pkgconf unzip python3 $PKG_SSL_LIB"
			PKG_XSLT_LIB="libxslt1-dev"
			PKG_XML2_LIB="libxml2-dev"
			PKG_NFS="nfs-kernel-server"
			;;
		"rhel")
			PKG_VNC="x11vnc Xvfb"
			PKG_NGINX="nginx-all-modules"
			PKG_COMPILE="$PKG_BUILD $PKG_ZLIB_LIB bzip2 gawk gettext flex ncurses-devel $PKG_MAKE_AUTOCONF patch unzip perl-ExtUtils-MakeMaker glibc glibc-devel glibc-static ncurses-libs sed sdcc intltool sharutils bison wget git-core $PKG_SSL_LIB xz"
			;;
		"arch")
			PKG_VNC="x11vnc xorg-server-xvfb"
			PKG_MMDB="mmdblookup"
			;;
		"alpine")
			PKG_SSL_LIB="openssl"
			PKG_COMPILE="$PKG_BUILD asciidoc bash bc bzip2 cdrkit coreutils diffutils findutils flex g++ gawk gcc gettext git grep intltool libxslt linux-headers $PKG_MAKE_AUTOCONF ncurses-dev patch perl python2-dev tar unzip util-linux wget zlib-dev $PKG_SSL_LIB"
			;;
	esac
	PKG_NGINX_MODULE_VIDEO_THUMB="$PKG_AVFORMAT_LIB $PKG_SWSCALE_LIB $PKG_AVFILTER_LIB"
}

init_config() {
	[ -f "$APP_PROFILE" ] && {
		while read CONFIG
		do
			[ -z "$CONFIG" ] || eval "$CONFIG"
		done <<-EOF
		$(cat "$APP_PROFILE" | grep -E "^[a-zA-Z0-9]+ *=.*")
		EOF
	}
}

err_exit() {
	[ -z "$1" ] || log_err "$1"
	exit
}

log_err() {
	echo "[ERR] $1"
}

log_success() {
	echo "[SUCCESS] $1"
}

log_warn() {
	echo "[WARN] $1"
}

log_info() {
	echo "[INFO] $1"
}

log_debug() {
	echo "[DEBUG] $1"
}

log_date() {
	echo "[$(date "+%Y/%m/%d %H:%M.%S")] $1"
}

args_match() {
	ARGS_MATCH_VALUE=""
	ARGS_MATCH_COUNT=0
	for ARGS_MATCH_REGEX; do true; done
	while [ $# -gt 1 ]
	do
		echo "$1-" | awk '{gsub(/-$/,"",$0); print $0}' | grep -Eq "^($ARGS_MATCH_REGEX)=?" && {
			ARGS_MATCH_COUNT=$((ARGS_MATCH_COUNT+1))
			if echo "$1" | grep -Eq "^($ARGS_MATCH_REGEX).+"; then
				_MATCH_VALUE_=$(echo "$1" | sed -E "s/^$ARGS_MATCH_REGEX=?//g")
				[ "$ARGS_MATCH_COUNT" -gt 1 ] && ARGS_MATCH_VALUE=$ARGS_MATCH_VALUE"$DELIMITER"${_MATCH_VALUE_} || ARGS_MATCH_VALUE=${_MATCH_VALUE_}
			else
				[ "$#" -gt 2 ] && {
					echo "$2" | grep -Eq "^[-]{1,2}.+" || {
						[ "$ARGS_MATCH_COUNT" -gt 1 ] && ARGS_MATCH_VALUE=$ARGS_MATCH_VALUE"$DELIMITER"$2 || ARGS_MATCH_VALUE=$2
						shift
					}
				}
			fi
		}
		shift
	done
	[ "$ARGS_MATCH_COUNT" -gt 0 ] && return 0
	return 1
}

is_ip() {
	echo "$1" | grep -Eq '^[0-9]{1,3}(\.[0-9]{1,3}){3}$' && return 0
	return 1
}

is_domain() {
	echo "$1" | grep -Eq '^([-a-zA-Z0-9.]+\.)+[a-zA-Z]{2,6}$' && return 0
	return 1
}

is_root() {
	_UID_=$(id | grep -Eo 'uid=[0-9]+' | awk -F'=' '{print $2}')
	[ "$_UID_" = "0" ] || err_exit "$LANG_MUST_RUN_WITH_ROOT"
	return 0
}

is_port() {
	echo "$1" | grep -Eq '^[1-9][0-9]{1,4}$' || return 1
	[ "$1" -gt 65535 ] && return 1
	return 0
}

is_empty_dir() {
	[ -z "$(ls "$1" 2>/dev/null)" ] && return 0
	return 1
}

is_musl() {
	ldd /bin/ls | grep -q 'musl'
	return $?
}

has_package() {
	[ -z "$1" ] && return 1
	HAS_BIN_NAME=$(cat <<-EOF | grep -E "^${1}:" | head -n1 | awk -F":" '{print $2}'
	openssh-server:sshd
	supervisor:supervisord
	frp:frpc
	gnupg-agent:gpg-agent
	aria2:aria2c
	xvfb:Xvfb
	dnsutils:dig
	libnss3-tools:certutil
	python3-pip:pip3
	netcat:nc
	psmisc:killall
	nodejs:node
	golang:go
	yum-utils:yum-config-manager
	imagemagick:identify
	$PKG_MMDB:mmdblookup
	$PKG_TOOL_LIB:libtoolize
	EOF
	)
	[ -z "$HAS_BIN_NAME" ] && HAS_BIN_NAME="$1"
	HAS_BIN_PATH=$(which $HAS_BIN_NAME)
	[ -z "$(which $HAS_BIN_NAME 2>/dev/null)" ] || return 0
	log_err "$(string_with_args "$LANG_HAVE_TO_INSTALL_APP_FIRST" "$1")"
	return 1
}

file_remove_lines() {
	# FilePath, BeginingString, EndindString
	[ -f "$1" ] || return 1
	[ -z "$2" ] && return 1
	RM_LINES_BEGIN=$(grep -n "^$2\$" "$1" | awk -F':' '{print $1}')
	[ -z "$RM_LINES_BEGIN" ] && return 1
	if [ -z "$3" ]; then
		while read LINE_NO_BEGIN
		do
			[ "$LINE_NO_BEGIN" -gt 0 ] && sed -Ei "${LINE_NO_BEGIN}d" "$1"
		done <<-EOF
		$RM_LINES_BEGIN
		EOF
	else
		RM_LINES_END=$(grep -n "^$3\$" "$1" | awk -F':' '{print $1}')
		while read LINE_NO_BEGIN
		do
			[ "$LINE_NO_BEGIN" -gt 0 ] && {
				while read LINE_NO_END
				do
					[ "$LINE_NO_END" -gt 0 -a "$LINE_NO_END" -gt "$LINE_NO_BEGIN" ] && sed -Ei "${LINE_NO_BEGIN},${LINE_NO_END}d" "$1"
				done <<-EOF
				$RM_LINES_END
				EOF
			}
		done <<-EOF
		$(echo "$RM_LINES_BEGIN")
		EOF
	fi
}

c_curl() {
	require_pkg "curl" >/dev/null 2>/dev/null || return 1
	check_cache_root || return 1
	curl "$@" && return 0
	return 1
}

c_aria2() {
	require_pkg "aria2" >/dev/null 2>/dev/null || return 1
	check_cache_root || return 1
	aria2c "$@" && return 0
	return 1
}

c_dig() {
	require_pkg "dnsutils" >/dev/null 2>/dev/null || return 1
	dig "$@" && return 0
	return 1
}

c_unzip() {
	require_pkg "unzip" >/dev/null 2>/dev/null || return 1
	unzip "$@" && return 0
	return 1
}

c_gzip() {
	require_pkg "gzip" >/dev/null 2>/dev/null || return 1
	gzip "$@" && return 0
	return 1
}

c_git() {
	require_pkg "git" >/dev/null 2>/dev/null || return 1
	git "$@" && return 0
	return 1
}

c_nc() {
	require_pkg "netcat" >/dev/null 2>/dev/null || return 1
	nc "$@" && return 0
	return 1
}

check_port_status() {
	get_address "$1" || return 1
	[ -z "$ADDRESS_PORT" ] && return 1
	TO_CHECK="$([ -z "$ADDRESS_IP" ] || echo "${ADDRESS_IP}:")$ADDRESS_PORT"
	echo "- $LANG_CHECKING $TO_CHECK ..."
	curl_status -s --max-time 5 "$TO_CHECK"
	return $CURL_STATUS_CODE
}

check_cache_root() {
	[ -d "$APP_CACHE_DIR" ] || {
		mkdir -p "$APP_CACHE_DIR" || return 1
	}
	return 0
}

has_lib() {
	REQUIRE_LIB_INSTALL=""
	while true
	do
		[ "$#" -lt 1 ] && break
		CUR_LIB=$(echo "$1" | awk '{gsub(/\-dev.*/,"",$0); print $0}')
		ldconfig -p | awk '{print $1}' | grep -qi "^$CUR_LIB[-.]" || {
			REQUIRE_LIB_INSTALL="$([ -z "$REQUIRE_LIB_INSTALL" ] || echo "$REQUIRE_LIB_INSTALL ")$CUR_LIB"
		}
		shift
	done
	[ -z "$REQUIRE_LIB_INSTALL" ] && return 0
	log_warn "$(string_with_args "$LANG_HAVE_TO_INSTALL_APP_FIRST" "$REQUIRE_LIB_INSTALL")"
	return 1
}

has_header() {
	FOUND_HEADER=0
	while true
	do
		[ "$#" -lt 1 ] && break
		[ -f "/usr/include/$1" ] && FOUND_HEADER="1" && break
		[ -f "$LOCAL_ROOT/include/$1" ] && FOUND_HEADER="1" && break
		shift
	done
	[ "$FOUND_HEADER" = "1" ] && return 0
	return 1
}

has_os_version() {
	[ "$(echo $1 | grep -Eo "[-_a-zA-Z0-9]+:[0-9.]+" | grep -E "^${OS_TYPE}:" | awk -v OS_VERSION="$OS_VERSION" -F':' '{if (OS_VERSION>=$2) print "1"}')" = "1" ] && return 0
	return 1
}

require_kernel_version() {
	[ -z "$1" ] && return 1
	eval $(echo "$1"|awk -F'.' '{print "KERNEL_REQUIRE_A="$1"; KERNEL_REQUIRE_B="$2}')
	eval $(echo "$KERNEL_VERSION_INSTALLED"|awk -F'.' '{print "KERNEL_INSTALLED_A="$1"; KERNEL_INSTALLED_B="$2}')
	[ "$KERNEL_INSTALLED_A" -gt "$KERNEL_REQUIRE_A" ] && return 0
	[ "$KERNEL_INSTALLED_A" -ge "$KERNEL_REQUIRE_A" -a "$KERNEL_INSTALLED_B" -ge "$KERNEL_REQUIRE_B" ] && return 0
	return 1
}

require_pkg_compile() {
	grep -Eq "^PKG_COMPILED_TIME=" "$APP_PROFILE" 2>/dev/null && return 0
	pkg_install "$PKG_COMPILE" && {
		sed -Ei "/^PKG_COMPILED_TIME=/d" "$APP_PROFILE" 2>/dev/null
		echo "PKG_COMPILED_TIME=$(date +%s)" >> "$APP_PROFILE"
		return 0
	}
	return 1
}

require_pkg() {
	PKG_INSTALL_ALL=""
	while read PKG_REQUIRE
	do
		[ -z "$PKG_REQUIRE" ] || {
			has_package "$PKG_REQUIRE" || PKG_INSTALL_ALL="$([ -z "$PKG_INSTALL_ALL" ] || echo "${PKG_INSTALL_ALL} ")$PKG_REQUIRE"
		}
	done<<-EOF
	$(echo "$*"|awk '{for (i=1;i<=NF;i++) print $i}')
	EOF
	[ -z "$PKG_INSTALL_ALL" ] || {
		pkg_install "$PKG_INSTALL_ALL" || return 1
	}
	return 0
}

get_basename() {
	echo "$1" | awk -F'(/|\\\\)' '{print $NF}'
}

get_dir_path() {
	[ -z "$1" ] && return 1
	if [ -d "$1" ]; then
		echo "$1" | awk '{gsub(/\/+$/,"",$0); print $0}'
	else
		echo "$1" | sed -E 's/\/+[^\/]*$//'
	fi
	return 0
}

get_address() {
	ADDRESS_IP=""
	ADDRESS_PORT=""
	if echo "$1" | grep -q ":"; then
		ADDRESS_IP=$(echo "$1" | grep -Eo ".*:" | tr -d ":")
		ADDRESS_PORT=$(echo "$1" | awk -F':' '{print $NF}')
		[ -z "$ADDRESS_IP" -a -z "$ADDRESS_PORT" ] && return 1
		[ -z "$ADDRESS_IP" ] || {
			is_ip "$ADDRESS_IP" || is_domain "$ADDRESS_IP" || return 1
		}
		[ -z "$ADDRESS_PORT" ] || {
			is_port "$ADDRESS_PORT" || return 1
		}
		return 0
	else
		if is_port "$1"; then
			ADDRESS_PORT="$1" && return 0
		elif is_ip "$1"; then
			ADDRESS_IP="$1" && return 0
		elif is_domain "$1"; then
			ADDRESS_IP="$1" && return 0
		fi
	fi
	return 1
}

get_pkg_arch() {
	PKG_ARCH=$(echo "$@" | tr " " "\n" | awk -v"ARCH=$OS_ARCH" -F",|:" '{for (i=1;i<NF;i++) {if ($i==ARCH) {print $NF}}}')
	[ -z "$PKG_ARCH" ] && echo "$OS_ARCH" && return 1
	echo "$PKG_ARCH" && return 0
}

get_home_path() {
	CUR_USER=${1:-$USER}
	[ -z "$CUR_USER" ] && CUR_USER="root"
	USER_NAME="$CUR_USER"
	USER_HOME_PATH=$(getent passwd $1 | awk -F':' '{print $6}')
	[ -z "$USER_HOME_PATH" ] || return 0
	[ "$CUR_USER" = "root" ] || {
		USER_HOME_PATH="/home/$CUR_USER" && return 0
	}
	USER_HOME_PATH="/root" && USER_NAME="root" && return 0
}

get_www_user() {
	if grep -Eq "^www-data:" "/etc/shadow" 2>/dev/null; then
		WWW_USER="www-data"
	elif grep -Eq "^nginx:" "/etc/shadow" 2>/dev/null; then
		WWW_USER="nginx"
	else
		WWW_USER="root"
	fi
}

get_virt_type() {
	has_package "virt-what" || return 1
	virt-what
}

get_displays() {
	PID_ALL=$(ps aux || ps)
	DISPLAYS=$(while read PID
	do
		[ -z "$PID" ] || {
			cat /proc/$PID/environ 2>/dev/null | tr '\0' '\n' | grep '^DISPLAY=:'
		}
	done<<-EOF | grep -o ':[0-9]*' | sort -u
	$(echo "$PID_ALL" | awk '{if(NR==1){for (i=1;i<=NF;i++){if ($i=="PID") {PID_F=i}}}; print $PID_F}')
	EOF
	)
	[ -z "$DISPLAYS" ] && return 1
	return 0
}

get_os_info() {
	# Get Arch
	OS_ARCH=$(uname -m | sed -e 's/i.86/i386/' | sed -e 's/arm.*/arm/')
	[ -z "$OS_ARCH" ] && err_exit "$LANG_NOT_DETECT_ARCH"
	# Get kernel version
	KERNEL_VERSION_INSTALLED=$(grep -Eoi "Linux\sversion\s[1-9](\.[0-9]+)+" "/proc/version"|grep -Eo "[1-9](\.[0-9]+)+")
	# Get OS info
	[ -f "/etc/os-release" ] && {
		eval "$(sh -c '. /etc/os-release; \
			[ -z "$ID_LIKE" ] || echo "OS_BASE=\"$ID_LIKE\"";
			[ -z "$ID" ] || echo "OS_RELEASE=\"$ID\"";
			[ -z "$PRETTY_NAME" ] && echo "OS_NAME=\"$NAME\"" || echo "OS_NAME=\"$PRETTY_NAME\"";
			[ -z "$VERSION_ID" ] && echo "OS_VERSION=\"$VERSION\"" || echo "OS_VERSION=\"$VERSION_ID\"";
			[ -z "$VERSION_CODENAME" ] && echo "OS_CODENAME=\"$VARIANT_ID\"" || echo "OS_CODENAME=\"$VERSION_CODENAME\"";
			[ -z "$PLATFORM_ID" ] || echo "OS_PLATFORM=\"$PLATFORM_ID\"";
		')"
	}
	[ -x "$(which lsb_release 2>/dev/null)" ] && {
		[ -z "$OS_VERSION" ] && OS_VERSION=$(lsb_release -s --release | tr '[[:upper:]]' '[[:lower:]]')
		[ -z "$OS_CODENAME" ] && OS_CODENAME=$(lsb_release -s --codename | tr '[[:upper:]]' '[[:lower:]]')
	}
	[ -z "$OS_BASE" ] && {
		echo "$OS_RELEASE" | grep -Eq '^(debian|arch|alpine)$' && OS_BASE="$OS_RELEASE"
	}
	echo "$OS_VERSION" | grep -qi 'snapshot' && {
		OS_VERSION="$(echo "$OS_VERSION" | awk '{gsub(/-?snapshot/,"",$0); print $0}')"
		[ -z "$OS_CODENAME" ] && OS_CODENAME="snapshot"
	}
	if [ "$OS_BASE" = "debian" ]; then
		[ -x "$(which apt)" ] && OS_PKG_MG="apt"
	elif [ "$OS_BASE" = "arch" ]; then
		pacman --version >/dev/null 2>&1 && OS_PKG_MG="pacman"
	elif echo "$OS_BASE" | grep -Eq "(rhel|fedora)"; then
		OS_BASE="rhel"
		yum --version >/dev/null 2>&1 && OS_PKG_MG="yum"
		# [ -z "$(which dnf 2>/dev/null)" ] || OS_PKG_MG="dnf"
		# OS_RELEASE=$(rpm -q --whatprovides redhat-release || rpm -q --whatprovides centos-release || rpm -q --whatprovides cloudlinux-release || rpm -q --whatprovides sl-release)
		[ -z "$OS_PLATFORM" ] || OS_TYPE=$(echo "$OS_PLATFORM" | grep -Eo 'el|fc')
		# case "$OS_RELEASE" in
		# 	"redhat"|"centos"|"cloudlinux"|"sl"|"ol"|"enterprise"|"system") OS_TYPE="el";;
		# 	"fedora"|"korora") OS_TYPE="fc";;
		# esac
	elif echo "$OS_BASE" | grep -Eq "(lede|openwrt)"; then
		OS_BASE="openwrt"
		[ -x "$(which opkg)" ] && OS_PKG_MG="opkg"
	elif [ "$OS_RELEASE" = "alpine" ]; then
		[ -z "$OS_CODENAME" ] && OS_CODENAME="alpine"
		[ -x "$(which apk)" ] && OS_PKG_MG="apk"
	else
		log_err "$LANG_NOT_SUPPORT_OS"
		return 1
	fi
	return 0
}

get_endian() {
	hexdump -s 5 -n 1 $(which sh) | awk '$1=="0000005" {if ($2=="0001") {print "le"} else if ($2=="0000") {print "be"} else {print ""}}'
	return $?
}

get_external_ip() {
	# https://ipinfo.io/
	# EXTERNAL_IP=$(c_curl -skL --max-time 10 "https://api.ipify.org/?format=text")
	__RES__=$(curl -skL --max-time 5 "http://whois.pconline.com.cn/ipJson.jsp")
	EXTERNAL_IP=$(echo "$__RES__" | grep -Eo '"ip":"[^"]+"' | awk -F':' '{gsub(/"/,"",$2); print $2}')
	[ -z "$EXTERNAL_IP" ] && return 1
	echo "[OK] successfully get external ip: $EXTERNAL_IP" >&2
	return 0
}

get_session_type() {
	loginctl show-session $(awk '/tty/ {print $1}' <$(loginctl)) -p Type | awk -F= '{print $2}'
}

get_bt_tracker() {
	BT_TRACKER=$(c_curl -skL https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_all.txt|grep -E '^(udp|http)')
	[ -z "$BT_TRACKER" ] && return 1
	return 0
}

get_cpu_cores() {
	_CPU_CORES_=0
	_CPU_CORES_=$(cat /proc/cpuinfo | grep '^processor\s*:' | wc -l)
	[ "$_CPU_CORES_" = 0 ] && _CPU_CORES_=$(cat /proc/cpuinfo | grep '^core\s*:' | wc -l)
	# _CPU_CORES_=$(cat "/proc/cpuinfo" | awk -F':' '{{gsub(/( |\t)+/,"",$1)} if($1=="cpucores"){CORES=CORES+$2} else if ($1=="core" || $1=="processor"){CORES++}} END{print CORES}')
	[ "$_CPU_CORES_" = 0 ] && return 1
	echo "$_CPU_CORES_"
	return 0
}

service_has() {
	has_package "systemctl" || return 1
	systemctl status "$1" >/dev/null 2>&1 && return 0
	return 1
}

service_is_active() {
	has_package "systemctl" || return 1
	systemctl is-active "$1" >/dev/null 2>&1 && return 0
	return 1
}

service_is_active() {
	has_package "systemctl" || return 1
	systemctl is-enabled "$1" >/dev/null 2>&1 && return 0
	return 1
}

service_is_running() {
	has_package "systemctl" || return 1
	systemctl status "$1" | awk '$1~/Active:/{print $2}' | grep -q "running" && return 0
	return 1
}

service_list() {
	has_package "systemctl" || return 1
	SERVICE_LIST_FILTER=$(echo "$1" | grep -Eq "(loaded|not-found|active|inactive|running|dead|exited)")
	if [ -z "$SERVICE_LIST_FILTER" ]; then
		SERVICE_LIST_FILTER="--all"
	else
		SERVICE_LIST_FILTER="--state=$1"
	fi
	# systemctl list-unit-files --state=running
	SERVICE_LIST=$(systemctl list-units --type service $SERVICE_LIST_FILTER  | sed -E "s/^●?\s+//" | awk '/.service/{gsub(/.service$/,"",$1); print $1}')
	echo "$SERVICE_LIST"
	return 0
}

download_file() {
	[ -z "$1" ] && return 1
	__DOWNLOAD_URL__="$1"
	__DOWNLOAD_OUT__="$2"
	__DOWNLOAD_OPTIONS__=$(echo "$@" | grep -Eo '\ -.*' | sed -E 's/^\s+//g')
	DOWNLOAD_FILE_NAME=""
	if [ -z "$__DOWNLOAD_OUT__" ]; then
		DOWNLOAD_FILE_DIR="."
	else
		DOWNLOAD_FILE_DIR=$(get_dir_path "$__DOWNLOAD_OUT__")
		[ "$DOWNLOAD_FILE_DIR" = "$__DOWNLOAD_OUT__" ] || [ "$DOWNLOAD_FILE_DIR/" = "$__DOWNLOAD_OUT__" ] || DOWNLOAD_FILE_NAME=$(echo "$__DOWNLOAD_OUT__" | awk -F'/' '{print $NF}')
	fi
	[ -z "$DOWNLOAD_FILE_NAME" ] && DOWNLOAD_FILE_NAME=$(echo "$__DOWNLOAD_URL__" | awk -F'/' '{print $NF}')
	[ -z "$DOWNLOAD_FILE_DIR" -o -z "$DOWNLOAD_FILE_NAME" ] && return 1
	[ -d "$DOWNLOAD_FILE_DIR" ] || {
		mkdir_p "$DOWNLOAD_FILE_DIR"
	}
	if has_package "aria2" > /dev/null 2>&1; then
		__DOWNLOAD_OPTIONS__=$(echo "$__DOWNLOAD_OPTIONS__" | sed -E -e 's/(-H|--header)\s+/--header=/g')
		eval "c_aria2 $__DOWNLOAD_OPTIONS__ --dir=\"$DOWNLOAD_FILE_DIR\" --out=\"$DOWNLOAD_FILE_NAME\" --allow-overwrite --max-connection-per-server=16 \"$__DOWNLOAD_URL__\"" && return 0
	else
		eval "c_curl $__DOWNLOAD_OPTIONS__ -kL -o \"$DOWNLOAD_FILE_DIR/$DOWNLOAD_FILE_NAME\" \"$__DOWNLOAD_URL__\"" && return 0
	fi
	return 1
}

tar_extract() {
	require_pkg "tar" >/dev/null 2>/dev/null || return 1
	[ -f "$1" ] || return 1
	TAR_EXTRACT_TO="${2:-.}"
	TAR_EXTRACT_ROOT="$(tar_list "$1" | awk -F'/' 'ROOT!=$1{ROOT=$1; COUNT++} END{if (COUNT==1) {print ROOT}}')"
	TAR_EXTRACT_LIST=""
	[ -d "$TAR_EXTRACT_TO" ] || mkdir_p "$TAR_EXTRACT_TO"
	if [ -z "$3" ]; then
		tar -xf "$1" -C "$TAR_EXTRACT_TO" && {
			TAR_EXTRACT_LIST=$(tar_list "$1" | awk "{print \"$TAR_EXTRACT_TO/\"\$0}")
			[ -d "$TAR_EXTRACT_TO/$TAR_EXTRACT_ROOT" ] || TAR_EXTRACT_ROOT=""
			return 0
		}
		return 1
	else
		while read FILE
		do
			[ -z "$FILE" ] || {
				FILE_NAME=$(echo "$FILE" | awk -F'/' '{print $NF}')
				FILE_PATH="$TAR_EXTRACT_TO/$FILE_NAME"
				tar -xf "$1" "$FILE" -O > "$FILE_PATH" && {
					if [ -z "$TAR_EXTRACT_LIST" ]; then
						TAR_EXTRACT_LIST="$FILE_PATH"
					else
						TAR_EXTRACT_LIST=$(cat <<-EOF
						$TAR_EXTRACT_LIST
						$FILE_PATH
						EOF
						)
					fi
				}
			}
		done<<-EOF
		$(tar_list "$1" | grep -E "[^\/]$" | grep -E "$3")
		EOF
	fi
	echo "$TAR_EXTRACT_LIST"
	return 0
}

tar_extract_remove() {
	tar_extract "$1" "$2" "$3" && rm -f "$1"
}

tar_list() {
	require_pkg "tar" >/dev/null 2>/dev/null || return 1
	[ -f "$1" ] || return 1
	tar -tf "$1" || return 1
	return 0
}

github_clone() {
	GITHUB_OPTION=""
	# git clone --single-branch --branch <branch-name> <remote-repo-url>
	[ -z "$1" -o -z "$2" ] && return 1
	rm -rf "$2"
	mkdir -p "$2"
	[ -z "$3" ] || GITHUB_OPTION="-b $3"
	c_git clone $GITHUB_OPTION "$1" "$2" && return 0 
	return 1
}

github_submodule_update() {
	[ -z "$1" ] || {
		[ -d "$1" ] && cd "$1"
	}
	c_git submodule update --init --recursive && return 0
	return 1
}

github_download_branch() {
	__GITHUB_DOWNLOAD_DIR__="$APP_CACHE_DIR/github"
	__GITHUB_DOWNLOAD_OUTPUT__=""
	mkdir -p "$__GITHUB_DOWNLOAD_DIR__" >/dev/null 2>&1
	download_file "https://github.com/${1}/archive/refs/heads/${2:-main}.zip" "${__GITHUB_DOWNLOAD_OUTPUT__:-$__GITHUB_DOWNLOAD_DIR__}" && {
		args_match "$@" "--unzip|-u" && {
			__GITHUB_DOWNLOAD_UNZIP_TO__="$ARGS_MATCH_VALUE"
			__GITHUB_DOWNLOAD_FOLDER__=$(c_unzip -ql "$__GITHUB_DOWNLOAD_DIR__/$DOWNLOAD_FILE_NAME" | head -n3 | awk '$NF~/\/$/{gsub(/\//,"",$NF); print $NF}')
			rm -rf "$__GITHUB_DOWNLOAD_DIR__/$__GITHUB_DOWNLOAD_FOLDER__"
			c_unzip -d "$__GITHUB_DOWNLOAD_DIR__" "$__GITHUB_DOWNLOAD_DIR__/$DOWNLOAD_FILE_NAME" && {
				[ -z "$__GITHUB_DOWNLOAD_UNZIP_TO__" ] || {
					if [ -d "$__GITHUB_DOWNLOAD_UNZIP_TO__" ]; then
						ls -a "$__GITHUB_DOWNLOAD_DIR__/$__GITHUB_DOWNLOAD_FOLDER__" | grep -v '^\.+$' | \
							while read F_D; do cp -rf "$__GITHUB_DOWNLOAD_DIR__/$__GITHUB_DOWNLOAD_FOLDER__/$F_D" "$__GITHUB_DOWNLOAD_UNZIP_TO__"; done
					else
						mkdir -p "$(echo $__GITHUB_DOWNLOAD_UNZIP_TO__ | awk '{gsub(/\/[^\/]+$/, "", $0); print $0}')"
						mv "$__GITHUB_DOWNLOAD_DIR__/${__GITHUB_DOWNLOAD_FOLDER__}" "$__GITHUB_DOWNLOAD_UNZIP_TO__"
					fi
					rm -rf "$__GITHUB_DOWNLOAD_DIR__/$__GITHUB_DOWNLOAD_FOLDER__"
				}
			}
			rm -f "$__GITHUB_DOWNLOAD_DIR__/$DOWNLOAD_FILE_NAME"
			return 0
		}
		args_match "$@" "--output|-o" && [ -z "$ARGS_MATCH_VALUE" ] && {
			mv "${__GITHUB_DOWNLOAD_DIR__}/$DOWNLOAD_FILE_NAME" "${__GITHUB_DOWNLOAD_DIR__}/$__GITHUB_DOWNLOAD_NAME__" && \
				echo "$ARGS_MATCH_VALUE" && \
					return 0
		}
		echo "${__GITHUB_DOWNLOAD_DIR__}/${DOWNLOAD_FILE_NAME}"
	}
	return 0
}

github_releases_url() {
	[ -z "$1" ] && return 1
	GITHUB_RELEASES_TAG="$2"
	[ -z "$GITHUB_RELEASES_TAG" -o "$GITHUB_RELEASES_TAG" = "latest" ] && \
	GITHUB_RELEASES_TAG=$(c_curl -skL "https://github.com/$1/releases" | \
		grep -Eo 'href="[^"]+/tag/[^"]+"' | \
		head -n1 | awk -F'/' '{gsub("\"","",$NF); print $NF}')
	[ -z "$GITHUB_RELEASES_TAG" ] && return 1
	GITHUB_RELEASES_URL=$(c_curl -skL "https://github.com/$1/releases/expanded_assets/$GITHUB_RELEASES_TAG" | \
		grep -Eo "href=[\"'][^\"^']+[\"']" | \
		awk "{gsub(/^href=/,\"\",\$0); gsub(/[\"']/,\"\",\$0); print \$0}" | \
		awk '{print "https://github.com"$0}')
	[ -z "$GITHUB_RELEASES_URL" ] && return 1
	echo "$GITHUB_RELEASES_URL"
	return 0
}

github_action_cleanup() {
	id runner 2>/dev/null || return 1
	[ -d "/home/runner/work/_actions" ] || return 1
	sudo -E apt-get -qq update
	# sudo -E apt-get -qq install build-essential asciidoc binutils bzip2 gawk gettext git libncurses5-dev libz-dev patch python3 python2.7 unzip zlib1g-dev lib32gcc1 libc6-dev-i386 subversion flex uglifyjs gcc-multilib g++-multilib p7zip p7zip-full msmtp libssl-dev texinfo libglib2.0-dev xmlto qemu-utils upx-ucl libelf-dev autoconf automake libtool autopoint device-tree-compiler ccache xsltproc rename antlr3 gperf wget curl swig rsync
	sudo -E apt-get -qq purge azure-cli ghc* zulu* llvm* firefox powershell openjdk* dotnet* google* mysql* php* android*
	sudo rm -rf /etc/apt/sources.list.d/* /usr/share/dotnet /usr/local/lib/android /opt/ghc
	sudo -E apt-get -qq autoremove --purge
	sudo -E apt-get -qq clean
	sudo rm -rf /usr/share/rust /usr/share/miniconda /usr/share/swift /opt/hostedtoolcache/
	# sudo rm -rf /usr/share/dotnet /etc/mysql /etc/php /usr/local/lib/android
	return 0
}

github_action_api() {
	__GITHUB_API_URL__="https://api.github.com/repos/${GITHUB_REPOSITORY}"
	__OPTIONS__="-H \"Authorization: Bearer ${GITHUB_TOKEN}\""
	eval $(echo "$1" | awk -F'(/|:)' '{print "__PATH_A__=\""$1"\"; __PATH_B__=\""$2"\"; __PATH_C__=\""$3"\""}')
	__DATA__="$2"
	__URL__=""
	[ "$__PATH_C__" = "delete" ] && __OPTIONS__="$__OPTIONS__ -X DELETE"
	case "$__PATH_A__" in
		"workflows")
			__URL__="${__GITHUB_API_URL__}/actions/workflows$([ -z "${__PATH_B__}" ] || echo "/${__PATH_B__}")"
			case "$__PATH_C__" in
				"dispatch"|"fire")
					# https://docs.github.com/en/actions/using-workflows/events-that-trigger-workflows
					# {"event_type": "test_result", "client_payload": {"passed": false, "message": "Error: timeout"}}
					__URL__="${__URL__}/dispatches"
					[ -z "$__DATA__" ] && __DATA__="{\"ref\":\"main\"}"
					__OPTIONS__="$__OPTIONS__ -X POST -d '$__DATA__'"
					;;
				"usage")
					__URL__="${__URL__}/timing"
					;;
				"disable"|"enable")
					__URL__="${__URL__}/${__PATH_C__}"
					__OPTIONS__="$__OPTIONS__ -X PUT"
					;;
			esac
			;;
		"runs")
			[ -z "$__PATH_B__" ] && return 1
			__URL__="${__GITHUB_API_URL__}/actions/runs/${__PATH_B__}"
			[ "$__PATH_C__" = "cancel" ] && {
				__OPTIONS__="$__OPTIONS__ -X POST"
				__URL__="${__URL__}/cancel"
			}
			;;
		"artifacts")
			__URL__="${__GITHUB_API_URL__}/actions/artifacts"
			[ -z "$__PATH_B__" ] || {
				case "$__PATH_B__" in
					"delete")
						github_action_api artifacts
						return $?
						;;
					*)
						__URL__="${__URL__}/${__PATH_B__}"
						[ -z "$__PATH_C__" ] || {
							[ "$__PATH_C__" = "zip" ] && __PATH_C__="archive_download_url"
							__VALUE__=$(github_action_api artifacts/$__PATH_B__ | jq -r ".$__PATH_C__")
							[ -z "$__VALUE__" ] && return 1
							[ -z "$__DATA__" ] && echo "$__VALUE__" || {
								# eval "curl -kL $__OPTIONS__ -o \"$__DATA__\" \"$__DOWNLOAD_URL__\""
								download_file "$__VALUE__" "$__DATA__" $__OPTIONS__
							}
							return $?
						}
						;;
				esac
			}
			;;
		"variables"|"vars")
			__URL__="${__GITHUB_API_URL__}/actions/variables"
			[ -z "$__PATH_B__" ] || {
				case "$__PATH_B__" in
					"delete")
						github_action_api vars | grep '"name":' | tr -d ' ,"' | awk -F':' '{print $2}'
						return $?
						;;
					*)
						__URL__="${__URL__}/${__PATH_B__}"
						;;
				esac
			}
			[ -z "$__DATA__" ] || {
				[ -z "$__PATH_B__" ] && {
					# NAME=VALUE
					__VAR_NAME__=$(echo "$__DATA__" | awk -F'=' '{print $1}')
					__VAR_VALUE__=$(echo "$__DATA__" | awk -F'=' '{for (i=2; i<=NF; i++) {V=V==""?$i:V""$i}} END{print V}')
					__OPTIONS__="$__OPTIONS__ -X POST -d '{\"name\":\"${__VAR_NAME__}\", \"value\":\"${__VAR_VALUE__}\"}'"
				} || {
					__OPTIONS__="$__OPTIONS__ -X PATCH -d '{\"name\":\"${__PATH_B__}\", \"value\":\"${__DATA__}\"}'"
				}
			}
			;;
		"secrets")
			__URL__="${__GITHUB_API_URL__}/actions/secrets"
			[ -z "$__PATH_B__" ] || {
				case "$__PATH_B__" in
					"delete")
						github_action_api secrets | grep '"name":' | tr -d ' ,"' | awk -F':' '{print $2}'
						return $?
						;;
					*)
						__URL__="${__URL__}/${__PATH_B__}"
						[ "$__PATH_C__" = "delete" ] && __OPTIONS__="$__OPTIONS__ -X DELETE"
						;;
				esac
			}
			[ -z "$__DATA__" ] || {
				github_action_api "encrypt" "${__DATA__}" || return 1
				__OPTIONS__="$__OPTIONS__ -X PUT -d '{\"encrypted_value\":\"${__ENCRYPT_VALUE__}\"}'"
			}
			;;
		"encrypt")
			[ -z "$__DATA__" ] || {
				__CACHE_DIR__="$APP_CACHE_DIR/github_encrypt"
				mkdir_p "$__CACHE_DIR__"
				__GITHUB_PUBLIC_KEY__=$(github_action_api "secrets/public-key" | jq -r '.key')
				[ -z "$__GITHUB_PUBLIC_KEY__" ] && return 1
				cd $__CACHE_DIR__
				cat <<-EOF > encrypt.js
				const sodium = require('libsodium-wrappers')
				const secret = '${__DATA__}' // replace with the secret you want to encrypt
				const key = '${__GITHUB_PUBLIC_KEY__}' // replace with the Base64 encoded public key

				//Check if libsodium is ready and then proceed.
				sodium.ready.then(() => {
				// Convert Secret & Base64 key to Uint8Array.
				let binkey = sodium.from_base64(key, sodium.base64_variants.ORIGINAL)
				let binsec = sodium.from_string(secret)

				//Encrypt the secret using LibSodium
				let encBytes = sodium.crypto_box_seal(binsec, binkey)

				// Convert encrypted Uint8Array to Base64
				let output = sodium.to_base64(encBytes, sodium.base64_variants.ORIGINAL)

				console.log(output)
				});
				EOF
				[ -d "node_modules/libsodium-wrappers" ] || npm i libsodium-wrappers >/dev/null 2>/dev/null
				__ENCRYPT_VALUE__=$(node encrypt.js 2>/dev/null | grep -E '^ENCRYPT_VALUE:' | awk -F':' '{print $2}')
				rm -f "encrypt.js"
				cd $CUR_DIR
				[ -z "$__ENCRYPT_VALUE__" ] && return 1
				echo "$__ENCRYPT_VALUE__"
				return 0
			}
			;;
		"permissions")
			__URL__="${__GITHUB_API_URL__}/permissions"
			[ -z "$__DATA__" ] || __OPTIONS__="$__OPTIONS__ -X PUT -d $__DATA__"
			;;
		"clean")
			github_action_cleanup
			;;
		*)
			case "$__PATH_B__" in
				"runs")
					__URL__="${__GITHUB_API_URL__}/actions/workflows/${__PATH_A__}/runs"
					;;
				"jobs")
					__URL__="${__GITHUB_API_URL__}/actions/runs/${__PATH_A__}/jobs"
					;;
				"artifacts")
					__URL__="${__GITHUB_API_URL__}/actions/runs/${__PATH_A__}/artifacts"
					;;
			esac
	esac
	[ -z "$__URL__" ] && return 1
	[ "$COONCLI_DEBUG" = "1" ] && echo "curl -skL $__OPTIONS__  \"$__URL__\"" >&2
	eval "curl -skL $__OPTIONS__  \"$__URL__\""
	__CODE__=$?
	[ "$LOG_ENABLED" = "1" ] && echo "curl -skL $__OPTIONS__  $__URL__" >> $LOG_FILE
	return $__CODE__
}

gitlab_releases_url() {
	require_pkg || return 1
	GITLAB_TAG="$2"
	__DATA__=$(c_curl -skL 'https://gitlab.com/api/graphql' \
		-H 'content-type: application/json' \
  		--data-raw "[{\"operationName\":\"allReleases\",\"variables\":{\"fullPath\":\"$1\",\"first\":10,\"sort\":\"RELEASED_AT_DESC\"},\"query\":\"query allReleases(\$fullPath: ID\u0021, \$first: Int, \$last: Int, \$before: String, \$after: String, \$sort: ReleaseSort) {\\n  project(fullPath: \$fullPath) {\\n    id\\n    releases(\\n      first: \$first\\n      last: \$last\\n      before: \$before\\n      after: \$after\\n      sort: \$sort\\n    ) {\\n      nodes {\\n        ...Release\\n        __typename\\n      }\\n      pageInfo {\\n        startCursor\\n        hasPreviousPage\\n        hasNextPage\\n        endCursor\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\\nfragment Release on Release {\\n  id\\n  name\\n  tagName\\n  tagPath\\n  descriptionHtml\\n  releasedAt\\n  createdAt\\n  upcomingRelease\\n  historicalRelease\\n  assets {\\n    count\\n    sources {\\n      nodes {\\n        format\\n        url\\n        __typename\\n      }\\n      __typename\\n    }\\n    links {\\n      nodes {\\n        id\\n        name\\n        url\\n        directAssetUrl\\n        linkType\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  evidences {\\n    nodes {\\n      id\\n      filepath\\n      collectedAt\\n      sha\\n      __typename\\n    }\\n    __typename\\n  }\\n  links {\\n    editUrl\\n    selfUrl\\n    openedIssuesUrl\\n    closedIssuesUrl\\n    openedMergeRequestsUrl\\n    mergedMergeRequestsUrl\\n    closedMergeRequestsUrl\\n    __typename\\n  }\\n  commit {\\n    id\\n    sha\\n    webUrl\\n    title\\n    __typename\\n  }\\n  author {\\n    id\\n    webUrl\\n    avatarUrl\\n    username\\n    __typename\\n  }\\n  milestones {\\n    nodes {\\n      id\\n      title\\n      description\\n      webPath\\n      stats {\\n        totalIssuesCount\\n        closedIssuesCount\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  __typename\\n}\\n\"}]")
	__RELEASES__=$(echo "$__DATA__" | jq '[.[0].data.project.releases.nodes[] | {name: .name, files: .assets.links.nodes}]')
	[ -z "$GITLAB_TAG" ] && GITLAB_TAG=$(echo "$__RELEASES__" | jq -r '.[0] | .name')
	[ -z "$2" ] && __RELEASE_FILES__=$(echo "$__RELEASES__" | jq -r '.[0] | .files[] | .directAssetUrl') || __RELEASE_FILES__=$(echo "$__RELEASES__" | jq -r ".[] | select( .name == \"$2\" ) | .files[] | .directAssetUrl")
	[ -z "$__RELEASE_FILES__" ] && return 1
	echo "$__RELEASE_FILES__" && return 0
}

size_to_human() {
	# echo "$1" 1>&2
	echo "$1" | grep -Eq "^[0-9]" || {
		echo "0,0.0Byte" && return 1
	}
	echo "$1" | awk 'BEGIN{UNIT="Byte"; TIMES=0} {
		if ($0~/g|G/) {UNIT="GB"; TIMES=1024*1024} else if ($0~/m|M/) {UNIT="MB"; TIMES=1024} else if ($0~/k|K/) {UNIT="KB"; TIMES=1}
		gsub(/[a-zA-Z]+/, "", $0);
		VALUE=$0
		TOTAL_KB=VALUE*TIMES
		if (VALUE*1 >= 1024) {
						VALUE=$0/1024;
						if (UNIT=="GB") {UNIT="TB"} else if (UNIT=="MB") {UNIT="GB"} else if (UNIT=="KB") {UNIT="MB"}
		}
		printf ("%s,%.1f%s\n", TOTAL_KB, VALUE, UNIT);
	}'
	return 0
}

seconds_to_human() {
	SECONDS_TO_HUMAN_STYLE=""
	args_match "$@" "--short|-s" && SECONDS_TO_HUMAN_STYLE="short"
	echo "$1" | awk -v "STYLE=$SECONDS_TO_HUMAN_STYLE" '
	$1>=0 {
		DAY=int($0/(3600*24)); HOUR=int(($0%(3600*24))/3600); MINUTE=int(($0%3600)/60); SENCOND=int($0%60)
	}
	END{
		if (STYLE=="short") {
			print (DAY>0?DAY" days, ":"")(HOUR>0?HOUR" hours, ":"")(MINUTE>0?MINUTE" mins, ":"")SENCOND" s"
		} else {
			print DAY" days, "HOUR" hours, "MINUTE" mins, "SENCOND" s"
		}
	}'
}

time_count() {
	[ "$1" = "0" ] && TIME_COUNT_BIGIN=""
	if [ -z "$TIME_COUNT_BIGIN" ]; then
		TIME_COUNT_BIGIN=$(date +%s.%N)
	else
		# int(($TIME_COUNT_END-$TIME_COUNT_BIGIN)*100)/100
		TIME_COUNT_END=$(date +%s.%N)
		TIME_COUNT=$(echo "" | awk "{print int(($TIME_COUNT_END-$TIME_COUNT_BIGIN)*1000)/1000}")
		TIME_COUNT_BIGIN=""
	fi
	return 0
}

curl_status() {
	require_pkg "curl" >/dev/null 2>/dev/null || return 1
	curl $*
	CURL_STATUS_CODE="$?"
	__CODE_MAP__=$(cat <<-EOF
	0:CURL_OK
	1:CURL_UNSUPPORTED_PROTOCOL
	2:CURL_FAILED_INIT
	3:CURL_URL_MALFORMAT
	4:CURL_NOT_BUILT_IN
	5:CURL_COULDNT_RESOLVE_PROXY
	6:CURL_COULDNT_RESOLVE_HOST
	7:CURL_COULDNT_CONNECT
	8:CURL_FTP_WEIRD_SERVER_REPLY
	9:CURL_REMOTE_ACCESS_DENIED
	10:CURL_FTP_ACCEPT_FAILED
	11:CURL_FTP_WEIRD_PASS_REPLY
	12:CURL_FTP_ACCEPT_TIMEOUT
	13:CURL_FTP_WEIRD_PASV_REPLY
	14:CURL_FTP_WEIRD_227_FORMAT
	15:CURL_FTP_CANT_GET_HOST
	16:CURL_HTTP2
	17:CURL_FTP_COULDNT_SET_TYPE
	18:CURL_PARTIAL_FILE
	19:CURL_FTP_COULDNT_RETR_FILE
	21:CURL_QUOTE_ERROR
	22:CURL_HTTP_RETURNED_ERROR
	23:CURL_WRITE_ERROR
	25:CURL_UPLOAD_FAILED
	26:CURL_READ_ERROR
	27:CURL_OUT_OF_MEMORY
	28:CURL_OPERATION_TIMEDOUT
	30:CURL_FTP_PORT_FAILED
	31:CURL_FTP_COULDNT_USE_REST
	33:CURL_RANGE_ERROR
	34:CURL_HTTP_POST_ERROR
	35:CURL_SSL_CONNECT_ERROR
	36:CURL_BAD_DOWNLOAD_RESUME
	37:CURL_FILE_COULDNT_READ_FILE
	38:CURL_LDAP_CANNOT_BIND
	39:CURL_LDAP_SEARCH_FAILED
	41:CURL_FUNCTION_NOT_FOUND
	42:CURL_ABORTED_BY_CALLBACK
	43:CURL_BAD_FUNCTION_ARGUMENT
	45:CURL_INTERFACE_FAILED
	47:CURL_TOO_MANY_REDIRECTS
	48:CURL_UNKNOWN_OPTION
	49:CURL_TELNET_OPTION_SYNTAX
	52:CURL_GOT_NOTHING
	53:CURL_SSL_ENGINE_NOTFOUND
	54:CURL_SSL_ENGINE_SETFAILED
	55:CURL_SEND_ERROR
	56:CURL_RECV_ERROR
	58:CURL_SSL_CERTPROBLEM
	59:CURL_SSL_CIPHER
	60:CURL_PEER_FAILED_VERIFICATION
	61:CURL_BAD_CONTENT_ENCODING
	62:CURL_LDAP_INVALID_URL
	63:CURL_FILESIZE_EXCEEDED
	64:CURL_USE_SSL_FAILED
	65:CURL_SEND_FAIL_REWIND
	66:CURL_SSL_ENGINE_INITFAILED
	67:CURL_LOGIN_DENIED
	68:CURL_TFTP_NOTFOUND
	69:CURL_TFTP_PERM
	70:CURL_REMOTE_DISK_FULL
	71:CURL_TFTP_ILLEGAL
	72:CURL_TFTP_UNKNOWNID
	73:CURL_REMOTE_FILE_EXISTS
	74:CURL_TFTP_NOSUCHUSER
	75:CURL_CONV_FAILED
	76:CURL_CONV_REQD
	77:CURL_SSL_CACERT_BADFILE
	78:CURL_REMOTE_FILE_NOT_FOUND
	79:CURL_SSH
	80:CURL_SSL_SHUTDOWN_FAILED
	81:CURL_AGAIN
	82:CURL_SSL_CRL_BADFILE
	83:CURL_SSL_ISSUER_ERROR
	84:CURL_FTP_PRET_FAILED
	85:CURL_RTSP_CSEQ_ERROR
	86:CURL_RTSP_SESSION_ERROR
	87:CURL_FTP_BAD_FILE_LIST
	88:CURL_CHUNK_FAILED
	89:CURL_NO_CONNECTION_AVAILABLE
	90:CURL_SSL_PINNEDPUBKEYNOTMATCH
	91:CURL_SSL_INVALIDCERTSTATUS
	92:CURL_HTTP2_STREAM
	93:CURL_RECURSIVE_API_CALL
	EOF
	)
	CURL_STATUS_TXT=$(echo "$__CODE_MAP__" | grep -E "^${CURL_STATUS_CODE}:" | awk -F':' '{print $2}')
	return $CURL_STATUS_CODE
}

cp_regex() {
	[ -d "$1" ] || return 1
	[ -z "$2" ] && return 1
	mkdir_p "$2"
	if [ -z "$3" ]; then
		cp -rf "$1/"* "$2"
	else
		while read FILE_OR_DIR
		do
			[ -z "$FILE_OR_DIR" ] || {
				cp -rf "$FILE_OR_DIR" "$2"
			}
		done<<-EOF
		$(ls $1 | grep -E "$3")
		EOF
	fi
	return 0
}

link_as_bin() {
	LINK_FROM=""
	[ -f "$1" ] && LINK_FROM="$1"
	[ -d "$1" ] && {
		[ -z "$2" ] || {
			LINK_FROM=$(ls "$1" | grep -E "$2")
			[ -z "$LINK_FROM" ] || LINK_FROM=$(echo "$LINK_FROM" | awk "{print \"$1/\"\$0}")
		}
	}
	[ -z "$LINK_FROM" ] && return 1
	while read FILE
	do
		[ -f "$FILE" ] && {
			chmod +x "$FILE"
			FILE_NAME=$(echo "$FILE" | awk -F'/' '{print $NF}')
			ln -sf "$FILE" "/usr/sbin/$FILE_NAME"
		}
	done<<-EOF
	$LINK_FROM
	EOF
	return 0
}

mkdir_p() {
	[ -d "$1" ] && return 0
	mkdir -p "$1" || return 1
	return 0
}

draw_line() {
	echo "$1" | awk -vWIDTH=${2:-48} '{for (i=1;i<=WIDTH;i++) {LINE=LINE==""?$0:LINE$0}; print LINE}'
}

input_header() {
	clear
	[ -z "$ERR" ] || echo "$ERR"
	ERR=''
	echo "===================================================="
	echo "                   $TITLE"
	echo "===================================================="
	echo "$LANG_OS_VERSION : $OS_ISSUE / $OS_ARCH"
	echo "$LANG_KERNEL_VERSION : $KERNEL_VERSION_INSTALLED"
	[ -z "$USER_NAME" ] || echo "User:  $USER_NAME"
	[ -z "$USER_PWD" ] || echo "Password:  $USER_PWD"
	[ -z "$SSH_PORT" ] || echo "SSH Port:  $SSH_PORT"
	[ -z "$SWAP_FILE_SIZE" ] || echo "Swap File Size:  ${SWAP_FILE_SIZE}MB"
	[ -z "$LNMP" ] || echo "* LNMP:  $LNMP  "$([ -z "$MYSQL_PWD" ] || echo "  /  MySQL Password:  $MYSQL_PWD )")
	[ -z "$VNC" ] || echo "* VNC:  $VNC"$([ -z "$VNC_DISPLAY" ] || echo "  /  Resolution:  $VNC_DISPLAY_RESOLUTION )")
	[ -z "$NODEJS" ] || echo "* NodeJS + Redis:  $NODEJS"
	echo "----------------------------------------------------"
}

input_select_options() {
	SELECT_OPTIONS=""
	_OPTION_DEFAULT_SELECT_=""
	_i=0
	while [ $# -gt 0 ]
	do
		[ -z "$1" ] || {
			eval $(echo "$1" | awk -F'    ' '{print "_OPTION_IS_DEFAULT_="($1~/^\*/ ? 1 : 0) ";_OPTION_VALUE_=\""$1"\";_OPTION_TITLE_=\""$2"\""}')
			[ "$_OPTION_VALUE_" = "-" ] && _OPTION_ID_="0" || {
				_i=$((_i+1))
				_OPTION_ID_=$_i
			}
			[ "$_OPTION_IS_DEFAULT_" = "1" ] && _OPTION_DEFAULT_SELECT_=$_OPTION_ID_
			[ -z "$SELECT_OPTIONS" ] && SELECT_OPTIONS="$_OPTION_ID_    $1" || SELECT_OPTIONS=$(cat <<-EOF
			$SELECT_OPTIONS
			$_OPTION_ID_    $1
			EOF
			)
			echo "[$_OPTION_ID_] $([ -z "$_OPTION_TITLE_" ] && echo "$_OPTION_VALUE_" || echo "$_OPTION_TITLE_")"$([ "$_OPTION_IS_DEFAULT_" = "1" ] && echo " $SYMBOL_SELECTED")
		}
		shift
	done
	SELECT_COUNT=$_i
	[ -z "$SELECT_OPTIONS" ] && return 1
	echo ""
	[ -z "$_OPTION_DEFAULT_SELECT_" ] || echo "$LANG_SELECT_DEFAULT"
	echo ""
}

input_select_value() {
	SELECT_INPUT="$1"
	[ -z "$SELECT_INPUT" ] && {
		[ -z "$_OPTION_DEFAULT_SELECT_" ] || SELECT_INPUT=$_OPTION_DEFAULT_SELECT_
	}
	SELECT_VALUE=$(echo "$SELECT_OPTIONS" | awk -F'    ' "\$1==\"$SELECT_INPUT\" {gsub(/^\\*/,\"\",\$2); print \$2}")
	[ -z "$SELECT_VALUE" ] && return 0
	return 0
}

input_ssh_port() {
	[ -z "$SSH_PORT" ] || return 0
	[ "$SHOW_HEADER" = "1" ] && input_header
	SSH_PORT_DEFAULT=$(cat /etc/ssh/sshd_config|grep -Ei '^#?port'|grep -Eo '[0-9]+')
	SSH_PORT_DEFAULT=${SSH_PORT_DEFAULT:-22}
	[ "$SHOW_HEADER" = "1" ] && input_header
	echo "SSH ${LANG_PORT}"
	echo "- ${LANG_PORT}: 1 ~ 65535"
	echo "[0] ${LANG_SKIP} ${SYMBOL_SELECTED}"
	echo "$LANG_SELECT_DEFAULT"
	read -p "[$LANG_PORT]: " SSH_PORT
	[ -z "$SSH_PORT" -o "$SSH_PORT" = '0' ] && SSH_PORT="$SSH_PORT_DEFAULT"
	SSH_PORT=$(echo "$SSH_PORT"|grep -Eo '[1-9][0-9]*')
	[ -z "$SSH_PORT" ] || {
		[ "$SSH_PORT" -gt 1 -a "$SSH_PORT" -lt 65535 ] && return 0
	}
	ERR="[ERR]: ${LANG_NOT_VALID_PORT}"
	input_ssh_port
}

input_user_name() {
	[ -z "$1" ] || {
		USER_NAME="$1"
		return 0
	}
	[ "$SHOW_HEADER" = "1" ] && input_header
	echo "$LANG_CREATE_NEW_USER"
	echo "- $LANG_USER_NAME_FORMAT_MUST_BE"
	echo "- $LANG_SELECT_DEFAULT"
	read -p "[$LANG_USER_NAME]: " NEW_USER_NAME
	echo "$NEW_USER_NAME"|grep -Ew '[a-z_]{3,32}' && USER_NAME="$NEW_USER_NAME" && get_home_path "$USER_NAME" && return 0
	ERR="[ERROR]: ${LANG_NOT_VALID_USER_NAME}"
	input_user_name
}

input_user_pwd() {
	[ "$SHOW_HEADER" = "1" ] && input_header
	USER_NAME=${USER_NAME:-root}
	echo "$LANG_USER_PASSWORD - ${USER_NAME}"
	echo "- $LANG_PASSWORD_FORMAT"
	echo "[1] ${USER_PWD_DEFAULT}"$([ "$USER_NAME" = "root" ] || echo "${SYMBOL_SELECTED}")
	[ "$USER_NAME" = "root" ] && echo "[0] ${LANG_SKIP} ${SYMBOL_SELECTED}"
	echo "$LANG_SELECT_DEFAULT"
	read -p "[$LANG_PASSWORD]: " USER_PWD
	if [ "$USER_NAME" = "root" ]; then
		[ "$USER_PWD" = "0" -o -z "$USER_PWD" ] && USER_PWD="" && return 0
	else
		[ -z "$USER_PWD" -o "$USER_PWD" = '1' ] && USER_PWD="$USER_PWD_DEFAULT"
	fi
	echo "$USER_PWD"|grep -Ew '[0-9a-zA-Z!@#$%^&*|<>_+=~.,:;]{6,16}' && return 0
	ERR="[ERR]: ${LANG_NOT_VALID_PASSWORD}"
	input_user_pwd
}

input_vnc_pwd() {
	[ -z "$VNC_PWD" ] || return 0
	[ "$SHOW_HEADER" = "1" ] && input_header
	echo "VNC $LANG_PASSWORD"
	echo "- $LANG_PASSWORD_FORMAT"
	if [ -z "$(cat $VNC_KEY 2>/dev/null)" ];then
		[ -z "$USER_PWD" ] || {
			echo "[0] ${USER_PWD}  ${LANG_SELECTED}"
			echo "$LANG_SELECT_DEFAULT"
		}
	else
		echo "[0] $LANG_SKIP ($LANG_VNC_PASSWORD_ALREADY_SET : $VNC_KEY)"
		echo "$LANG_SELECT_DEFAULT"
	fi
	read -p "[$LANG_PASSWORD]: " VNC_PWD
	[ -z "$VNC_PWD" -o "$VNC_PWD" = "0" ] && {
		[ -z "$(cat $VNC_KEY 2>/dev/null)" ] || return 0
		[ -z "$USER_PWD" ] && VNC_PWD="$USER_PWD"
	}
	echo "$VNC_PWD"|grep -Ew '[0-9a-zA-Z!@#$%^&*|<>_+=~.,:;]{4,16}' && return 0
	ERR="[ERROR]: Not a valid password!"
	VNC_PWD=""
	input_vnc_pwd
}

input_vnc_display_resolution() {
	[ -z "$VNC_DISPLAY_RESOLUTION" ] || return 1
	[ "$SHOW_HEADER" = "1" ] && input_header
	echo "VNC $LANG_DISPLAY_RESOLUTION"
	input_select_options "640x480" "800x640" "1024x768" "*1280x720" "1366x768" "1440x900" "1920x1080" "4096x2160"
	read -p "[1,2... $LANG_OR 480x480]: " VNC_DISPLAY_RESOLUTION
	input_select_value "$VNC_DISPLAY_RESOLUTION" && VNC_DISPLAY_RESOLUTION="$SELECT_VALUE"
	echo "$VNC_DISPLAY_RESOLUTION" | grep -Eo "[1-9][0-9]{2,3}x[1-9][0-9]{2,3}" && return 0
	VNC_DISPLAY_RESOLUTION=""
	input_vnc_display_resolution
}

input_desktop_env() {
	[ -z "$DESKTOP_ENV" ] || return 1
	[ "$SHOW_HEADER" = "1" ] && input_header
	echo "Desktop Environment"
	input_select_options "*xfce    XFCE" "lxde    LXDE" "lxqt    LXQT" "-    $LANG_SKIP"
	read -p "[0~$SELECT_COUNT]: " DESKTOP_ENV
	input_select_value "$DESKTOP_ENV" && DESKTOP_ENV="$SELECT_VALUE"
	echo "DESKTOP_ENV: $DESKTOP_ENV"
	[ -z "$DESKTOP_ENV" ] || return 0
	DESKTOP_ENV=""
	input_desktop_env
}

input_mysql_pwd() {
	[ -z "$MYSQL_PWD" ] || return 1
	[ "$SHOW_HEADER" = "1" ] && input_header
	echo "MySQL $LANG_PASSWORD"
	echo "- $LANG_PASSWORD_FORMAT"
	[ -z "$USER_PWD" ] || echo "[0] ${USER_PWD}  ${SYMBOL_SELECTED}"
	echo "$LANG_SELECT_DEFAULT"
	read -p "[MySQL $LANG_]: " MYSQL_PWD
	[ -z "$USER_PWD" ] || {
		[ -z "$MYSQL_PWD" -o "$MYSQL_PWD" = '0' ] && MYSQL_PWD="$USER_PWD"
	}
	echo "$MYSQL_PWD"|grep -Ew '[0-9a-zA-Z!@#$%^&*|<>_+=~.,:;]{4,16}' && return 0
	ERR="[ERR] $LANG_NOT_VALID_PASSWORD"
	MYSQL_PWD=""
	input_mysql_pwd
}

input_yes_no() {
	[ "$SHOW_HEADER" = "1" ] && input_header
	CHOICE_YES_NO=""
	CHOICE_YES_NO_DEFAULT="${3:-n}"
	[ -z "$2" ] || echo "$2"
	echo "[y] Yes    $([ "$CHOICE_YES_NO_DEFAULT" = "y" ] && echo "$SYMBOL_SELECTED")"
	echo "[n] No     $([ "$CHOICE_YES_NO_DEFAULT" = "n" ] && echo "$SYMBOL_SELECTED")"
	read -p "[y / n]: " CHOICE_YES_NO
	[ -z "$CHOICE_YES_NO" ] && CHOICE_YES_NO="$CHOICE_YES_NO_DEFAULT"
	[ "$CHOICE_YES_NO" = "y" -o "$CHOICE_YES_NO" = "Y" ] && CHOICE_YES_NO="1"
	[ "$CHOICE_YES_NO" = "n" -o "$CHOICE_YES_NO" = "N" ] && CHOICE_YES_NO="0"
	[ "$CHOICE_YES_NO" = "0" -o "$CHOICE_YES_NO" = "1" ] && {
		[ -z "$1" ] || eval "$1=\"$CHOICE_YES_NO\""
		[ "$CHOICE_YES_NO" = "1" ] && return 0
		[ "$CHOICE_YES_NO" = "0" ] && return 1
	}
	input_yes_no "$1" "$2" "$3"
}

random_string() {
	args_match "$@" "--length|-l" && PASSWORD_LENGTH="$ARGS_MATCH_VALUE"
	[ -z "$PASSWORD_LENGTH" ] && return 1
	[ "$PASSWORD_LENGTH" -gt 0 ] || return 1
	RANDOM_LOWER="abcdefghijklmnopqrstuvwxyz"
	RANDOM_UPPER="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
	RANDOM_DIGIT="0123456789"
	RANDOM_SIGN='-+*#@_!$^'
	RANDOM_CODE="$RANDOM_LOWER$RANDOM_UPPER$RANDOM_DIGIT$RANDOM_SIGN"
	if args_match "$@" "--only-with|-o"; then
		RANDOM_CODE="$ARGS_MATCH_VALUE"
		[ -z "$RANDOM_CODE" ] && return 1
	elif args_match "$@" "--digit|-D|--upper|-U|--lower|-L|--sign|-S"; then
		RANDOM_CODE=""
		args_match "$@" "--digit|-D" && RANDOM_CODE="$([ -z "$RANDOM_CODE" ] || echo "$RANDOM_CODE")$RANDOM_DIGIT"
		args_match "$@" "--upper|-U" && RANDOM_CODE="$([ -z "$RANDOM_CODE" ] || echo "$RANDOM_CODE")$RANDOM_UPPER"
		args_match "$@" "--lower|-L" && RANDOM_CODE="$([ -z "$RANDOM_CODE" ] || echo "$RANDOM_CODE")$RANDOM_LOWER"
		args_match "$@" "--sign|-S" && RANDOM_CODE="$([ -z "$RANDOM_CODE" ] || echo "$RANDOM_CODE")$RANDOM_SIGN"
	fi
	RANDOM_CODE_LEN="$(echo "$RANDOM_CODE" | awk '{LEN=split($0, array, ""); print LEN}')"

	echo "$RANDOM_CODE" | awk "BEGIN{
		CODE=\"$RANDOM_CODE\"
		codes[0]=\"$RANDOM_LOWER\"
		codes[1]=\"$RANDOM_UPPER\"
		codes[2]=\"$RANDOM_DIGIT\"
		codes[3]=\"$RANDOM_SIGN\"
		LEN=$PASSWORD_LENGTH
		srand()
	} {
		split(\$0,map,\"\")
	} END{
		while (STRING==\"\") {
			for (i=1; i<=LEN; i++){
				w[i]=int($RANDOM_CODE_LEN*rand()+1)
			}
			for (i=1; i<=LEN; i++) {
				STRING=(STRING==\"\"?map[w[i]]:STRING\"\"map[w[i]])
			}
			_CODE=CODE
			for (x in codes) {
				FIND=codes[x]
				gsub(/(\\\$|\\^|\\+|\\*)/,\"\\\\\\\\&\",FIND)
				if (gsub(FIND,\"\",_CODE)) {
					FIND=\"[\"codes[x]\"]\"
					if (STRING!~FIND) {
						STRING=\"\"
						break
					}
				}
			}
		}
		print STRING
	}"
}

pkg_list_update() {
	echo "[PACKAGE] $LANG_UPDATEING_PACKAGE_LIST ..."
	case "$OS_PKG_MG" in
		"apt")
			apt-get update && PKG_LIST_UPDATED="1" && return 0
			;;
		"apk")
			apk update && PKG_LIST_UPDATED="1" && return 0
			;;
		"yum")
			yum update && PKG_LIST_UPDATED="1" && return 0
			;;
		"opkg")
			opkg update && PKG_LIST_UPDATED="1" && return 0
			;;
		"pacman"|"yay")
			PKG_LIST_UPDATED="1" && return 0
			;;
		"dnf")
			PKG_LIST_UPDATED="1" && return 0
			;;
		*)
			echo "$LANG_NOT_SUPPORT_FUNCTION"
			return 1
			;;
	esac
	return 0
}

pkg_install_minimal() {
	case "$OS_PKG_MG" in
		"apt")
			pkg_install "$1" "--no-install-recommends"
			;;
		*)
			pkg_install "$1"
	esac
}

pkg_install() {
	[ -z "$1" ] && return 1
	[ "$PKG_LIST_UPDATED" = "1" ] || pkg_list_update || {
		echo "${LANG_FAIL_UPDATE_PACKAGE_LIST}."
		return 1
	}
	PKG_INSTALL_PACKAGES="$1"
	PKG_INSTALL_OPTIONS="$2"
	echo "[PACKAGE] $LANG_INSTALLING $1"
	case "$OS_PKG_MG" in
		"apt")
			apt-get install -y $PKG_INSTALL_OPTIONS $PKG_INSTALL_PACKAGES
			;;
		"yum"|"dnf")
			$OS_PKG_MG $PKG_INSTALL_OPTIONS install -y $PKG_INSTALL_PACKAGES
			;;
		"pacman"|"yay")
			$OS_PKG_MG -Syu --noconfirm $PKG_INSTALL_PACKAGES
			;;
		"apk")
			apk add $PKG_INSTALL_PACKAGES $PKG_INSTALL_OPTIONS
			;;
		"opkg")
			opkg install $PKG_INSTALL_PACKAGES
			;;
		*)
			echo "$LANG_NOT_SUPPORT_FUNCTION" && return 1
			;;
	esac
	PKG_INSTALL_CODE="$?"
	[ "$PKG_INSTALL_CODE" = "0" ] && return 0
	echo "[ERR] ${LANG_FAIL_INSTALL_PACKAGE}:$PKG_INSTALL_CODE"
	return 1
}

pkg_remove() {
	case "$OS_PKG_MG" in
		"apt")
			apt-get -y remove $1
			apt-get -y autoremove >/dev/null 2>/dev/null
			;;
		"yum")
			yum -y remove $1
			;;
		"dnf")
			dnf -y remove $1
			;;
		"apk")
			apk del $1
			;;
		"opkg")
			opkg remove $1
			;;
		*)
			echo "$LANG_NOT_SUPPORT_FUNCTION" && return 1
			;;
	esac
}

pkg_match() {
	[ -z "$1" ] && return 1
	PKG_MATCH_VALUE=""
	args_match "$@" "--exclude" && PKG_MATCH_VALUE_EXCLUDE="$ARGS_MATCH_VALUE" || PKG_MATCH_VALUE_EXCLUDE=""
	case "$OS_PKG_MG" in
		"apt")
			PKG_MATCH_VALUE=$(apt-cache search "$1" | awk "\$1~/$1/{print \$1}")
			[ -z "$PKG_MATCH_VALUE_EXCLUDE" ] || {
				PKG_MATCH_VALUE=$(echo "$PKG_MATCH_VALUE" | awk "\$0!~/$PKG_MATCH_VALUE_EXCLUDE/ {print \$0}")
			}
			;;
		*)
			echo "$LANG_NOT_SUPPORT_FUNCTION" && return 1
			;;
	esac
	[ -z "$PKG_MATCH_VALUE" ] && return 1
	return 0
}

repo_init() {
	case "$OS_BASE" in
		"debian")
			REPO_ROOT="/etc/apt/sources.list.d"
			;;
		"rhel")
			REPO_ROOT="/etc/yum.repos.d"
			;;
		"alpine")
			REPO_ROOT="/etc/apk"
			;;
		"openwrt")
			REPO_ROOT="/etc/opkg"
			;;
	esac
}

has_repo() {
	[ -f "$1" ] || return 1
	grep -Eq "^[^#]" "$1" || return 1
	return 0
}

arch_enable_i386() {
	case "$OS_PKG_MG" in
		"apt")
			dpkg --add-architecture i386
			;;
	esac
}

arch_disable_i386() {
	case "$OS_PKG_MG" in
		"apt")
			apt-get remove --purge $(dpkg --get-selections | awk '/i386/{print $1}')
			dpkg --remove-architecture i386
			;;
	esac
}

repo_add_debian_ubuntu() {
	[ -z "$1" -o -z "$2" ] && return 1
	[ -z "$3" ] || {
		mkdir_p "/etc/apt/trusted.gpg.d"
		c_curl -skL -o "$APP_CACHE_DIR/${1}.gpg" "$3" || return 1
		if grep -Eiq '[-]+.*KEY' "$APP_CACHE_DIR/${1}.gpg"; then
			apt-key add "$APP_CACHE_DIR/${1}.gpg" || return 1
		else
			mv "$APP_CACHE_DIR/${1}.gpg" "/etc/apt/trusted.gpg.d/${1}.gpg"
		fi
	}
	[ -z "$4" ] || {
		mkdir_p "/etc/apt/preferences.d"
		echo "$4" > /etc/apt/preferences.d/99${1}
	}
	mkdir_p "$REPO_ROOT"
	echo "$2" > "$REPO_ROOT/${1}.list"
	# apt-add-repository "$2" || return 1
	return 0
}

repo_add_el_fc() {
	[ -z "$1" -o -z "$2" ] && return 1
	[ -z "$3" ] || {
		rpm --import "$3"
	}
	if echo "$2" | head -n1 | grep -Eq "^http"; then
		# yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
		rpm -Uvh "$2"
		has_repo "$REPO_ROOT/${1}.repo" || {
			echo "$LANG_FAIL_INSTALL_REPO" && return 1
		}
	else
		echo "$2" > "$REPO_ROOT/${1}.repo"
	fi
	[ -z "$4" ] || {
		has_package "yum-utils" || pkg_install "yum-utils"
		yum-config-manager --enable "$4" >/dev/null 2>&1 || return 1
	}
	return 0
}

repo_add() {
	repo_init
	REPO_URL=""
	REPO_KEY=""
	REPO_PREFERENCES=""
	REPO_DEFAULT=""
	case "$1" in
		"elrepo")
			[ "$OS_TYPE" = "el" -o "$OS_TYPE" = "fc" ] && {
				EL_REPO_VERSION=$(echo "$OS_VERSION"|awk -F'.' '{
					if ($1==6) print "6.el6";
					else if ($1==7) print "7.el7";
					else if ($1==8) print "8.el8";
					else if ($1==9) print "9.el9";
				}')
				[ -z "$EL_REPO_VERSION" ] && echo "$LANG_NOT_SUPPORT_FUNCTION" && return 1
				REPO_URL="https://www.elrepo.org/elrepo-release-${EL_REPO_VERSION}.elrepo.noarch.rpm"
				REPO_KEY="https://www.elrepo.org/RPM-GPG-KEY-elrepo.org"
				[ "$OS_RELEASE" = "oracle" ] && {
					yum install -y "https://dl.fedoraproject.org/pub/epel/epel-release-latest-$(echo "$OS_VERSION" | awk -F'.' '{print $1}').noarch.rpm"
					return $?
				} 
			}
			;;
		"backports")
			[ "$OS_BASE" = "debian" ] && {
				REPO_URL="$(cat <<-EOF
				deb http://deb.debian.org/debian ${OS_CODENAME}-backports main contrib non-free
				deb-src http://deb.debian.org/debian ${OS_CODENAME}-backports main contrib non-free
				EOF
				)"
			}
			;;
		"experimental")
			[ "$OS_BASE" = "debian" ] && {
				REPO_URL="deb http://deb.debian.org/debian experimental main"
			}
			;;
		"php")
			[ "$OS_BASE" = "debian" ] && {
				REPO_URL="deb https://packages.sury.org/php/ $OS_CODENAME main"
				REPO_KEY="https://packages.sury.org/php/apt.gpg"
			}
			;;
		"nodejs")
			[ "$OS_BASE" = "debian" ] && {
				REPO_URL="$(cat <<-EOF
				deb https://deb.nodesource.com/$NODEJS_VERSION_REPO $NODEJS_DISTRO main
				deb-src https://deb.nodesource.com/$NODEJS_VERSION_REPO $NODEJS_DISTRO main
				EOF
				)"
				REPO_KEY="https://deb.nodesource.com/gpgkey/nodesource.gpg.key"
			}
			;;
		"mongodb")
			[ "$OS_BASE" = "debian" ] && MONGODB_URL="http://repo.mongodb.org/apt/${OS_TYPE}/dists/${OS_CODENAME}/mongodb-org/"
			[ "$OS_BASE" = "rhel" ] && MONGODB_URL="http://repo.mongodb.org/yum/redhat/${OS_CODENAME}/mongodb-org/"
			while read MONGODB_VERSION_REPO
			do
				[ -z "$MONGODB_VERSION_REPO" ] || {
					c_curl -skL "https://www.mongodb.org/static/pgp/server-${MONGODB_VERSION_REPO}.asc" | grep -iq "KEY" && {
						MONGODB_VERSION="$MONGODB_VERSION_REPO"
						MONGODB_KEY_URL="https://www.mongodb.org/static/pgp/server-${MONGODB_VERSION_REPO}.asc"
						break
					}
				}
			done <<-EOF
			$(c_curl -skL --max-time 5 "$MONGODB_URL" | grep -Eo ">[0-9.]+<" | tr -d "<>" | sort -ru)
			EOF
			[ -z "$MONGODB_VERSION" ] && {
				echo "[ERROR] $LANG_CAN_NOT_GET Mongodb $LANG_VERSION"
				return 1
			}
			echo "MongoDB ${LANG_VERSION}: $MONGODB_VERSION"
			[ "$OS_BASE" = "debian" ] && {
				REPO_URL="deb http://repo.mongodb.org/apt/${OS_TYPE} ${OS_CODENAME}/mongodb-org/${MONGODB_VERSION} main"
				REPO_KEY="$MONGODB_KEY_URL"
			}
			[ "$OS_BASE" = "rhel" ] && {
				REPO_URL="$(cat <<-EOF
				[mongodb-org-${MONGODB_VERSION}]
				name=MongoDB Repository
				baseurl=https://repo.mongodb.org/yum/redhat/${OS_CODENAME}/mongodb-org/${MONGODB_VERSION}/$OS_ARCH/
				gpgcheck=1
				enabled=1
				gpgkey=$MONGODB_KEY_URL
				EOF
				)"
			}
			;;
		"wine")
			[ "$OS_BASE" = "debian" ] && {
				REPO_URL="deb https://dl.winehq.org/wine-builds/$OS_TYPE/ $OS_CODENAME main"
				REPO_KEY="https://dl.winehq.org/wine-builds/winehq.key"
			}
			arch_enable_i386
			;;
		"docker")
			[ "$OS_BASE" = "debian" ] && {
				REPO_URL="deb [arch=$(dpkg --print-architecture)] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
				REPO_KEY="https://download.docker.com/linux/ubuntu/gpg"
			}
			[ "$OS_BASE" = "rhel" ] && {
				REPO_URL="https://download.docker.com/linux/centos/docker-ce.repo"
				REPO_DEFAULT="docker-ce-nightly"
			}
			;;
		"nginx")
			[ "$OS_BASE" = "debian" ] && {
				REPO_URL="deb http://nginx.org/packages/mainline/${OS_TYPE} $OS_CODENAME nginx"
				REPO_KEY="https://nginx.org/keys/nginx_signing.key"
				REPO_PREFERENCES=$(cat <<-EOF
				Package: *
				Pin: origin nginx.org
				Pin: release o=nginx
				Pin-Priority: 900
				EOF
				)
			}
			[ "$OS_BASE" = "rhel" ] && {
				REPO_URL="$(cat <<-EOF
				[nginx-stable]
				name=nginx stable repo
				baseurl=http://nginx.org/packages/centos/\$releasever/\$basearch/
				gpgcheck=1
				enabled=1
				gpgkey=https://nginx.org/keys/nginx_signing.key
				module_hotfixes=true

				[nginx-mainline]
				name=nginx mainline repo
				baseurl=http://nginx.org/packages/mainline/centos/\$releasever/\$basearch/
				gpgcheck=1
				enabled=0
				gpgkey=https://nginx.org/keys/nginx_signing.key
				module_hotfixes=true
				EOF
				)"
				REPO_DEFAULT="nginx-mainline"
			}
			;;
		"teamviewer")
			[ "$OS_BASE" = "debian" ] && {
				REPO_URL="$(cat <<-EOF
				deb https://linux.teamviewer.com/deb stable main
				deb https://linux.teamviewer.com/deb preview main
				EOF
				)"
				REPO_KEY="https://download.teamviewer.com/download/linux/signature/TeamViewer2017.asc"
			}
			;;
	esac
	[ -z "$REPO_URL" ] && return 1
	case "$OS_BASE" in
		"debian")
			repo_add_debian_ubuntu "$1" "$REPO_URL" "$REPO_KEY" "$REPO_PREFERENCES" && return 0
			;;
		"rhel")
			repo_add_el_fc "$1" "$REPO_URL" "$REPO_KEY" "$REPO_DEFAULT" && return 0
			;;
	esac
	return 1
}

repo_remove() {
	repo_init
	_SUCCESS_="false"
	case "$OS_BASE" in
		"debian")
			[ -f "$REPO_ROOT/${1}.list" ] && rm -f "$REPO_ROOT/${1}.list" && _SUCCESS_="true";;
		"rhel")
			[ -f "$REPO_ROOT/${1}.repo" ] && rm -f "$REPO_ROOT/${1}.repo" && _SUCCESS_="true";;
	esac
	[ "$_SUCCESS_" = "true" ] && echo "$LANG_SUCCESS_TO_REMOTE_REPO $1" && return 0
	echo "$LANG_FAIL_TO_REMOTE_REPO"
	return 1
}

add_user() {
	[ -z "$USER_PWD" ] && return 1
	if [ "$USER_NAME" = "root" ]; then
		[ "$USER_PWD" = "0" ] && return 0
		echo "root:${USER_PWD}"|chpasswd
	else
		useradd  -m -U -s "/bin/bash" $USER_NAME
		USER_HOME_PATH="/home/$USER_NAME"
		echo "${USER_NAME}    ALL=(ALL) ALL" >> "/etc/sudoers"
		echo "${USER_NAME}:${USER_PWD}"|chpasswd
		usermod -aG wheel $USER_NAME
		[ "$SET_ROOT_PWD" = "1" ] && echo "root:${USER_PWD}"|chpasswd
	fi
}

install_ssh() {
	require_pkg "openssh-server"
	SSHD_CONF="/etc/ssh/sshd_config"
	[ -f "$SSHD_CONF" ] || return 1
	SSHD_PORT_CURR=$(grep -Eo 'Port\s*[1-9][0-9]*' "$SSHD_CONF" | grep -Eo '[0-9]+')
	[ -z "$SSH_PORT" ] && {
		[ -z "$SSHD_PORT_CURR" ] && SSH_PORT="22" || SSH_PORT=$SSHD_PORT_CURR
	}
	cp "$SSHD_CONF" "${SSHD_CONF}.bak"
	sed -e '/^[Pp]ort[^s]/d' -e '/PasswordAuthentication/d' -e '/PermitRootLogin/d' -e '/UsePAM/d' -e '/TCPKeepAlive/d' -e '/ClientAliveInterval/d' -e '/ClientAliveCountMax/d' -i "$SSHD_CONF"
	cat <<-EOF >> "$SSHD_CONF"
	Port $SSH_PORT
	PasswordAuthentication yes
	PermitRootLogin yes
	UsePAM yes
	TCPKeepAlive yes
	ClientAliveInterval 360
	ClientAliveCountMax 20
	EOF
	if [ "$HOST_TYPE" = "docker" ]; then
		require_pkg "supervisor"
		supervisor_ssh
		mkdir_p "/run/sshd"
	else
		$INITD_ROOT/ssh restart
	fi
}

nginx_addon() {
	mkdir_p "$NGINX_ADDON"
	case "$1" in
		"error_page")
			cat <<-EOF > "$NGINX_ADDON/error_page.conf"
			error_page 404 /404.html;
			location = /404.html {
			    root /usr/share/nginx/html;
			}

			error_page 500 502 503 504 /50x.html;
			location = /50x.html {
			    root /usr/share/nginx/html;
			}
			EOF
			;;
		"webdav")
			cat <<-EOF > "$NGINX_ADDON/webdav.conf"
			dav_methods PUT DELETE MKCOL COPY MOVE;
			dav_ext_methods   PROPFIND OPTIONS;
			create_full_put_path  on;
			dav_access    user:rw group:rw all:rw;
			# auth_basic "restricted";
			# auth_basic_user_file /etc/nginx/htpasswd;
			EOF
			;;
		"eva")
			# <code> Download Eva ... </code>
			cat <<-EOF > "$NGINX_ADDON/eva.conf"
			location /eva/ {
			    alias /www/eva/;
			}
			#location /dl/ {
			#    alias /data/download/;
			#    autoindex on;
			#    add_before_body /eva/header.html;
			#}
			EOF
			;;
		"jquery")
			DL_URL=$(c_curl -sk https://jquery.com/download/|grep -Eo '"[^"]+\.jquery[^"]*\.min\.js"'|tr -d '"'|head -n1)
			mkdir_p "$WWW_ROOT/jquery"
			[ -z "$DL_URL" ] || download_file "$DL_URL" "$WWW_ROOT/jquery/jquery.min.js"
			cat <<-EOF > "$NGINX_ADDON/jquery.conf"
			location /jquery/ {
			    alias $WWW_ROOT/jquery/;
			}
			EOF
			nginx_addon_enable "jquery"
			;;
		"bootstrap")
			DL=$(c_curl -sSkL https://github.com/twbs/bootstrap/releases|grep -Eo "/[^\"]+-dist.zip"|head -n1)
			[ -z "$DL" ] && return 1
			download_file "https://github.com$DL" "/tmp/bootstrap.zip" || return 1
			rm -rf "$WWW_ROOT/bootstrap"
			c_unzip "/tmp/bootstrap.zip" -d "$WWW_ROOT/bootstrap"
			rm -f "/tmp/bootstrap.zip"
			[ $(ls "$WWW_ROOT/bootstrap"|grep ".*"|wc -l) = 1 ] && {
				BOOTSTRAP_NAME=$(ls "$WWW_ROOT/bootstrap")
				cp -rf "$WWW_ROOT/bootstrap/$BOOTSTRAP_NAME/"* "$WWW_ROOT/bootstrap"
				rm -rf "$WWW_ROOT/bootstrap/$BOOTSTRAP_NAME/"
			}
			cat <<-EOF > "$NGINX_ADDON/bootstrap.conf"
			location /bootstrap/ {
			    alias $WWW_ROOT/bootstrap/;
			}
			EOF
			nginx_addon_enable "bootstrap"
			;;
		"font-awesome")
			github_clone "https://github.com/FortAwesome/Font-Awesome.git" "$WWW_ROOT/font-awesome"
			cat <<-EOF > "$NGINX_ADDON/font-awesome.conf"
			location /font-awesome/ {
			    alias $WWW_ROOT/font-awesome/;
			}
			EOF
			nginx_addon_enable "font-awesome"
			;;
		"flag")
			rm -rf "$WWW_ROOT/flag" && github_clone "https://github.com/lipis/flag-icon-css.git" "$WWW_ROOT/flag"
			cat <<-EOF > "$NGINX_ADDON/flag.conf"
			location /flag/ {
			    alias $WWW_ROOT/flag/;
			}
			EOF
			nginx_addon_enable "flag"
			;;
	esac
}

nginx_addon_enable() {
	[ -z "$1" ] && return 1
	grep -Eiq "${1}\.conf" "$NGINX_ADDON/default" 2>/dev/null || echo "include $NGINX_ADDON/${1}.conf;" >> "$NGINX_ADDON/default"
	NGINX_RESTART="1"
}

nginx_default() {
	# General
	cat <<-EOF > "$NGINX_CONF_ROOT/nginx.conf"
	user $WWW_USER;
	worker_processes auto;
	pid /run/nginx.pid;
	worker_rlimit_nofile 100000;

	include /etc/nginx/modules-enabled/*.conf;

	events {
	    worker_connections 2048;
	    multi_accept on;
	    use epoll;
	}

	http {
	    sendfile on;
	    tcp_nopush on;
	    tcp_nodelay on;
	    server_tokens off;

	    access_log /var/log/nginx/access.log;
	    error_log /var/log/nginx/error.log;

	    keepalive_timeout 10;

	    client_header_timeout 10;
	    client_body_timeout 10;

	    reset_timedout_connection on;
	    send_timeout 10;

	    limit_conn_zone \$binary_remote_addr zone=addr:5m;
	    limit_conn addr 100;

	    types_hash_max_size 2048;

	    include $NGINX_CONF_ROOT/mime.types;
	    default_type application/octet-stream;
	    charset UTF-8;

	    ssl_protocols TLSv1 TLSv1.1 TLSv1.2; # Dropping SSLv3, ref: POODLE
	    ssl_prefer_server_ciphers on;

	    gzip on;
	    gzip_disable "msie6";

	    # gzip_static on;
	    gzip_proxied any;
	    gzip_min_length 1000;
	    gzip_comp_level 4;
	    gzip_types text/plain
	               text/css
	               application/json
	               application/x-javascript
	               text/xml
	               application/xml
	               application/xml+rss
	               text/javascript;

	    open_file_cache max=100000 inactive=20s;
	    open_file_cache_valid 30s;
	    open_file_cache_min_uses 2;
	    open_file_cache_errors on;

		include $NGINX_CONF_ROOT/conf.d/*.conf;
		include $NGINX_CONF_ROOT/sites-enabled/*;
	}
	EOF

	# Default
	cat <<-EOF > "$NGINX_SITES/default"
	server {
	    ssl_protocols TLSv1.2;
	    ssl_ciphers 'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-CHACHA20-POLY1305:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA256';
	    ssl_prefer_server_ciphers on;

	    listen 80 default_server;
	    server_name localhost;
	    root $WWW_ROOT/html;
	    index index.html index.htm index.php;
	    # add_header Access-Control-Allow-Origin *;
	    location / {
	        try_files \$uri \$uri/ =404;
	    }
	    include $NGINX_ADDON/default;
	    include $NGINX_ADDON/error_page.conf;
	}
	EOF
	ln -sf "/etc/nginx/sites-available/default" "/etc/nginx/sites-enabled"

	NGINX_RESTART="1"
}

nginx_supervisor() {
	[ "$HOST_TYPE" = "docker" ] || return 1
	supervisor_add "nginx" --command "nginx -c /etc/nginx/nginx.conf" --user "$WWW_USER"
}

install_nginx() {
	pkg_install "$PKG_NGINX"
	has_package "nginx" || return 1
	get_www_user

	mkdir_p "$WWW_ROOT/html"
	mkdir_p "$NGINX_ADDON"
	mkdir_p "/etc/nginx/sites-available"
	mkdir_p "/etc/nginx/sites-enabled"

	[ -f "/usr/share/nginx/html/index.html" ] && cp "/usr/share/nginx/html/index.html" "$WWW_ROOT/html"

	chown -R "${WWW_USER}:${WWW_USER}" "$WWW_ROOT"

	nginx_default
	nginx_addon "error_page"
	nginx_addon "webdav"
	# nginx_addon "eva"
	# nginx_addon "jquery"
	# nginx_addon "bootstrap"
	# nginx_addon "font-awesome"
	# nginx_addon "flag"

	service nginx status >/dev/null 2>/dev/null && service nginx restart || nginx_supervisor
}

fcgiwrap_nginx() {
	mkdir_p "$NGINX_ADDON"
	cat <<-EOF > "$NGINX_ADDON/fcgiwrap.conf"
	location /cgi-bin/ {
	    # fastcgi_pass unix:/var/run/fcgiwrap.socket;
	    # fastcgi_pass 127.0.0.1:9000;
	    fastcgi_pass $FCGIWRAP_PORT;
	    include /etc/nginx/fastcgi_params;
	    fastcgi_param SCRIPT_FILENAME $(echo "\$document_root\$fastcgi_script_name");
	}
	EOF
	nginx_addon_enable "fcgiwrap"
}

fcgiwrap_supervisor() {
	supervisor_add "fcgiwrap" --command "$(which fcgiwrap) -f -c 5 -s tcp:$FCGIWRAP_PORT" --user "$WWW_USER"
	return $?
}

install_fcgiwrap() {
	FCGIWRAP_PORT="unix:/var/run/fcgiwrap.socket"
	require_pkg "fcgiwrap supervisor"
	get_www_user

	mkdir_p "$HTML_ROOT/cgi-bin"
	cat <<-EOF > "$HTML_ROOT/cgi-bin/test"
	#!/bin/bash

	echo "Content-type: text/html"
	echo ""
	[ "\$REQUEST_METHOD" = "POST" ] && read QUERY_STRING
	[ -z "$QUERY_STRING" ] && echo "Hello Word!"
	EOF
	chmod +x "$HTML_ROOT/cgi-bin/test"

	chown -R "${WWW_USER}:${WWW_USER}" "$HTML_ROOT/cgi-bin"

	service fcgiwrap status >/dev/null 2>/dev/null || [ -f "$INITD_ROOT/fcgiwrap" ] || {
		FCGIWRAP_PORT="127.0.0.1:9000"
		fcgiwrap_supervisor
	}
	fcgiwrap_nginx
}

php_phpmyadmin() {
	PHP_PHPMYADMIN_URL=$(c_curl -sSL https://www.phpmyadmin.net/downloads/ 2>/dev/null|grep -Eo 'http[^"]+phpMyAdmin-[0-9.]+-english.tar.(gz|bz2)'|sort -ru|head -n1)
	[ -z "$PHP_PHPMYADMIN_URL" ] && return 1
	PHP_PHPMYADMIN_NAME=$(echo "$PHP_PHPMYADMIN_URL"|sed -E 's|.*/||')
	PHP_PHPMYADMIN_FILE="/tmp/$PHP_PHPMYADMIN_NAME"
	c_curl -SL "$PHP_PHPMYADMIN_URL" -o "$PHP_PHPMYADMIN_FILE" || return 1
	[ -f "$PHP_PHPMYADMIN_FILE" ] && {
		rm -rf "$PHP_PHPMYADMIN_ROOT"
		tar -xf "$PHP_PHPMYADMIN_FILE" -C "$WWW_ROOT"
		rm -f "$PHP_PHPMYADMIN_FILE"
		PHP_PHPMYADMIN_EXTRACT="$(ls -1 "$WWW_ROOT"|grep -Ei "phpmyadmin-"|head -n1)"
		[ -z "$PHP_PHPMYADMIN_EXTRACT" ] || mv "$WWW_ROOT/$PHP_PHPMYADMIN_EXTRACT" "$PHP_PHPMYADMIN_ROOT"
	}
}

php_opcache() {
	find /usr|grep opcache.so &>/dev/null || return 1
	cat <<-EOF > "$PHP_FPM_CONF_ROOT/fpm/conf.d/10-opcache.ini"
	zend_extension=opcache.so
	opcache.enable=1
	opcache.enable_cli=1
	opcache.fast_shutdown=1
	opcache.memory_consumption=${OPCACHE_MEM_SIZE:-128}
	opcache.interned_strings_buffer=16
	opcache.max_accelerated_files=5413
	opcache.revalidate_freq=60
	EOF
}

php_apcu() {
	find /usr|grep apcu.so &>/dev/null || return 1
	cat <<-EOF > "$PHP_FPM_CONF_ROOT/fpm/conf.d/20-apcu.ini"
	extension=apcu.so
	apc.enabled=1
	apc.shm_size=${APC_SHM_SIZE:-128M}
	apc.ttl=7200
	EOF
}

php_fpm() {
	# php-cgi process will restart with error SIGSEGV SIGBUS 
	cat <<-EOF >> "$PHP_FPM_PHP_INI"
	emergency_restart_threshold = 10
	emergency_restart_interval = 1m
	process_control_timeout = 10s
	EOF
}

php_nginx() {
	mkdir_p "$NGINX_ADDON"
	cat <<-EOF > "$NGINX_ADDON/php.conf"
	location ~ \.php\$ {
	    fastcgi_split_path_info ^(.+.php)(/.*)\$;
	    try_files \$uri =404;
	    fastcgi_keep_conn on;
	    include /etc/nginx/fastcgi_params;
	    fastcgi_pass unix:/run/php/php7.0-fpm.sock;
	    fastcgi_index index.php;
	    fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
	}
	EOF

	# PHP & PHPMyAdmin
	cat <<-EOF > "$NGINX_ADDON/php_phpmyadmin.conf"
	location /phpmyadmin {
	    alias $WWW_ROOT/phpmyadmin;
	}
	location ~ \.php\$ {
	    fastcgi_pass unix:/run/php/php7.0-fpm.sock;
	    fastcgi_index index.php;
	    include /etc/nginx/fastcgi_params;
	    set \$fastcgi_script_root \$document_root;
	    if (\$fastcgi_script_name ~ /phpmyadmin/(.+.php)\$) {
	        set \$fastcgi_script_root $WWW_ROOT;
	    }
	    fastcgi_param SCRIPT_FILENAME \$fastcgi_script_root\$fastcgi_script_name;
	}
	EOF
	nginx_addon_default "php_phpmyadmin"
}

php_supervisor() {
	[ "$DOCKER" = '1' ] || return 1
	supervisor_add "php" --command "php-fpm7.1" --user "$WWW_USER" --priority 100
	return $?
}

install_php() {
	[ -z "$1" ] || {
		pkg_match "^php$1" --exclude="-dbgsym" || return 1
		PKG_PHP=$PKG_MATCH_VALUE
	}
	pkg_install "$PKG_PHP" || return 1
	PHP_VERSION=$(php -v|grep -Eoi "php\s*[0-9]+\.[0-9]+"|sed -E "s/php\s*//i")
	[ -z "$PHP_VERSION" ] && PHP_VERSION=$(ls /etc/php/|tail -n1)
	[ -z "$PHP_VERSION" ] && echo "[ERR] $LANG_NOT_GET_PHP_VERSION" && return 1
	if [ -d "/etc/php/$PHP_VERSION" ]; then
		PHP_CONF_ROOT="/etc/php/$PHP_VERSION"
	else
		echo "[ERR] $LANG_NOT_GET_PHP_VERSION" && return 1
	fi
	while read FILE
	do
		[ -f "$FILE" ] && {
			grep -Eiq "^listen\s*=\s*" "$FILE" && {
				PHP_PORT=$(grep -Ei "^listen\s*=\s*"|tr -d " "|awk -F'=' '{print $2}')
			}
			[ -z "$PHP_PORT" ] || break
		}
	done <<-EOF
	$(find "$PHP_CONF_ROOT" -type f -name "*.conf")
	EOF
	PHP_FPM_PHP_INI="$PHP_CONF_ROOT/fpm/php.ini"
	PHP_FPM_PHP_INI_CLI="$PHP_CONF_ROOT/cli/php.ini"

	c_curl -sS "https://getcomposer.org/installer" | php -- --install-dir=$LOCAL_ROOT/bin --filename=composer

	sed -Ei -e "s/;?cgi.fix_pathinfo=1/cgi.fix_pathinfo=0/" \
	-e "s|;?date\.timezone.*|date.timezone=$TIMEZONE|" \
	-e "s/.*memory_limit.*/memory_limit=$PHP_MEMORY_LIMIT/" \
	-e "s/.*upload_max_filesize.*/upload_max_filesize=$PHP_UPLOAD_MAX_FILESIZE/" \
	-e "s/.*max_file_uploads.*/max_file_uploads=$PHP_MAX_FILE_UPLOADS/" \
	-e "s/.*post_max_size.*/post_max_size=$PHP_POST_MAX_SIZE/" \
	-e "s/.*error_reporting\s*=.*/error_reporting=E_ALL/" \
	-e "s/.*display_errors\s*=.*/display_errors=On/" \
	-e "s/^;?error_log\s*=.*/error_log=\/var\/logs\/php_errors.log/" \
	-e "s/;?daemonize\s*=.*/daemonize=yes/" \
	"$PHP_FPM_PHP_INI"

	sed -Ei -e "s|;?date\.timezone.*|date.timezone=$TIMEZONE|" \
	"$PHP_FPM_PHP_INI_CLI"

	php_opcache

	php_apcu

	PHP_INIT=$(ls /etc/init.d|grep -Eo "php.*fpm.*")
	[ -z "$PHP_INIT" ] || /etc/init.d/$PHP_INIT restart

	# echo "binlog-format = MIXED">mysql

	echo "<?php phpinfo(); ?>" > "$WWW_ROOT/index.php"

	php_phpmyadmin &

	php_nginx
	php_supervisor
}

mysql_supervisor() {
	[ "$DOCKER" = "1" ] || return 1
	supervisor_add "mysql" --command "mysqld" --user "$WWW_USER" --priority 100
	return $?
}

install_mysql() {
	[ -z "$MYSQL_PWD" ] && MYSQL_PWD="$USER_PWD_DEFAULT"
	# MySQL Auto Set Password
	echo "mysql-server mysql-server/root_password password $MYSQL_PWD"|debconf-set-selections
	echo "mysql-server mysql-server/root_password_again password $MYSQL_PWD"|debconf-set-selections
	require_pkg "$PKG_MYSQL"

	mysql_supervisor
}

install_nmp() {
	install_nginx
	install_mysql
	install_php "7.2"
}

install_nvm() {
	curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/master/install.sh | bash || return 1
	export NVM_DIR="$HOME/.nvm"
	[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
	return 0
}

install_nodejs() {
	# unofficial-builds: https://unofficial-builds.nodejs.org/download/release/
	NODEJS_SCRIPT_URL=""
	NODEJS_VERSION_ALL=$(c_curl -skL https://nodejs.org/|grep -Eoi 'data-version="[^"]+"'|awk -F'=' '{gsub("[\"v]","",$2);print $2}')
	NODEJS_VERSION_A=$(echo "$NODEJS_VERSION_ALL"|head -n1)
	NODEJS_VERSION_B=$(echo "$NODEJS_VERSION_ALL"|tail -n1)
	NODEJS_VERSION_LTS=$NODEJS_VERSION_A
	NODEJS_VERSION_LATEST=$NODEJS_VERSION_B
	[ $(echo "$NODEJS_VERSION_A" | grep -Eo "^[0-9]+") -gt $(echo $NODEJS_VERSION_B | grep -Eo "^[0-9]+") ] && {
		NODEJS_VERSION_LTS="$NODEJS_VERSION_B" && NODEJS_VERSION_LATEST="$NODEJS_VERSION_A"
	}
	NODEJS_VERSION="$NODEJS_VERSION_LTS"
	[ "$1" = "latest" ] && NODEJS_VERSION="$NODEJS_VERSION_LATEST"
	NODEJS_VERSION_MAIN=$(echo "$NODEJS_VERSION" | awk -F'.' '{print $1}')
	case "$OS_BASE" in
		"debian")
			NODEJS_SCRIPT_URL="https://deb.nodesource.com/setup_lts.x"
			[ "$1" = "latest" ] && NODEJS_SCRIPT_URL="https://deb.nodesource.com/setup_${NODEJS_VERSION_MAIN}.x"
			;;
		"rhel")
			NODEJS_SCRIPT_URL="https://rpm.nodesource.com/setup_lts.x"
			[ "$1" = "latest" ] && NODEJS_SCRIPT_URL="https://rpm.nodesource.com/setup_${NODEJS_VERSION_MAIN}.x"
			;;
		"arch")
			pkg_install nodejs npm; return $?
			;;
		"alpine")
			pkg_install nodejs npm; return $?
			;;
	esac
	[ -z "$NODEJS_SCRIPT_URL" ] && return 1
	c_curl -fsSL $NODEJS_SCRIPT_URL | bash - && pkg_list_update && pkg_install "$PKG_NODEJS"
	return $?
}

install_golang() {
	GOLANG_SITE_URL="https://go.dev"
	GOLANG_ROOT="$LOCAL_ROOT/go"
	GOLANG_URLS=$(curl -skL "$GOLANG_SITE_URL/dl/" | grep -Eo 'href="[^"]+linux-[^"]+\.tar\.gz"' | sed -E 's/href="(.*)"/\1/')
	GOLANG_VERSION=$(echo "$GOLANG_URLS" | head -n1 | grep -Eo 'go[0-9.]+[0-9]+' | tr -d 'go')
	GOLANG_URLS=$(echo "$GOLANG_URLS" | grep -E "$GOLANG_VERSION" | grep "$(get_pkg_arch "i386:386" "x86_64:amd64" "aarch64:arm64")" | head -n1)
	[ -z "$GOLANG_URLS" ] && echo "$LANG_FAIL_TO_DOWNLOAD" && return 1
	GOLANG_FILE_NAME=$(echo "$GOLANG_URLS" | awk -F'/' '{print $NF}')
	GOLANG_FILE_CACHE="$APP_CACHE_DIR/$GOLANG_FILE_NAME"
	c_curl -kL "$GOLANG_SITE_URL$GOLANG_URLS" -o "$GOLANG_FILE_CACHE" && {
		tar xzf "$GOLANG_FILE_CACHE" -C "$LOCAL_ROOT" && {
			ln -sf "$GOLANG_ROOT/bin/"* "/usr/bin/"
		}
	}
	rm -rf "$GOLANG_FILE_CACHE" 2>/dev/null
	# list GOOS/GOARCH
	# go tool dist list
	go version && return 0
	return 1
}

install_mongodb() {
	repo_add "mongodb" || return 1
	pkg_list_update && require_pkg "$PKG_MONGODB" && return 0
}

install_rethinkdb() {
	build_rethinkdb
}

install_redis() {
	build_redis
}

install_acme() {
	require_pkg "cron"
	c_curl -kL "https://get.acme.sh" | sh
	# acme.sh --home /www/.acme.sh --issue -d example.com -d www.example.com --standalone -k ec-256 --server letsencrypt
}

qbittorrent_init() {
	QBITTORRENT_WEBUI_PORT=${QBITTORRENT_WEBUI_PORT:-30000}
	QBITTORRENT_PROFILE=${QBITTORRENT_PROFILE:-/data}
}

qbittorrent_nginx() {
	qbittorrent_init
	mkdir_p "$NGINX_ADDON"
	cat <<-EOF > "$NGINX_ADDON/qbittorrent.conf"
	location /bt/ {
	    proxy_pass         http://127.0.0.1:$QBITTORRENT_WEBUI_PORT/;
	    proxy_http_version 1.1;	
	    proxy_set_header   Host               127.0.0.1:$QBITTORRENT_WEBUI_PORT;
	    proxy_set_header   X-Forwarded-Host   \$http_host;
	    proxy_set_header   X-Forwarded-For    \$remote_addr;
	    proxy_cookie_path  /                  "/; Secure";
	}
	EOF
	nginx_addon_enable "qbittorrent"
}

qbittorrent_supervisor() {
	qbittorrent_init
	supervisor_add "qbittorrent" --command "$(which qbittorrent-nox) --profile=${QBITTORRENT_PROFILE} --webui-port=$QBITTORRENT_WEBUI_PORT"
	return $?
}

install_qbittorrent() {
	_FAILED_=1
	_BIN_PATH_="/usr/bin/qbittorrent-nox"
	_DL_URL_=$(github_releases_url "c0re100/qBittorrent-Enhanced-Edition" | grep "$(get_pkg_arch "i386:386" "")-linux.*\.zip")
	[ -z "$_DL_URL_" ] && return 1
	# 	download_file "http://hg.nginx.org/njs/archive/tip.tar.gz" "$NGINX_SOURCE_MODULE_ROOT" || return 1
	_PKG_TMP_ROOT_="$APP_CACHE_DIR/qbittorrent"
	mkdir_p "$_PKG_TMP_ROOT_"
	# tar_extract_remove "$NGINX_SOURCE_MODULE_ROOT/$DOWNLOAD_FILE_NAME" "$NGINX_SOURCE_MODULE_ROOT" || return 1
	download_file "$_DL_URL_" "$_PKG_TMP_ROOT_" && {
		c_unzip -d "$_PKG_TMP_ROOT_" "$_PKG_TMP_ROOT_/$DOWNLOAD_FILE_NAME" && mv "$_PKG_TMP_ROOT_/qbittorrent-nox" "$_BIN_PATH_" && chmod +x "$_BIN_PATH_" && _FAILED_=0
	}
	rm -rf "$_PKG_TMP_ROOT_"
	[ "$_FAILED_" = "0" ] && {
		"$_BIN_PATH_" --version
		qbittorrent_supervisor
		qbittorrent_nginx
	} || echo $LANG_"$LANG_FAIL_INSTALL_PACKAGE: qbittorrent"
	return $_FAILED_
}

aliyundrive_webdav_supervisor() {
	supervisor_add "aliyundrive-webdav" --command "aliyundrive-webdav --auto-index --no-trash -p 8080 --auth-user ${WEBDAV_AUTH_USER} --auth-password ${WEBDAV_AUTH_PASSWORD} -r ${REFRESH_TOKEN}" 
	return $?
}

install_aliyundrive_webdav() {
	_FAILED_=1
	if has_package "python3-pip"; then
		pip install -U aliyundrive-webdav && _FAILED_=0
	elif has_package "snap"; then
		snap install aliyundrive-webdav && _FAILED_=0
	else
		_ARCH_=$(get_pkg_arch "i386:i686")
		_DL_URL_=$(github_releases_url "messense/aliyundrive-webdav" | grep "linux.*tar.gz$" | grep "$_ARCH_")
		_PKG_TMP_ROOT_="$APP_CACHE_DIR/aliyundrive_webdav"
		rm -rf "$_PKG_TMP_ROOT_"; mkdir_p "$_PKG_TMP_ROOT_"
		[ -z "$_DL_URL_" ] && return 1
		download_file "$_DL_URL_" "$_PKG_TMP_ROOT_" && {
			tar_extract_remove "$_PKG_TMP_ROOT_/$DOWNLOAD_FILE_NAME" "$_PKG_TMP_ROOT_" && {
				[ -f "$_PKG_TMP_ROOT_/aliyundrive-webdav" ] && mv "$_PKG_TMP_ROOT_/aliyundrive-webdav" /usr/bin/ && _FAILED_=0
			}
		}
	fi
	[ "$_FAILED_" = "0" ] && aliyundrive-webdav -V && aliyundrive_webdav_supervisor && return 0
	echo "[ERR] ${LANG_FAIL_INSTALL_PACKAGE}:aliyundrive-webdav"
	return 1
}

alist_supervisor() {
	mkdir -p /etc/alist
	supervisor_add "alist" --command "alist server --data /etc/alist"
	return $?
}

install_alist() {
	_ARCH_=$(get_pkg_arch "i386:386" "x86_64:amd64" "aarch64:arm64")
	echo "$_ARCH_" | grep -q 'mips' && [ "$(get_endian)" = "le" ] && _ARCH_="${_ARCH_}le"
	_DL_URL_=$(github_releases_url "alist-org/alist" | grep "linux.*${_ARCH_}.*tar.gz$")
	is_musl && _DL_URL_=$(echo "$_DL_URL_" | grep 'musl' | head -n1) || _DL_URL_=$(echo "$_DL_URL_" | grep -v 'musl' | head -n1)
	[ -z "$_DL_URL_" ] && return 1
	_PKG_TMP_ROOT_="$APP_CACHE_DIR/alist"
	rm -rf "$_PKG_TMP_ROOT_"; mkdir_p "$_PKG_TMP_ROOT_"
	download_file "$_DL_URL_" "$_PKG_TMP_ROOT_" && {
		tar_extract_remove "$_PKG_TMP_ROOT_/$DOWNLOAD_FILE_NAME" "$_PKG_TMP_ROOT_" && \
			$_PKG_TMP_ROOT_/alist version >&2 && \
			mv "$_PKG_TMP_ROOT_/alist" /usr/bin/ && \
			alist_supervisor && \
			return 0
	}
	echo "[ERR] ${LANG_FAIL_INSTALL_PACKAGE}:alist"
	return 1
}

filebrowser_nginx() {
	cat <<-EOF
	location $FILEBROWSER_BASEURL/ {
		client_max_body_size 1024m;
		proxy_http_version 1.1;
		proxy_set_header Upgrade         \$http_upgrade;
		proxy_set_header Connection      "Upgrade";
		proxy_set_header Host            \$http_host;
		proxy_set_header X-Real-IP       \$remote_addr;
		proxy_set_header X-Forward-For   \$proxy_add_x_forwarded_for;
		proxy_set_header X-Forward-Proto \$scheme;
		proxy_redirect off; 
		proxy_pass http://127.0.0.1:${FILEBROWSER_PORT};
	}
	EOF
}

filebrowser_conf() {
	cat <<-EOF
	{
		"port": ${FILEBROWSER_PORT},
		"noAuth": false,
		"baseURL": "$FILEBROWSER_BASEURL",
		"address": "127.0.0.1",
		"alternativeReCaptcha": false,
		"reCaptchaKey": "",
		"reCaptchaSecret": "",
		"database": "$HOME/database.db",
		"log": "stdout",
		"plugin": "",
		"scope": "$HOME/cloud",
		"allowCommands": true,
		"allowEdit": true,
		"allowNew": true,
		"commands": [
			"ls",
			"df"
		]
	}
	EOF
}

install_filebrowser() {
	FILEBROWSER_PORT=${FILEBROWSER_PORT:-6920}
	FILEBROWSER_BASEURL=${FILEBROWSER_BASEURL:-/fb}
	FILEBROWSER_ROOT=$HOME
	c_curl -fsSL "https://raw.githubusercontent.com/filebrowser/get/master/get.sh" | bash
	# https://filebrowser.org/cli/filebrowser
	# filebrowser -r /path/to/your/files -b /fb -a 127.0.0.1 -p 6920
}

mail_send() {
	echo "Mail body text" | mailx -v -A gmail -a file -s "Mail subject" -S smtp-auth-user=username@gmail.com -S smtp-auth-password=s0m3p@zzW0rD "recipient@some.com"
}

postfix_reload() {
	postfix reload
}

postfix_conf() {
	postconf -e "smtpd_tls_security_level = may"
	postconf -e "smtp_tls_security_level = may"
	postconf -e "home_mailbox = Maildir/"
	postconf -e "smtpd_recipient_restrictions ="
	postconf -e "message_size_limit=2048000000"
	postfix_reload
}

postfix_relay_gmail() {
	POSTFIX_CONF_SASL="$POSTFIX_CONF_ROOT/sasl_passwd"
	POSTFIX_CRT="/etc/ssl/certs/ca-certificates.crt"
	echo "[smtp.gmail.com]:587    username@gmail.com:password" > "$POSTFIX_CONF_SASL"
	cat <<-EOF > "$POSTFIX_CONF_MAIN"
	relayhost = [smtp.gmail.com]:587
	smtp_use_tls = yes
	smtp_sasl_auth_enable = yes
	smtp_sasl_security_options =
	smtp_sasl_password_maps = hash:$POSTFIX_CONF_SASL
	smtp_tls_CAfile = $POSTFIX_CRT
	EOF
	postmap "$POSTFIX_CONF_SASL"
	postfix_reload
}

postfix_relay_account() {
	# Google App Password
	# https://myaccount.google.com/apppasswords
	# "Select App" > "Other" > "Generate"
	cat <<-EOF > ~/.mailrc
	account gmail {
	    set smtp-use-starttls
	    set ssl-verify=ignore
	    set smtp-auth=login
	    set smtp=smtp://smtp.gmail.com:587
	    set from="noreply@gmail.com(Your Real Name)"
	    set smtp-auth-user=noreply@gmail.com
	    set smtp-auth-password=16bytepassword
	    set ssl-verify=ignore
	}
	account aol {
	    set smtp-use-starttls
	    set ssl-verify=ignore
	    set smtp-auth=login
	    set smtp=smtp://smtp.aol.com:587
	    set from="noreply@aol.com(Your Real Name)"
	    set smtp-auth-user=noreply@aol.com
	    set smtp-auth-password=16bytepassword
	    set ssl-verify=ignore
	}
	EOF
}

install_postfix() {
	require_pkg "postfix heirloom-mailx"
	postfix_relay_account
	postfix_conf
}

install_build_tools() {
	require_pkg_compile
}

aria2_nginx() {
	mkdir_p "$NGINX_ADDON"
	cat <<-EOF > "$NGINX_ADDON/aria2.conf"
	location /aria2/ {
	    alias $ARIA2_WEB_ROOT/;
	    index index.html;
	}

	location /jsonrpc {
	    proxy_pass http://127.0.0.1:6800/jsonrpc;
	    proxy_redirect off;
	    proxy_http_version 1.1;
	    proxy_set_header Upgrade \$http_upgrade;
	    proxy_set_header Connection "upgrade";
	}
	EOF
	NGINX_RESTART="1"
}

aria2_supervisor() {
	supervisor_add "aria2" --command "aria2c --conf-path=$ARIA2_CONF" --directory "$DOWNLOAD_ROOT" --user "$WWW_USER"
	return $?
}

aria2_conf() {
	mkdir_p "$ARIA2_CONF_ROOT"
	[ -f "$ARIA2_SESSION" ] || {
		touch "$ARIA2_SESSION" && chmod 666 "$ARIA2_SESSION"
	}
	[ -f "$ARIA2_CONF" ] && {
		[ -z "$(cat $ARIA2_CONF)" ] || return 1
	}
	cat <<-EOF > "$ARIA2_CONF"
	# HTTPS
	# rpc-secure=true
	# rpc-certificate=/path/to/cer
	# rpc-private-key=/path/to/key
	dir=$DOWNLOAD_ROOT
	disk-cache=32M
	# on-download-complete=/conf/a2/a2-on-complete.sh
	save-session=$ARIA2_SESSION
	input-file=$ARIA2_SESSION
	file-allocation=trunc
	log-level=warn
	# peer-id-prefix=-TR2770-
	# user-agent=Transmission/2.77
	enable-http-pipelining=true
	max-concurrent-downloads=5
	max-connection-per-server=16
	max-download-limit=0
	split=16
	#lowest-speed-limit=0
	min-split-size=10M
	continue=true
	max-overall-download-limit=0
	max-overall-upload-limit=1K
	seed-time=0
	enable-rpc=true
	rpc-listen-all=true
	rpc-allow-origin-all=true
	rpc-listen-port=6800
	bt-max-peers=100
	seed-time=0
	EOF
	aria2_bt_tracker
	[ "$ARIA2_COMPILED" = "1" ] && aria2_max_speed
}

aria2_bt_tracker() {
	get_bt_tracker || return 1
	BT_TRACKER="bt-tracker="$(echo $BT_TRACKER|sed 's| |,|g')
	sed -i "/bt-tracker/d" "$ARIA2_CONF"
	echo "$BT_TRACKER" >> "$ARIA2_CONF"
	echo "- $(string_with_args "$LANG_UPDATED_BT_TRACKER" "aria2")"
	return 0
}

aria2_restart() {
	[ -z "$(pidof aria2c)" ] && return 1
	supervisor_status "aria2" >/dev/null && {
		[ "$SUPERVISOR_STATUS" = "RUNNING" ] && supervisor_restart "aria2"
		return 0
	}
	return 1
}

aria2_web() {
	github_download_branch "mayswind/AriaNg-DailyBuild" || return 1
	rm -rf "$ARIA2_WEB_ROOT"
	c_unzip -qo "$GITHUB_MASTER_OUTPUT" -d "$WWW_ROOT"
	rm -f "$GITHUB_MASTER_OUTPUT"
	mv "$WWW_ROOT/$GITHUB_MASTER_NAME" "$ARIA2_WEB_ROOT"
	chown -R "${WWW_USER}:${WWW_USER}" "$ARIA2_WEB_ROOT"
	echo "[OK] $LANG_UPDATED Aria2 Web-UI."
}

aria2_max_speed() {
	[ -f "$ARIA2_CONF" ] || return 1
	sed -e 's/max-connection-per-server=.*/max-connection-per-server=256/' -e 's/^split=.*/split=512/' -i "$ARIA2_CONF"
}

install_aria2() {
	echo "[PACKAGE] $LANG_INSTALLING Aria2"
	require_pkg "aria2 supervisor"
	get_www_user

	[ -d "$DOWNLOAD_ROOT" ] || {
		mkdir_p "$DOWNLOAD_ROOT"
		chown -R "${WWW_USER}:${WWW_USER}" "$DOWNLOAD_ROOT"
		chmod -R 666 "$DOWNLOAD_ROOT"
		ln -sf "$DOWNLOAD_ROOT" "$WWW_ROOT/downloads"
	}

	aria2_nginx
	aria2_supervisor
	aria2_conf
	aria2_web
}

qbittorrent_bt_tracker() {
	get_bt_tracker || return 1
	BT_TRACKER=$(echo "$BT_TRACKER"|tr '\n' '|'|sed -E -e 's/\|$//' -e 's/\|/\\\\n/g')
	sed -Ei "s|Bittorrent\\\\TrackersList=.*|Bittorrent\\\\TrackersList=$BT_TRACKERS|" "$QBITTORRENT_CONF"
	echo "- $(string_with_args "$LANG_UPDATED_BT_TRACKER" "qBittorrent")"
}

install_firefox_latest() {
	if [ "$OS_ARCH" = "x86_64" -o "$OS_ARCH" = "i386" ]; then
		FIREFOX_ARCH=$(get_pkg_arch "i386:linux" "x86_64:linux64")
		FIREFOX_ROOT="/usr/share/firefox"
		FIREFOX_BIN="$FIREFOX_ROOT/firefox-bin"
		FIREFOX_UPDATE_CACHE="$APP_CACHE_DIR/firefox-latest.tar.bz2"
		check_cache_root
		curl -kL -o "$FIREFOX_UPDATE_CACHE" "https://download.mozilla.org/?product=firefox-latest&os=${FIREFOX_ARCH}&lang=en-US" && {
			rm -rf "$FIREFOX_ROOT"
			tar -xf "$FIREFOX_UPDATE_CACHE" -C "$APP_CACHE_DIR" && {
				mv "$APP_CACHE_DIR/firefox" "$FIREFOX_ROOT"
				chmod +x "$FIREFOX_BIN"
				ln -sf "$FIREFOX_BIN" "/usr/bin/firefox"
				[ -d "/etc/alternatives/" ] && {
					ln -sf "$FIREFOX_BIN" "/usr/bin/x-www-browser"
					ln -sf "$FIREFOX_BIN" "/usr/bin/www-browser"					
				}
				cat <<-EOF > "$APPLICATION_ROOT/firefox.desktop"
				[Desktop Entry]
				Name=Firefox
				Comment=Web Browser
				GenericName=Web Browser
				X-GNOME-FullName=Firefox Web Browser
				Exec=$FIREFOX_BIN %u
				Terminal=false
				X-MultipleArgs=false
				Type=Application
				Icon=$FIREFOX_ROOT/browser/chrome/icons/default/default128.png
				Categories=Network;WebBrowser;
				MimeType=text/html;text/xml;application/xhtml+xml;application/xml;application/vnd.mozilla.xul+xml;application/rss+xml;application/rdf+xml;image/gif;image/jpeg;image/png;x-scheme-handler/http;x-scheme-handler/https;
				StartupWMClass=Firefox
				StartupNotify=true
				EOF
				return 0
			}
		}
		rm -f "$FIREFOX_UPDATE_CACHE" 2>/dev/null
	else
		echo "$LANG_NOT_SUPPORT_OS"
	fi
	return 1
}

install_speedtest() {
	require_pkg "python3-pip" || return 1
	[ -z "$(which speedtest-cli)" ] && pip3 install speedtest-cli
}

install_frp() {
	[ -z "$FRP_VERSION" ] && FRP_VERSION="$1"
	
	FRP_URL=$(github_releases_url "fatedier/frp" "$FRP_VERSION" | grep "linux_$(get_pkg_arch "x86_64:amd64" "i386:386" "aarch64:arm64")")
	[ -z "$FRP_URL" ] && log_err "$LANG_FAIL_TO_GET frp" && return 1
	FRP_VERSION=$(echo "$FRP_URL" | sed -E 's|.*/download/([^/]+)/.*|\1|g')
	FRP_FILE_NAME=$(echo "$FRP_URL" | awk -F'/' '{print $NF}')
	FRP_OUTPUT="$APP_CACHE_DIR/$FRP_FILE_NAME"
	FRP_DIR="$FRP_ROOT/$FRP_VERSION"
	c_curl -skL -o "$FRP_OUTPUT" "$FRP_URL" && {
		mkdir_p "$FRP_DIR"
		mkdir_p "$FRP_CONF_ROOT"
		mkdir_p "$FRP_DIR/systemd"
		tar_extract "$FRP_OUTPUT" "$FRP_DIR" '(frpc|frps)$' && {
			link_as_bin "$FRP_DIR" "^(frpc|frps)$"
		}
		tar_extract "$FRP_OUTPUT" "$FRP_DIR" '\.ini$'
		tar_extract "$FRP_OUTPUT" "$FRP_DIR/systemd" '/systemd/'
	}
	rm -f "$FRP_OUTPUT"
}

install_n2n() {
	require_pkg "supervisor"
}

install_novnc() {
	has_package "nginx" || return 1
	
	rm -rf "$VNC_NOVNC_ROOT"
	github_clone "https://github.com/novnc/noVNC.git" "$VNC_NOVNC_ROOT"
	github_clone "https://github.com/novnc/websockify.git" "$VNC_NOVNC_ROOT/utils/websockify"

	vnc_novnc_nginx
	vnc_novnc_supervisor
}

vnc_novnc_nginx() {
	[ -d "$NGINX_ADDON" ] || mkdir -p "$NGINX_ADDON"
	cat <<-EOF > "$NGINX_ADDON/novnc.conf"
	location = /vnc/ {
        rewrite .* /vnc/vnc.html last;
	}

	location /vnc/ {
        proxy_pass http://127.0.0.1:$VNC_HTTP_PORT/;
	}

	location = /websockify {
	    proxy_http_version 1.1;
	    proxy_set_header Upgrade \$http_upgrade;
	    proxy_set_header Connection "upgrade";
	    proxy_pass http://127.0.0.1:$VNC_HTTP_PORT;
	}
	EOF
	nginx_addon_enable "novnc"
}

vnc_novnc_supervisor() {
	supervisor_add "novnc" "$(cat <<-EOF
	[program:novnc]
	priority=25
	directory=$VNC_NOVNC_ROOT/
	command=$VNC_NOVNC_ROOT/utils/novnc_proxy --vnc localhost:$VNC_PORT --listen $VNC_HTTP_PORT
	user=$USER_NAME
	autostart=true
	autorestart=true
	stopsignal=TERM
	stdout_logfile=/var/log/novnc.log
	redirect_stderr=true
	stopasgroup=true
	EOF
	)"
}

vnc_supervisor() {
	if get_displays; then
		VNC_DISPLAY_ID=$(echo "$DISPLAYS" | tr -d ':' | sort | tail -n1)
		VNC_DISPLAY_ID=":$((VNC_DISPLAY_ID+1))"
	else
		VNC_DISPLAY_ID=":1"
	fi
	supervisor_add "vnc" "$(cat <<-EOF
	[program:xvfb]
	priority=10
	directory=/
	command=/usr/bin/Xvfb $VNC_DISPLAY_ID -s 0 -p 0 -screen 0 ${VNC_DISPLAY_RESOLUTION}x${VNC_DISPLAY_DEPTH}
	user=$USER_NAME
	autostart=true
	autorestart=true
	stopsignal=TERM
	stdout_logfile=/var/log/xvfb.log
	redirect_stderr=true

	[program:x11vnc]
	priority=20
	directory=/
	command=x11vnc -display $VNC_DISPLAY_ID -xkb -forever -shared -repeat -bg -rfbauth $VNC_KEY -rfbport $VNC_PORT
	user=$USER_NAME
	autostart=true
	autorestart=true
	stopsignal=TERM
	stdout_logfile=/var/log/x11vnc.log
	redirect_stderr=true
	EOF
	)"
}

install_vnc() {
	require_pkg "supervisor"
	pkg_install "$PKG_VNC" || {
		echo "$LANG_FAIL_INSTALL_PACKAGE vnc" && return 1
	}

	VNC_DISPLAY_RESOLUTION="${VNC_DISPLAY_RESOLUTION:-1280x768}"

	[ -z "$VNC_PWD" ] || x11vnc -storepasswd "$VNC_PWD" "$VNC_KEY"

	cat <<-EOF >$HOME/.vnc/xstartup
	#!/bin/sh
	dbus-launch /usr/bin/startplasma-x11
	EOF

	vnc_supervisor
	install_novnc
}

install_realvnc_for_plasma() {
	# wget https://downloads.realvnc.com/download/file/vnc.files/VNC-Server-7.1.0-Linux-ARM64.deb
	# wget https://downloads.realvnc.com/download/file/vnc.files/VNC-Server-6.10.1-Linux-ARM64.deb
	vnclicense -add "VKUPN-MTHHC-UDHGS-UWD76-6N36A"
# 	systemctl enable vncserver-x11-serviced
# 	systemctl start vncserver-x11-serviced
	sudo cat <<-EOF >/etc/vnc/xstartup.custom
	#!/bin/sh
	DESKTOP_SESSION=plasma
	export DESKTOP_SESSION
	startplasma-x11
	vncserver-virtual -kill \$DISPLAY
	EOF
	sudo chmod +x xstartup.custom
	sudo echo "su $USER -c \"vncserver-virtual -geometry 1600x900 :1\"" >> /etc/rc.local
}

desktop_app() {
	require_pkg "$PKG_FONT $PKG_INPUT $PKG_BROWSER $PKG_ARCHIVER"
}

desktop_xfce() {
	require_pkg "supervisor"
	pkg_install "$PKG_XFCE" || {
		echo "$LANG_FAIL_INSTALL_PACKAGE $PKG_XFCE"
		return 1
	}
	desktop_app
	desktop_supervisor "xfce" "/usr/bin/xfce4-session"
	echo "exec startxfce4" > "$USER_HOME_PATH/.xinitrc"
}

desktop_lxde() {
	require_pkg "supervisor"
	pkg_install "$PKG_LXDE" || {
		echo "$LANG_FAIL_INSTALL_PACKAGE $PKG_LXDE"
		return 1
	}
	desktop_app
	[ -z "$(which lxsession)" ] || desktop_supervisor "lxqt" "$(which lxsession)"
	echo "exec startlxde" > "$USER_HOME_PATH/.xinitrc"
}

desktop_lxqt() {
	require_pkg "supervisor"
	pkg_install "$PKG_LXQT" || {
		echo "$LANG_FAIL_INSTALL_PACKAGE $PKG_LXQT"
		return 1
	}
	desktop_app
	[ -z "$(which lxqt-session)" ] || desktop_supervisor "lxqt" "$(which lxqt-session)"
	echo "exec startlxqt" > "$USER_HOME_PATH/.xinitrc"
}

desktop_supervisor() {
	supervisor_add "$1" "$(cat <<-EOF
	[program:$1]
	priority=15
	directory=$USER_HOME_PATH
	command=$2
	user=$USER_NAME
	autostart=true
	autorestart=true
	stopsignal=TERM
	environment=DISPLAY=":1",HOME="$USER_HOME_PATH"
	stdout_logfile=/var/log/$1.log
	redirect_stderr=true
	stopasgroup=true
	EOF
	)"
}

install_desktop() {
	# https://wiki.manjaro.org/index.php/Install_Desktop_Environments
	case "$1" in
		"xfce")
			desktop_xfce
			;;
		"lxde")
			desktop_lxde
			;;
		"lxqt")
			desktop_lxqt
			;;
		*)
			cat <<-EOF
			$APP_NAME desktop [ xfce / lxde / lxqt ]
			EOF
			;;
	esac
}

install_fcitx() {
	grep -q 'fcitx' || {
		sudo cat <<-EOF >>/etc/environment
		# Fcitx5
		GTK_IM_MODULE=fcitx
		QT_IM_MODULE=fcitx
		XMODIFIERS=@im=fcitx
		SDL_IM_MODULE=fcitx
		GLFW_IM_MODULE=ibus
		EOF
	}
	# fcitx5-configtool
}

install_wine() {
	has_package "wine" && {
		log_err "$(string_with_args "$LANG_ALREADY_INSTALLED" "wine")"
		return 1
	}
	repo_add "wine"
	pkg_install "$PKG_WINE $PKG_WINE_EXTRA"
}

install_wine_devel() {
	PKG_WINE="winehq-devel"
	install_wine
}

install_wine_staging() {
	PKG_WINE="winehq-staging"
	install_wine
}

install_heroku() {
	has_package "nodejs" || {
		log_err "$(string_with_args "$LANG_HAVE_TO_INSTALL_APP_FIRST" "nodejs")"
		return 1
	}
	curl https://cli-assets.heroku.com/install.sh | sh
}

install_docker() {
	case "$OS_BASE" in
		"debian")
			pkg_remove "docker docker-engine docker.io containerd runc";;
		"rhel")
			pkg_remove "docker docker-client docker-client-latest docker-common docker-latest docker-latest-logrotate docker-logrotate docker-engine";;
	esac
	repo_add "docker" && pkg_list_update && require_pkg "$PKG_DOCKER" && return 0
	return 0
}

install_vscode_server() {
	# https://github.com/coder/code-server
	curl -fsSL https://code-server.dev/install.sh | sh
}

install_youtube_dl() {
	python3 -m pip install -U yt-dlp
}

install_zsh() {
	pkg_install zsh zsh-autosuggestions zsh-syntax-highlighting zsh-theme-powerlevel10k
	# Font (Optional)
	pkg_install ttf-meslo-nerd-font-powerlevel10k
	chsh -s /usr/bin/zsh
	# Need to run again for root user
	# sudo chsh -s /usr/bin/zsh
	grep -q '# ZSH' /etc/environment || cat <<-EOF >> /etc/environment
	# ZSH
	unset \$SHELL
	\$SHELL=/usr/bin/zsh
	EOF
	grep -q '# PLUGIN' ~/.zshrc || cat <<-EOF >> ~/.zshrc
	# PLUGIN
	source /usr/share/zsh/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
	source /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh
	source /usr/share/zsh-theme-powerlevel10k/powerlevel10k.zsh-theme
	EOF
}

kernel_update() {
	KERNEL_APP_CACHE_DIR="$APP_CACHE_DIR/kernel"
	[ -d "$KERNEL_APP_CACHE_DIR" ] || mkdir -p "$KERNEL_APP_CACHE_DIR"
	case "$OS_TYPE" in
		"ubuntu")
			# KERNEL_UPDATE_URL="https://mirrors.edge.kernel.org/debian/pool/main/l/linux/"
			KERNEL_UPDATE_URL="http://kernel.ubuntu.com/~kernel-ppa/mainline/"
			KERNEL_VERSION_LATEST=$(c_curl -sSL "$KERNEL_UPDATE_URL"|sed -E '/-rc[0-9]*/d'|grep -Eo 'v[4-9]\.[0-9.]+(-rc[0-9]+)?'|sort|tail -n1)
			[ -z "$KERNEL_VERSION_LATEST" ] && echo "$LANG_NOT_FOUND_LATEST_KERNEL" && return 1
			[ "$KERNEL_VERSION_INSTALLED" = "$KERNEL_VERSION_LATEST" ] && {
				echo "$LANG_KERNEL_IS_UP_TO_DATE" && return 0
			}
			input_yes_no "KERNEL_UPDATE_CONFIRM" "$LANG_CONFIRM_UPDATE_KERNEL ($KERNEL_VERSION_INSTALLED -> $KERNEL_VERSION_LATEST)" "y"
			[ "$KERNEL_UPDATE_CONFIRM" = "1" ] && {
				KERNEL_UPDATE_URL="${KERNEL_UPDATE_URL}${KERNEL_VERSION_LATEST}/"
				KERNEL_UPDATE_URL_HTML=$(c_curl -sSL "$KERNEL_UPDATE_URL")
				# KERNEL_NAME_HEADERS=$(echo "$KERNEL_UPDATE_URL_HTML"|grep -Eo "linux-headers-[^\"]+generic[^\"]+$(get_pkg_arch).deb"|sort -u|head -n1)
				# KERNEL_NAME_MODULES=$(echo "$KERNEL_UPDATE_URL_HTML"|grep -Eo "linux-modules-[^\"]+generic[^\"]+$(get_pkg_arch).deb"|sort -u|head -n1)
				# KERNEL_NAME_IMAGE=$(echo "$KERNEL_UPDATE_URL_HTML"|grep -Eo "linux-image-[^\"]+generic[^\"]+$(get_pkg_arch).deb"|sort -u|head -n1)
				while read FILE_NAME
				do
					[ -z "$FILE_NAME" ] || {
						echo "[DL] $FILE_NAME ..."
						c_curl -skL "${KERNEL_UPDATE_URL}$FILE_NAME" -o "$KERNEL_APP_CACHE_DIR/${FILE_NAME}"
					}
				done<<-EOF
				$(echo "$KERNEL_UPDATE_URL_HTML"|grep -Eo "linux-[^\"]+($(get_pkg_arch "x86_64:amd64")|all)[^\"]*\.deb"|sort -u|grep -v "(lowlatency|headers)")
				EOF
				dpkg -i $KERNEL_APP_CACHE_DIR/*.deb && {
					[ -z "$(which update-grub)" ] || update-grub
					KERNEL_VERSION_INSTALLED="$KERNEL_VERSION_LATEST"
					REBOOT=1
					rm -rf "$KERNEL_APP_CACHE_DIR"
				}
			}
			;;
		"debian")
			repo_add "backports" || return 1
			repo_add "experimental" || return 1
			pkg_list_update
			KERNEL_VERSION_ALL=$(apt list 2>/dev/null| grep -E "linux-image-[0-9.]{3,16}" | sed -E "/-(dbg|cloud)/d" | awk -F'/' '{print $1}')
			KERNEL_VERSION_LATEST=$(echo "$KERNEL_VERSION_ALL" | awk -F'-' '{print $3}' | sort -u | awk -F'.' 'BEGIN{A=0;B=0} {if($1"."$2*1 > A) {A=$1"."$2; if ($3 >= B) B=$3}} END{print A"."B}')
			[ "$KERNEL_VERSION_INSTALLED" = "$KERNEL_VERSION_LATEST" ] && {
				echo "$LANG_KERNEL_IS_UP_TO_DATE" && return 0
			}
			KERNEL_VERSION_ALL=$(echo "$KERNEL_VERSION_ALL" | grep -E "linux-image-$KERNEL_VERSION_LATEST")
			[ $(echo "$KERNEL_VERSION_ALL" | wc -l) -gt 1 ] && KERNEL_VERSION_ALL=$(echo "$KERNEL_VERSION_ALL" | sed -E "/unsigned/d" | head -n1)
			KERNEL_PACKAGE_NAME="$KERNEL_VERSION_ALL"
			[ -z "$KERNEL_VERSION_ALL" ] && return 1
			input_yes_no "KERNEL_UPDATE_CONFIRM" "$LANG_CONFIRM_UPDATE_KERNEL ($KERNEL_VERSION_INSTALLED -> $KERNEL_VERSION_LATEST)" "y"
			[ "$KERNEL_UPDATE_CONFIRM" = "1" ] && pkg_install "$KERNEL_PACKAGE_NAME" && KERNEL_VERSION_INSTALLED="$KERNEL_VERSION_LATEST" && REBOOT=1
			;;
		"el"|"fc")
			repo_add "elrepo" || return 1
			# [ -z "$(which yum-config-manager)" ] && pkg_install "yum-utils"
			# yum-config-manager --enable elrepo-kernel 2>/dev/null
			pkg_install "kernel-ml kernel-ml-devel" "--enablerepo=elrepo-kernel"
			[ -f "/boot/grub/grub.conf" ] && sed -i 's/^default=.*/default=0/g' "/boot/grub/grub.conf"
			[ -z "$(which grub2-set-default)" ] || grub2-set-default 0
			;;
		*)
			echo "$LANG_NOT_SUPPORT_FUNCTION"
			return 1
			;;
	esac
	return 0
}

kernel_get_release() {
	KERNEL_HTML=$(curl -skL 'https://www.kernel.org/')
	KERNEL_RELEASE_LIST=$(echo "$KERNEL_HTML" | tr -d '\n' | sed -E -e 's/<tr/\n<tr/g' -e 's/> +</></g' | grep -E '<tr.*tar.(gz|xz)')
	KERNEL_RELEASE_LIST=$(echo "$KERNEL_RELEASE_LIST" | sed -E -e 's/<\/?(tr|strong|span)[^>]*>//g' -e 's/<\/td><td>/@@@@/g' -e 's/<\/?td[^>]*>//g' -e 's/\[([A-Za-z]+)\]//g' -e 's/\[.*href="([^"]+tar.(gz|xz))".*\]/\1/g')
	KERNEL_LATEST_RELEASE=$(echo "$KERNEL_RELEASE_LIST" | head -n1 | grep -Eo '>[0-9.]+<' | tr -d '<>')
	KERNEL_RELEASE_LIST=$(echo "$KERNEL_RELEASE_LIST" | awk -F'@@@@' '$3~/[0-9]{4}/{gsub(/:/,"",$1); gsub(/ /,"",$2); print $1" "$2" "$3" "$4}')
}

kernel_remote() {
	kernel_get_release
	echo "Latest Release: $KERNEL_LATEST_RELEASE"
	echo "$KERNEL_RELEASE_LIST"
}

kernel_build() {
	KERNEL_VERSION="$1"
	echo "$KERNEL_VERSION" | grep -Eq '^[0-9][0-9.]+$' || {
		echo "Not a valid kernel version: $KERNEL_VERSION"
		return 1
	}
	KERNEL_VERSION_MAIN=$(echo $KERNEL_VERSION | grep -Eo '[0-9]+' | head -n1)
	KERNEL_TMP_DIR="$APP_CACHE_DIR/kernel"
	download_file https://cdn.kernel.org/pub/linux/kernel/v${KERNEL_VERSION_MAIN}.x/linux-${KERNEL_VERSION}.tar.xz "$KERNEL_TMP_DIR" || return 1
	tar_extract "$DOWNLOAD_FILE_NAME" "$KERNEL_TMP_DIR" || return 1
	cd $KERNEL_TMP_DIR/$TAR_EXTRACT_ROOT || return 1
	# Enable 5G AP
	# drivers/net/wireless/intel/iwlwifi/iwl-nvm-parse.c
	# curl https://github.com/pagxir/linux-patch/commit/819ac8cc0a4fdee32f2b9a881bced045a671af73
	[ -f /proc/config.gz ] && zcat /proc/config.gz >> .config
	make menuconfig
	make -j$(nproc)
	sudo make modules_install
	sudo make install
	sudo su
	cp /boot/vmlinuz "/boot/vmlinuz-${KERNEL_VERSION}-[arch]"
	# /etc/mkinitcpio.d
	sudo mkinitcpio -p "linux${KERNEL_VERSION}"
	# Update GRUB
}

sysctl_reload() {
	sysctl -p >/dev/null 2>&1 && return 0
	return 1
}

sysctl_enable() {
	rm -f "$SYSCTL_FILE"
	[ -f "$SYSCTL_CONF" ] && {
		file_remove_lines "$SYSCTL_CONF" "$SYSCTL_MARK_BEGIN" "$SYSCTL_MARK_END"
		SYSCTL_FILE="$SYSCTL_CONF"
	}
	SYSCTL_CONTENT="$SYSCTL_KEY = $SYSCTL_VALUE"
	[ -z "$SYSCTL_CONF_EXT" ] || SYSCTL_CONTENT=$(cat <<-EOF
	$SYSCTL_CONTENT
	$SYSCTL_CONF_EXT
	EOF
	)
	cat <<-EOF >> "$SYSCTL_FILE"
	$SYSCTL_MARK_BEGIN
	$SYSCTL_CONTENT
	$SYSCTL_MARK_END
	EOF
	if [ -f "$SYSCTL_CONF" ]; then
		sysctl_reload && {
			[ "$(sysctl $SYSCTL_KEY | awk -F'=' '{gsub(" ","",$2); print $2}')" = "$SYSCTL_VALUE" ] || {
				echo "$LANG_FAIL_TO_ENABLE $SYSCTL_TITLE_UPPER"
				return 1
			}
		}
	else
		REBOOT="1"
	fi
	echo "$LANG_SUCCESS_TO_ENABLE $SYSCTL_TITLE_UPPER"
	return 0
}

sysctl_disable() {
	[ -f "$SYSCTL_CONF" ] && {
		grep -Eq "^${SYSCTL_MARK_BEGIN}\$" "$SYSCTL_CONF" && {
			file_remove_lines "$SYSCTL_CONF" "$SYSCTL_MARK_BEGIN" "$SYSCTL_MARK_END" && sysctl_reload
		}
	}
	[ -f "$SYSCTL_FILE" ] && {
		rm -f "$SYSCTL_FILE"
		REBOOT="1"
	}
	echo "$LANG_SUCCESS_TO_DISABLE $SYSCTL_TITLE_UPPER"
	return 0
}

lib_apply() {
	LD_SO_MATCH="0"
	grep -Eq "^$1" "$LD_SO_CONF" && LD_SO_MATCH="1"
	cat $LD_SO_CONF_D/* | grep -Eq "^$1" && LD_SO_MATCH="1"
	[ "$LD_SO_MATCH" = "1" ] || echo "$1" >> "$LD_SO_CONF"
	ldconfig
}

install_package() {
	_INSTALL_PACKAGE_=$(echo "$1" | awk -F':' '{print $1}')
	_INSTALL_PACKAGE_VERSION_=$(echo "$1" | awk -F':' '{print $2}')
	case "$_INSTALL_PACKAGE_" in
		"ssh")
			USER_NAME="root"
			input_user_pwd
			input_ssh_port
			add_user
			install_ssh
			;;
		"nginx")
			install_nginx
			;;
		"fcgiwrap")
			install_fcgiwrap
			;;
		"php")
			install_php
			;;
		"php7.2")
			install_php "7.2"
			;;
		"php7.3")
			install_php "7.3"
			;;
		"mysql")
			input_mysql_pwd
			install_mysql
			;;
		"nmp")
			input_mysql_pwd
			install_nmp
			;;
		"nvm")
			install_nvm
			;;
		"nodejs")
			install_nodejs
			;;
		"nodejs-latest")
			install_nodejs "latest"
			;;
		"golang")
			install_golang
			;;
		"mongodb")
			install_mongodb
			;;
		"rethinkdb")
			install_rethinkdb
			;;
		"redis")
			install_redis
			;;
		"acme")
			install_acme
			;;
		"postfix")
			install_postfix
			;;
		"aria2")
			install_aria2
			;;
		"qbittorrent")
			install_qbittorrent
			;;
		"aliyundrive-webdav"|"aliyun")
			install_aliyundrive_webdav
			;;
		"alist")
			install_alist
			;;
		"filebrowser")
			install_filebrowser
			;;
		"vnc")
			VNC_KEY="$USER_HOME_PATH/x11vnc_passwd"
			input_vnc_display_resolution
			input_vnc_pwd
			install_vnc
			;;
		"novnc")
			install_novnc
			;;
		"speedtest")
			install_speedtest
			;;
		"frp")
			install_frp "$_INSTALL_PACKAGE_VERSION_"
			;;
		"firefox-latest")
			install_firefox_latest
			;;
		"desktop")
			input_desktop_env
			install_desktop "$DESKTOP_ENV"
			;;
		"wine")
			install_wine
			;;
		"wine-devel")
			install_wine_devel
			;;
		"wine-staging")
			install_wine_staging
			;;
		"heroku")
			install_heroku
			;;
		"docker")
			install_docker
			;;
		"vscode-server")
			install_vscode_server
			;;
		"build-tools")
			install_build_tools
			;;
		*)
			return 255
			;;
	esac
}

build_aria2() {
	require_pkg_compile
	github_clone "https://github.com/aria2/aria2.git" "aria2" && cd aria2 && {
		LINE=$(cat src/OptionHandlerFactory.cc|grep -n 'TEXT_CHECK_CERTIFICATE'|sed -E 's|:.*||')
		[ -z "$LINE" ] || LINE=$(($LINE+1))

		cat src/OptionHandlerFactory.cc | \
		# MAX_CONNECTION_PER_SERVER
		sed -E "s|\"1\", 1, 16, 'x'|\"16\", 1, -1, 'x'|" | \
		# MAX_CONCURRENT_DOWNLOADS
		sed -E "s|\"5\", 1, -1, 'j'|\"128\", 1, -1, 'j'|" | \
		# MIN_SPLIT_SIZE
		sed -E "s|\"5\", 1, -1, 'j'|\"128\", 1, -1, 'j'|" | \
		# MIN_SPLIT_SIZE
		sed -E "s|\"20M\", 1_m, 1_g, 'k'|\"1M\", 1_k, 1_g, 'k'|" | \
		# CONNECT_TIMEOUT
		sed -E "s|\"60\", 1, 600|\"30\", 1, 600|" | \
		# PIECE_LENGTH
		sed -E "s|\"1M\", 1_m, 1_g|\"1M\", 1_k, 1_g|" | \
		# RETRY_WAIT
		sed -E "s|TEXT_RETRY_WAIT, \"0\", 0, 600|TEXT_RETRY_WAIT, \"2\", 0, 600|" | \
		# SPLIT
		sed -E "s|TEXT_SPLIT, \"5\", 1, -1, 's'|TEXT_SPLIT, \"128\", 1, -1, 's'|" | \
		# CONTINUE
		sed -E "s|TEXT_CONTINUE, A2_V_FALSE|TEXT_CONTINUE, A2_V_TRUE|" | \
		# CHECK_CERTIFICATE
		sed -E "${LINE}s|A2_V_TRUE|A2_V_FALSE|" \
		>./src/OptionHandlerFactory.cc_

		mv -f ./src/OptionHandlerFactory.cc_ ./src/OptionHandlerFactory.cc

		autoreconf -i && ./configure && make -j$(nproc) && make install && {
			aria2_max_speed
			ARIA2_COMPILED="1" && rm -rf aria2 && return 0
		}
	}
	return 1
}

build_common() {
	# --skip-config --keep-source --no-install
	[ -z "$SOURCE_APP" -o -z "$SOURCE_URL" ] && return 1
	SOURCE_FILE_NAME=$(get_basename "$SOURCE_URL")
	SOURCE_VERSION=$(echo "$SOURCE_FILE_NAME" | grep -Eo "[0-9](\.[0-9])+")
	SOURCE_ROOT="$APP_CACHE_DIR/$SOURCE_APP"
	SOURCE_FILE="$SOURCE_ROOT/$SOURCE_FILE_NAME"
	rm -rf "$SOURCE_ROOT"
	mkdir_p "$SOURCE_ROOT"
	download_file "$SOURCE_URL" "$SOURCE_FILE" || return 1
	tar_extract_remove "$SOURCE_FILE" "$SOURCE_ROOT" || return 1
	[ -z "$TAR_EXTRACT_ROOT" ] || cp -rf "$SOURCE_ROOT/$TAR_EXTRACT_ROOT/"* "$SOURCE_ROOT"
	cd "$SOURCE_ROOT" || return 1
	args_match "$@" "--skip-config" || {
		./configure $SOURCE_OPTION_CONFIGURE || return 1
	}
	make -j $(get_cpu_cores) $SOURCE_OPTION_MAKE || return 1
	args_match "$@" "--no-install" || {
		make ${SOURCE_OPTION_INSTALL:-install} || return 1
	}
	args_match "$@" "--keep-source" || rm -rf "$SOURCE_ROOT"
	return 0
}

build_openresty() {
	SOURCE_APP="openresty"
	SOURCE_URL=$(c_curl -skL "https://openresty.org/en/download.html" | grep -Eo 'href="[^"]+\.tar\.gz"' | sed -E -e 's/href=//' -e 's/"//g' | head -n1)
	SOURCE_OPTION_CONFIGURE=""
	SOURCE_OPTION_MAKE=""
	SOURCE_OPTION_INSTALL=""
	build_common --no-install --keep-source
}

build_redis() {
	SOURCE_APP="redis"
	SOURCE_PREFIX="$LOCAL_ROOT/$SOURCE_APP"
	SOURCE_URL="http://download.redis.io/redis-stable.tar.gz"
	SOURCE_OPTION_CONFIGURE=""
	SOURCE_OPTION_MAKE=""
	SOURCE_OPTION_INSTALL="PREFIX=$SOURCE_PREFIX install"
	build_common || return 1
	link_as_bin "$SOURCE_PREFIX/bin" ".*"
	rm -rf "$SOURCE_ROOT"
	return 0
}

build_rethinkdb() {
	SOURCE_APP="rethinkdb"
	SOURCE_PREFIX="$LOCAL_ROOT/$SOURCE_APP"
	SOURCE_URL="https://download.rethinkdb.com/dist/rethinkdb-2.3.6.tgz"
	SOURCE_OPTION_CONFIGURE="--allow-fetch"
	SOURCE_OPTION_MAKE=""
	SOURCE_OPTION_INSTALL="PREFIX=$SOURCE_PREFIX install"
	build_common || return 1
	link_as_bin "$SOURCE_PREFIX/bin" ".*"
	rm -rf "$SOURCE_ROOT"
	return 0
}

build_libluajit() {
	SOURCE_APP="libluajit"
	LUAJIT_URL="http://luajit.org"
	LUAJIT_DOWNLOAD_ALL=$(c_curl -skL "$LUAJIT_URL/download.html" | grep -Eo 'href="[^"]*download/[^"]+tar.gz"' | sed -E 's/href="([^"]+)"/\1/')
	LUAJIT_VERSION=$(echo "$LUAJIT_DOWNLOAD_ALL" | grep -Eo "[0-9](\.[0-9])+(-[a-z0-9]+)?" | sort | tail -n1)
	SOURCE_URL="$(echo "$LUAJIT_DOWNLOAD_ALL" | grep "$LUAJIT_VERSION")"
	SOURCE_OPTION_CONFIGURE="--without-server"
	SOURCE_OPTION_MAKE=""
	SOURCE_OPTION_INSTALL="PREFIX=$LUAJIT_ROOT install"
	# build_common --skip-config --keep-source --no-install && lib_apply "$LUAJIT_ROOT/lib" && return 0
	build_common --skip-config && lib_apply "$LUAJIT_ROOT/lib" && return 0
	return 1
}

build_libmaxminddb() {
	SOURCE_APP="libmaxminddb"
	SOURCE_URL=$(github_releases_url "maxmind/libmaxminddb" | head -n1)
	SOURCE_OPTION_CONFIGURE="--without-server"
	SOURCE_OPTION_MAKE=""
	SOURCE_OPTION_INSTALL=""
	build_common && lib_apply "$LOCAL_LIB_ROOT" && return 0
	return 1
}

build_libdrizzle() {
	# require: gperf libprotobuf-dev protobuf-compiler libreadline-dev libboost-all-dev
	SOURCE_APP="libdrizzle"
	SOURCE_URL="https://openresty.org/download/drizzle7-2011.07.21.tar.gz"
	SOURCE_OPTION_CONFIGURE="--without-server"
	SOURCE_OPTION_MAKE="libdrizzle-1.0"
	SOURCE_OPTION_INSTALL="install-libdrizzle-1.0"
	build_common && lib_apply "$LOCAL_LIB_ROOT" && return 0
	return 1
}

build_libsodium() {
	SOURCE_APP="libsodium"
	SOURCE_URL="https://download.libsodium.org/libsodium/releases/LATEST.tar.gz"
	build_common && lib_apply "$LOCAL_LIB_ROOT" && return 0
	return 1
}

build_nginx_module_common() {
	# --submodule
	NGINX_MODULE_NAME=$(echo "$1" | awk -F'/' '{gsub(/\.git$/,"",$NF); print $NF}')
	[ -z "$NGINX_MODULE_NAME" ] && return 1
	NGINX_MODULE_PATH="$NGINX_SOURCE_MODULE_ROOT/$NGINX_MODULE_NAME"
	NGINX_MODULE_SUBDIR=""
	is_empty_dir "$NGINX_MODULE_PATH" && {
		github_clone "$1" "$NGINX_MODULE_PATH" || return 1
		args_match "$@" "--submodule" && github_submodule_update "$NGINX_MODULE_PATH"
	}
	args_match "$@" "--subdir" && {
		[ -z "$ARGS_MATCH_VALUE" ] || NGINX_MODULE_SUBDIR="/$ARGS_MATCH_VALUE"
	}
	NGINX_OPTION_ADD_DYNAMIC_MODULE="$NGINX_OPTION_ADD_DYNAMIC_MODULE --add-dynamic-module=$NGINX_MODULE_PATH$NGINX_MODULE_SUBDIR"
	return 0
}

build_nginx_module_pagespeed() {
	# Google PageSpeed Module (Only Support x86_64)
	log_info "$LANG_INITIALIZING_MODULE: pagespeed"
	[ "$OS_ARCH" = "x86_64" ] || {
		log_warn "$LANG_NOT_SUPPORT_FUNCTION"; return 0
	}
	has_header "uuid/uuid.h" || pkg_install "$PKG_UUID_LIB" || return 1
	NGINX_MODULE_PATH="$NGINX_SOURCE_MODULE_ROOT/incubator-pagespeed-ngx"
	NGX_PAGESPEED_URL=$(github_releases_url "apache/incubator-pagespeed-ngx" | grep "\.tar\.gz$" | head -n1)
	is_empty_dir "$NGINX_MODULE_PATH" && {
		download_file "$NGX_PAGESPEED_URL" "$NGINX_SOURCE_MODULE_ROOT" || return 1
		tar_extract_remove "$DOWNLOAD_FILE_NAME" "$NGINX_SOURCE_MODULE_ROOT" || return 1
		mv "$NGINX_SOURCE_MODULE_ROOT/$TAR_EXTRACT_ROOT" "$NGINX_MODULE_PATH" || return 1
		download_file "$($NGINX_MODULE_PATH/scripts/format_binary_url.sh "$NGINX_MODULE_PATH/PSOL_BINARY_URL")" "$NGINX_MODULE_PATH/" || (rm -rf "$NGINX_MODULE_PATH"; return 1)
		tar_extract_remove "$NGINX_MODULE_PATH/$DOWNLOAD_FILE_NAME" "$NGINX_MODULE_PATH" || return 1
	}
	NGINX_OPTION_ADD_DYNAMIC_MODULE="$NGINX_OPTION_ADD_DYNAMIC_MODULE --add-dynamic-module=$NGINX_MODULE_PATH"
	return 0
}

build_nginx_module_drizzle() {
	# Drizzle Module
	log_info "$LANG_INITIALIZING_MODULE: drizzle"
	has_lib "libdrizzle" || build_libdrizzle || return 1
	build_nginx_module_common "https://github.com/openresty/drizzle-nginx-module.git"
}

build_nginx_module_geoip2() {
	# GeoIP2 Module
	log_info "$LANG_INITIALIZING_MODULE: geoip2"
	has_header "maxminddb.h" || build_libmaxminddb || return 1
	build_nginx_module_common "https://github.com/leev/ngx_http_geoip2_module.git"
}

build_nginx_module_mruby() {
	log_info "$LANG_INITIALIZING_MODULE: mruby"
	has_package "rake" || return 1
	NGINX_MODULE_PATH="$NGINX_SOURCE_MODULE_ROOT/ngx_mruby"
	github_clone "https://github.com/matsumotory/ngx_mruby.git" "$NGINX_MODULE_PATH"
	cd "$NGINX_MODULE_PATH" && ./configure --with-ngx-src-root=$NGINX_SOURCE_ROOT --with-ngx-config-opt=--prefix=$NGINX_PREFIX && make build_mruby && make generate_gems_config && NGINX_OPTION_ADD_DYNAMIC_MODULE="$NGINX_OPTION_ADD_DYNAMIC_MODULE --add-dynamic-module=$NGINX_MODULE_PATH"
}

build_nginx_module_lua() {
	# LuaJIT Module
	log_info "$LANG_INITIALIZING_MODULE: lua"
	has_lib "libluajit" || build_libluajit || return 1
	has_header "pcre.h" || pkg_install "$PKG_PCRE_LIB" || return 1
	build_nginx_module_common "https://github.com/openresty/lua-nginx-module.git"
	export LUAJIT_LIB=$LUAJIT_ROOT/lib
	export LUAJIT_INC=$LUAJIT_ROOT/include/$(ls $LUAJIT_ROOT/include | tail -n1)
}

build_nginx_module_video_thumb_extractor() {
	log_info "$LANG_INITIALIZING_MODULE: video-thumbextractor"
	has_lib "libavformat libavcodec libavutil libavfilter libswscale libjpeg" || pkg_install "$PKG_NGINX_MODULE_VIDEO_THUMB" || return 1
	build_nginx_module_common "https://github.com/wandenberg/nginx-video-thumbextractor-module.git"
}

build_nginx_module_small_light() {
	# Small Light Module
	log_info "$LANG_INITIALIZING_MODULE: small_light"
	NGINX_MODULE_PATH="$NGINX_SOURCE_MODULE_ROOT/ngx_small_light"
	github_clone "https://github.com/cubicdaiya/ngx_small_light.git" "$NGINX_MODULE_PATH"
	cd "$NGINX_MODULE_PATH" && ./setup && NGINX_OPTION_ADD_DYNAMIC_MODULE="$NGINX_OPTION_ADD_DYNAMIC_MODULE --add-dynamic-module=$NGINX_MODULE_PATH"
}

build_nginx_module_tcp_proxy() {
	# TCP Proxy Module
	log_info "$LANG_INITIALIZING_MODULE: tcp_proxy"
	NGINX_MODULE_PATH="$NGINX_SOURCE_MODULE_ROOT/nginx_tcp_proxy_module"
	github_clone "https://github.com/yaoweibin/nginx_tcp_proxy_module.git" "$NGINX_MODULE_PATH"
	patch -d "$NGINX_SOURCE_ROOT" -p1 < "$NGINX_MODULE_PATH/tcp_1_8.patch"
	NGINX_OPTION_ADD_DYNAMIC_MODULE="$NGINX_OPTION_ADD_DYNAMIC_MODULE --add-dynamic-module=$NGINX_MODULE_PATH"
}

build_nginx_module_njs() {
	# NJS Module
	log_info "$LANG_INITIALIZING_MODULE: njs"
	download_file "http://hg.nginx.org/njs/archive/tip.tar.gz" "$NGINX_SOURCE_MODULE_ROOT" || return 1
	tar_extract_remove "$NGINX_SOURCE_MODULE_ROOT/$DOWNLOAD_FILE_NAME" "$NGINX_SOURCE_MODULE_ROOT" || return 1
	NGINX_MODULE_PATH="$NGINX_SOURCE_MODULE_ROOT/$TAR_EXTRACT_ROOT/nginx"
	NGINX_OPTION_ADD_DYNAMIC_MODULE="$NGINX_OPTION_ADD_DYNAMIC_MODULE --add-dynamic-module=$NGINX_MODULE_PATH"
}

build_nginx_module_sass() {
	# SASS Module
	log_info "$LANG_INITIALIZING_MODULE: sass"
	has_lib "libsass" || pkg_install "$PKG_SASS_LIB" || return 1
	build_nginx_module_common "https://github.com/mneudert/sass-nginx-module.git"
}

build_nginx_module_set_misc() {
	log_info "$LANG_INITIALIZING_MODULE: set_misc"
	build_nginx_module_common "https://github.com/openresty/set-misc-nginx-module.git"
}

build_nginx_module_eval() {
	log_info "$LANG_INITIALIZING_MODULE: eval"
	build_nginx_module_common "https://github.com/openresty/nginx-eval-module.git"
}

build_nginx_module_mongo() {
	log_info "$LANG_INITIALIZING_MODULE: mongo"
	has_header "yajl/yajl_common.h" || pkg_install "$PKG_YAJL_LIB" || return 1
	build_nginx_module_common "https://github.com/simplresty/ngx_mongo.git"
}

build_nginx_module_postgres() {
	# PostgreSQL
	log_info "$LANG_INITIALIZING_MODULE: postgres"
	has_lib "libpq" || pkg_install "$PKG_PQ_LIB" || return 1
	build_nginx_module_common "https://github.com/openresty/ngx_postgres"
}

build_nginx_module_rds_json() {
	log_info "$LANG_INITIALIZING_MODULE: rds_json"
	build_nginx_module_common "https://github.com/openresty/rds-json-nginx-module.git"
}

build_nginx_module_redis() {
	# Redis
	log_info "$LANG_INITIALIZING_MODULE: redis"
	build_nginx_module_common "https://github.com/onnimonni/redis-nginx-module.git"
	grep -Eq 'if\s*\(NGX_HTTP_GZIP\)' $NGINX_MODULE_PATH/ngx_http_redis_module.c && {
		sed -Ei 's/(if\s*\()NGX_HTTP_GZIP(\))/\1NGX_HTTP_GZIP \&\& nginx_version < 1023000\2/g' $NGINX_MODULE_PATH/ngx_http_redis_module.c
	}
	return 0
}

build_nginx_module_redis2() {
	# Redis2
	log_info "$LANG_INITIALIZING_MODULE: redis2"
	build_nginx_module_common "https://github.com/openresty/redis2-nginx-module.git"
}

build_nginx_module_memcached() {
	log_info "$LANG_INITIALIZING_MODULE: memcached"
	build_nginx_module_common "https://github.com/openresty/memc-nginx-module"
}

build_nginx_module_brotli() {
	log_info "$LANG_INITIALIZING_MODULE: brotli"
	build_nginx_module_common "https://github.com/eustas/ngx_brotli.git" --submodule
}

build_nginx_module_encrypted_session() {
	log_info "$LANG_INITIALIZING_MODULE: encrypted_session"
	build_nginx_module_common "https://github.com/openresty/encrypted-session-nginx-module.git"
}

build_nginx_module_encrypted_form_input() {
	log_info "$LANG_INITIALIZING_MODULE: form_input"
	build_nginx_module_common "https://github.com/calio/form-input-nginx-module.git"
}

build_nginx_module_headers_more() {
	log_info "$LANG_INITIALIZING_MODULE: headers_more"
	build_nginx_module_common "https://github.com/openresty/headers-more-nginx-module.git"
}

build_nginx_module_dav_ext() {
	log_info "$LANG_INITIALIZING_MODULE: dav_ext"
	build_nginx_module_common "https://github.com/arut/nginx-dav-ext-module.git"
}

build_nginx_module_auth_pam() {
	# PAM Module
	log_info "$LANG_INITIALIZING_MODULE: pam"
	has_header "security/pam_appl.h" || pkg_install "$PKG_PAM_LIB" || return 1
	build_nginx_module_common "https://github.com/sto/ngx_http_auth_pam_module.git"
}

build_nginx_module_auth_aws() {
	log_info "$LANG_INITIALIZING_MODULE: auth_aws"
	build_nginx_module_common "https://github.com/anomalizer/ngx_aws_auth.git"
}

build_nginx_module_auth_ldap() {
	log_info "$LANG_INITIALIZING_MODULE: auth_ldap"
	has_header "ldap.h" || pkg_install "$PKG_LDAP_LIB" || return 1
	build_nginx_module_common "https://github.com/kvspb/nginx-auth-ldap.git"
}

build_nginx_module_echo() {
	log_info "$LANG_INITIALIZING_MODULE: echo"
	build_nginx_module_common "https://github.com/openresty/echo-nginx-module.git"
}

build_nginx_module_fancyindex() {
	log_info "$LANG_INITIALIZING_MODULE: fancyindex"
	build_nginx_module_common "https://github.com/aperezdc/ngx-fancyindex.git"
}

build_nginx_module_cache_purge() {
	log_info "$LANG_INITIALIZING_MODULE: cache_purge"
	build_nginx_module_common "https://github.com/FRiCKLE/ngx_cache_purge.git"
}

build_nginx_module_nchan() {
	log_info "$LANG_INITIALIZING_MODULE: nchan"
	build_nginx_module_common "https://github.com/slact/nchan.git"
}

build_nginx_module_upstream_fair() {
	log_info "$LANG_INITIALIZING_MODULE: upstream_fair"
	build_nginx_module_common "https://github.com/itoffshore/nginx-upstream-fair.git"
}

build_nginx_module_substitutions_filter() {
	log_info "$LANG_INITIALIZING_MODULE: substitutions_filter"
	build_nginx_module_common "https://github.com/yaoweibin/ngx_http_substitutions_filter_module.git"
}

build_nginx_module_upload() {
	log_info "$LANG_INITIALIZING_MODULE: upload"
	build_nginx_module_common "https://github.com/fdintino/nginx-upload-module.git"
}

build_nginx_module_upload_progress() {
	log_info "$LANG_INITIALIZING_MODULE: upload_progress"
	build_nginx_module_common "https://github.com/masterzen/nginx-upload-progress-module.git"
	[ -f "$NGINX_SOURCE_ROOT/.patched" ] || {
		echo "$NGINX_VERSION" | grep -Eq '^1\.[2-9][0-9]' && {
			c_curl -skL "https://github.com/masterzen/nginx-upload-progress-module/compare/master...msva:nginx-upload-progress-module:master.diff" | patch -d "$NGINX_MODULE_PATH" -p1 -b && \
				touch "$NGINX_MODULE_PATH/.patched"
		}
	}
	return 0
}

build_nginx_module_execute() {
	log_info "$LANG_INITIALIZING_MODULE: execute"
	build_nginx_module_common "https://github.com/limithit/NginxExecute.git"
}

build_nginx_module_traffic_accounting() {
	log_info "$LANG_INITIALIZING_MODULE: traffic_accounting"
	build_nginx_module_common "https://github.com/Lax/traffic-accounting-nginx-module.git"
}

build_nginx_module_push_stream() {
	log_info "$LANG_INITIALIZING_MODULE: push_stream"
	build_nginx_module_common "https://github.com/wandenberg/nginx-push-stream-module.git"
}

build_nginx_module_statsd() {
	log_info "$LANG_INITIALIZING_MODULE: statsd"
	build_nginx_module_common "https://github.com/trungtm/nginx-statsd.git"
}

build_nginx_module_naxsi() {
	log_info "$LANG_INITIALIZING_MODULE: naxsi"
	has_header "pcre.h" || pkg_install "$PKG_PCRE_LIB" || return 1
	build_nginx_module_common "https://github.com/nbs-system/naxsi.git"
}

build_nginx_module_upstream_check() {
	log_info "$LANG_INITIALIZING_MODULE: upstream_check"
	build_nginx_module_common "https://github.com/yaoweibin/nginx_upstream_check_module.git"
}

build_nginx_module_vts() {
	# For Nginx 1.20+
	log_info "$LANG_INITIALIZING_MODULE: vts"
	[ -f "$NGINX_SOURCE_ROOT/.patched_vts" ] || {
		echo "$NGINX_VERSION" | grep -Eq '^1\.[2-9][0-9]' && {
			[ -f "$NGINX_SOURCE_ROOT/check_1.20.1%2B.patch" ] || {
				wget -O "$NGINX_SOURCE_ROOT/check_1.20.1+.patch" "https://github.com/yaoweibin/nginx_upstream_check_module/raw/master/check_1.20.1%2B.patch"
				patch -d "$NGINX_SOURCE_ROOT" -p1 < "$NGINX_SOURCE_ROOT/check_1.20.1+.patch" && touch "$NGINX_SOURCE_ROOT/.patched_vts"
			}
		}
	}
	build_nginx_module_common "https://github.com/vozlt/nginx-module-vts.git"
}

build_nginx_module_rtmp() {
	log_info "$LANG_INITIALIZING_MODULE: rtmp"
	build_nginx_module_common "https://github.com/arut/nginx-rtmp-module.git"
}

build_nginx_module_devel_kit() {
	log_info "$LANG_INITIALIZING_MODULE: devel_kit"
	build_nginx_module_common "https://github.com/simplresty/ngx_devel_kit.git"
}

build_nginx_module_xslt() {
	log_info "$LANG_INITIALIZING_MODULE: xslt"
	has_header "exslt.h" "libexslt/exslt.h" || pkg_install "$PKG_XSLT_LIB" || return 1
	has_lib "libxml2" || pkg_install "$PKG_XML2_LIB" || return 1
	NGINX_OPTION_MODULE_DYNAMIC="$NGINX_OPTION_MODULE_DYNAMIC --with-http_xslt_module=dynamic"
}

build_nginx_module_geoip() {
	log_info "$LANG_INITIALIZING_MODULE: geoip"
	has_lib "libgeoip" || pkg_install "$PKG_GEOIP_LIB" || return 1
	NGINX_OPTION_MODULE_DYNAMIC="$NGINX_OPTION_MODULE_DYNAMIC --with-http_geoip_module=dynamic"
}

build_nginx_module_image_filter() {
	log_info "$LANG_INITIALIZING_MODULE: image_filter"
	has_header "gd.h" || pkg_install "$PKG_GD_LIB" || return 1
	NGINX_OPTION_MODULE_DYNAMIC="$NGINX_OPTION_MODULE_DYNAMIC --with-http_image_filter_module=dynamic"
}

build_nginx_with_zlib() {
	# Zlib Cloudflare
	NGINX_DEPEND="$NGINX_SOURCE_DEPEND_ROOT/zlib-cloudflare"
	is_empty_dir "$NGINX_DEPEND" && {
		github_clone "https://github.com/cloudflare/zlib.git" "$NGINX_DEPEND" || return 1
		cd "$NGINX_DEPEND" && ./configure || return 1
	}
	NGINX_OPTION_DEFAULT="$NGINX_OPTION_DEFAULT --with-zlib=$NGINX_DEPEND"
	return 0
}

build_nginx_with_pcre() {
	has_package "$PKG_TOOL_LIB" || pkg_install "$PKG_TOOL_LIB" || return 1
	NGINX_DEPEND="$NGINX_SOURCE_DEPEND_ROOT/pcre2"
	is_empty_dir "$NGINX_DEPEND" && {
		github_clone "https://github.com/PCRE2Project/pcre2.git" "$NGINX_DEPEND" || return 1
		[ -f "$NGINX_DEPEND/autogen.sh" ] && {
			cd $NGINX_DEPEND
			chmod +x ./autogen.sh
			./autogen.sh || return 1
		}
	}
	NGINX_OPTION_DEFAULT="$NGINX_OPTION_DEFAULT --with-pcre=$NGINX_DEPEND"
	return 0
}
       
build_nginx_with_openssl() {
	NGINX_DEPEND="$NGINX_SOURCE_DEPEND_ROOT/openssl"
	# OpenSSL Dev Version
	is_empty_dir "$NGINX_DEPEND" && {
		# OpenSSL 1.1.1 Stable
		# github_clone "https://github.com/openssl/openssl.git" "$NGINX_DEPEND" "OpenSSL_1_1_1q" || return 1
		# github_clone "https://github.com/openssl/openssl.git" "$NGINX_DEPEND" "openssl-3.1" || return 1
		github_clone "https://github.com/openssl/openssl.git" "$NGINX_DEPEND" || return 1
		github_submodule_update "$NGINX_DEPEND" || return 1
	}
	NGINX_OPTION_DEFAULT="$NGINX_OPTION_DEFAULT --with-openssl=$NGINX_DEPEND"
	return 0
}

build_nginx_gen_module_conf() {
	mkdir_p "$2"
	while read MODULE
	do
		[ -z "$MODULE" ] || {
			MODULE_NAME=$(echo "$MODULE" | awk -F'.' '{print $1}')
			echo "load_module modules/$MODULE;" > "$2/${MODULE_NAME}.conf"
		}
	done <<-EOF
	$(ls "$1" | grep -i '\.so$')
	EOF
}

build_nginx() {
	NGINX_VERSION_ALL=$(c_curl -skL "http://nginx.org/en/download.html" | grep -Eo 'href="[^"]+\.tar\.gz"' | sed -E 's/href="([^"]+)"/\1/')
	NGINX_VERSION_LATEST=$(echo "$NGINX_VERSION_ALL" | awk -F'(nginx-|.tar.gz)' 'NR==1 {print $2}')
	NGINX_VERSION_STABLE=$(echo "$NGINX_VERSION_ALL" | awk -F'(nginx-|.tar.gz)' 'NR==2 {print $2}')
	NGINX_VERSION_INSTALLED="$(nginx -v 2>&1)"
	NGINX_VERSION_INSTALLED=$(echo "$NGINX_VERSION_INSTALLED" | head -n1 | awk -F'/' '{print $NF}')
	[ "$BUILD_SHOW_VERSION_ONLY" = "1" ] && {
		string_by_columns "$(cat <<-EOF
		$LANG_INSTALLED    : $NGINX_VERSION_INSTALLED
		$LANG_STABLE    : $NGINX_VERSION_STABLE
		$LANG_MAINLINE    : $NGINX_VERSION_LATEST
		EOF
		)" "    " "+2"
		return 0
	}
	NGINX_VERSION="$NGINX_VERSION_STABLE"
	[ "$BUILD_LATEST" = "1" ] && NGINX_VERSION="$NGINX_VERSION_LATEST"
	[ -z "$NGINX_VERSION" ] && return 1
	# pkg_install "$PKG_XSLT_LIB $PKG_XML2_LIB"
	NGINX_SOURCE_FILE="$NGINX_APP_CACHE_DIR/nginx-$NGINX_VERSION.tar.gz"
	NGINX_SOURCE_ROOT="$NGINX_APP_CACHE_DIR/nginx-$NGINX_VERSION"
	NGINX_PREFIX="$NGINX_PREFIX/$NGINX_VERSION"
	# Compile Options
	NGINX_OPTION_GCC="--with-cc-opt='-g -O2 -fdebug-prefix-map=$NGINX_SOURCE_ROOT=. -fstack-protector-strong -Wformat -Werror=format-security -Wdate-time -D_FORTIFY_SOURCE=2'"
	NGINX_OPTION_GCC="--with-cc-opt='-Wformat -Werror=format-security -Wdate-time'"
	NGINX_OPTION_LD="--with-ld-opt='-Wl,-z,relro -pie'"
	NGINX_OPTION_DEFAULT="--prefix=$NGINX_PREFIX --conf-path=/etc/nginx/nginx.conf --http-log-path=/var/log/nginx/access.log --error-log-path=/var/log/nginx/error.log --lock-path=/var/lock/nginx.lock --pid-path=/run/nginx.pid --modules-path=$NGINX_PREFIX/modules --http-client-body-temp-path=/var/lib/nginx/body --http-fastcgi-temp-path=/var/lib/nginx/fastcgi --http-proxy-temp-path=/var/lib/nginx/proxy --http-scgi-temp-path=/var/lib/nginx/scgi --http-uwsgi-temp-path=/var/lib/nginx/uwsgi"
	NGINX_OPTION_MODULE="--with-debug --with-http_ssl_module --with-http_stub_status_module --with-http_realip_module --with-http_auth_request_module --with-http_dav_module --with-http_slice_module --with-threads --with-http_addition_module --with-http_flv_module --with-http_gunzip_module --with-http_gzip_static_module --with-http_mp4_module --with-http_random_index_module --with-http_secure_link_module --with-http_sub_module --with-http_v2_module --with-mail_ssl_module --with-stream_realip_module --with-stream_ssl_module --with-stream_ssl_preread_module"
	NGINX_OPTION_MODULE_DYNAMIC="--with-http_perl_module=dynamic --with-mail=dynamic --with-stream"
	find /usr/lib | grep -Eq '/libperl.so$' || pkg_install "$PKG_PERL_LIB" || return 1
	# Download Source
	is_empty_dir "$NGINX_SOURCE_ROOT" && {
		download_file "http://nginx.org/download/nginx-$NGINX_VERSION.tar.gz" "$NGINX_SOURCE_FILE" || return 1
		tar_extract "$NGINX_SOURCE_FILE" "$NGINX_APP_CACHE_DIR" || return 1
	}
	# Download Dependens
	# build_nginx_with_openssl || pkg_install "$PKG_SSL_LIB"
	# build_nginx_with_pcre || pkg_install "$PKG_PCRE_LIB"
	# build_nginx_with_zlib || pkg_install "$PKG_ZLIB_LIB"
	build_nginx_with_openssl || return 1
	build_nginx_with_pcre || return 1
	build_nginx_with_zlib || return 1
	# Download Modules
	# Basic
	build_nginx_module_image_filter || return 1
	build_nginx_module_geoip || return 1
	build_nginx_module_xslt || return 1
	build_nginx_module_devel_kit || return 1
	# Auth
	build_nginx_module_auth_pam || return 1
	build_nginx_module_auth_aws || return 1
	build_nginx_module_auth_ldap || return 1
	# Database
	build_nginx_module_mongo || return 1
	build_nginx_module_postgres || return 1
	# build_nginx_module_drizzle || return 1
	build_nginx_module_rds_json || return 1
	build_nginx_module_redis || return 1
	build_nginx_module_redis2 || return 1
	# Optimize
	build_nginx_module_pagespeed || return 1
	build_nginx_module_brotli || return 1
	# Language & Content
	# build_nginx_module_mruby || return 1
	build_nginx_module_lua || return 1
	build_nginx_module_njs || return 1
	build_nginx_module_echo || return 1
	build_nginx_module_substitutions_filter || return 1
	build_nginx_module_sass || return 1
	build_nginx_module_eval || return 1
	# Application
	build_nginx_module_execute || return 1
	build_nginx_module_traffic_accounting || return 1
	build_nginx_module_statsd || return 1
	build_nginx_module_fancyindex || return 1
	build_nginx_module_dav_ext || return 1
	build_nginx_module_nchan || return 1
	# build_nginx_module_naxsi
	# Header
	build_nginx_module_geoip2 || return 1
	build_nginx_module_headers_more || return 1
	build_nginx_module_encrypted_session || return 1
	build_nginx_module_encrypted_form_input || return 1
	# Other
	build_nginx_module_cache_purge || return 1
	build_nginx_module_memcached || return 1
	build_nginx_module_upstream_fair || return 1
	build_nginx_module_upload || return 1
	build_nginx_module_upload_progress || return 1
	build_nginx_module_push_stream || return 1
	build_nginx_module_upstream_check || return 1
	build_nginx_module_vts || return 1
	build_nginx_module_rtmp || return 1
	build_nginx_module_video_thumb_extractor || return 1
	build_nginx_module_set_misc || return 1
	# NGINX_OPTION_ADD_DYNAMIC_MODULE=""
	time_count "0"
	cd "$NGINX_SOURCE_ROOT" && echo "y" | ./configure --with-cc-opt=-Wno-error $NGINX_OPTION_DEFAULT $NGINX_OPTION_MODULE $NGINX_OPTION_MODULE_DYNAMIC $NGINX_OPTION_ADD_DYNAMIC_MODULE && make -j$(nproc) V=s && {
		rm -rf "$NGINX_PREFIX" && make install && rm -rf "$NGINX_CACHE" && {
			mkdir -p /var/lib/nginx && chmod 777 /var/lib/nginx
			build_nginx_gen_module_conf "$NGINX_PREFIX/modules" "$NGINX_PREFIX/modules-available"
			has_package "nginx" || link_as_bin "$NGINX_PREFIX/sbin/nginx"
		}
	}
	time_count
	seconds_to_human "$TIME_COUNT" --short
}

build_rclone() {
	# Newifi D2
	# GOOS=linux GOARCH=mipsle GOMIPS=softfloat go build
	_FAILED_=1
	_PKG_TMP_ROOT_="$APP_CACHE_DIR/rclone"
	_GIT_BRANCH_="traack_symlinks"
	has_package "golang" || install_golang || {
		return 1
	}
	rm -rf "$_PKG_TMP_ROOT_"
	c_git clone https://github.com/dinoboy197/rclone "$_PKG_TMP_ROOT_" && \
		cd "$_PKG_TMP_ROOT_" && \
		c_git checkout "$_GIT_BRANCH_" && \
		go build && \
		cp -f rclone /usr/bin/ && \
		chmod +x /usr/bin/rclone && \
		rclone version && \
		_FAILED_=0
	rm -rf "$_PKG_TMP_ROOT_" 2>/dev/null
	return $_FAILED_
}

build_tcping() {
	_FAILED_=1
	_PKG_TMP_ROOT_="$APP_CACHE_DIR/tcping"
	has_package "golang" || install_golang || {
		return 1
	}
	rm -rf "$_PKG_TMP_ROOT_"
	c_git clone https://github.com/cloverstd/tcping.git "$_PKG_TMP_ROOT_" && \
		cd "$_PKG_TMP_ROOT_" && \
		go build && \
		cp -f tcping /usr/bin/ && \
		chmod +x /usr/bin/tcping && \
		tcping --version && \
		_FAILED_=0
	rm -rf "$_PKG_TMP_ROOT_" 2>/dev/null
	return $_FAILED_
}

build_squashfs() {
	_FAILED_=1
	_PKG_TMP_ROOT_="$APP_CACHE_DIR/squashfs"
	rm -rf "$_PKG_TMP_ROOT_"
	c_git clone https://github.com/plougher/squashfs-tools.git "$_PKG_TMP_ROOT_" && \
		cd "$_PKG_TMP_ROOT_" && \
		make && \
		make install && \
		_FAILED_=0
	rm -rf "$_PKG_TMP_ROOT_" 2>/dev/null
	return $_FAILED_
}

build_yay() {
	[ "$OS_PKG_MG" = "pacman" ] || return 1
	pacman -S --needed git base-devel
	git clone https://aur.archlinux.org/yay.git
	cd yay
	makepkg -si
}

config_set() {
	CONFIG_MATCHED="0"
	CONFIG_MAP=$(cat <<-EOF
	www_root    WWW_ROOT    Website document root path, default: /www
	data_root    DATA_ROOT    Data root path, default: /data
	php_mem_limit    PHP_MEMORY_LIMIT    
	php_up_max    PHP_UPLOAD_MAX_FILESIZE    PHP max upload file size, default: 50M
	tz    TIMEZONE    Time Zone, default: Asia/Shanghai
	EOF
	)
	while read CONFIG
	do
		[ -z "$CONFIG" ] || {
			CONFIG_NAME=$(echo "$CONFIG" | grep -Eo "^--[^-^=]+=" | tr -d '=-')
			CONFIG_MAP_MATCH=$(echo "$CONFIG_MAP" | grep "^${CONFIG_NAME}    ")
			[ -z "$CONFIG_MAP_MATCH" ] || {
				CONFIG_NAME=$(echo "$CONFIG_MAP_MATCH" | awk -F'    ' '{print $2}')
				CONFIG_VALUE=$(echo "$CONFIG" | sed -E "s/^[^=]+=//")
				grep -Eq "^${CONFIG_NAME}=" "$APP_PROFILE" && {
					sed -Ei "/^${CONFIG_NAME}=/d" "$APP_PROFILE"
				}
				echo "$CONFIG_NAME=$CONFIG_VALUE" >> "$APP_PROFILE"
				CONFIG_MATCHED=$((CONFIG_MATCHED+1))
			}
		}
	done <<-EOF
	$1
	EOF
	[ "$CONFIG_MATCHED" -gt 0 ] && return 0
	[ -f "$APP_PROFILE" ] && {
		CONFIG_CONTENT=$(cat "$APP_PROFILE")
		while read CONFIG
		do
			CONFIG_NAME=$(echo "$CONFIG_MAP" | awk -F'    ' "$2 == \"$CONFIG\" {print $1}")
			[ -z "$CONFIG_NAME" ] || {
				echo "$CONFIG_CONTENT" | grep "^${CONFIG_NAME}=" | sed -E "s/^${CONFIG}=/$CONFIG_NAME=/"
			}
		done <<-EOF
		$(echo "$CONFIG_CONTENT" | grep -Eo "^[0-9A-Z_]=" | tr -d "=")
		EOF
	}
	cat <<-EOF

	$APP_NAME config [--name=value] [--name=value] [...]
	$(echo "$CONFIG_MAP" | awk -F'    ' '{print "--"$1"={"$3"}"}')
	EOF
}

supervisor_add() {
	case "$OS_TYPE" in
		"el"|"fc")
			SUPERVISOR_CONF_ROOT="/etc/supervisord.d"
			SUPERVISOR_CONF_EXT="ini"
			;;
	esac
	has_package "supervisor" || return 1
	[ -z "$1" ] && return 1
	_APP_SUPERVISOR_CONF_FILE_="$SUPERVISOR_CONF_ROOT/${1}.${SUPERVISOR_CONF_EXT}"
	if args_match "$@" "--content|-c"; then
		echo "$ARGS_MATCH_VALUE" > "$_APP_SUPERVISOR_CONF_FILE_"
	else
		args_match "$@" "--command|-C" && _SUPERVISOR_COMMAND_="$ARGS_MATCH_VALUE"
		args_match "$@" "--user|-U" && _SUPERVISOR_USER_="$ARGS_MATCH_VALUE" || _SUPERVISOR_USER_="$USER"
		args_match "$@" "--priority|-P" && _SUPERVISOR_PRIORITY_="$ARGS_MATCH_VALUE" || _SUPERVISOR_PRIORITY_="30"
		args_match "$@" "--directory|-D" && _SUPERVISOR_DIRECTORY_="$ARGS_MATCH_VALUE" || _SUPERVISOR_DIRECTORY_="/"
		args_match "$@" "--autostart" && _SUPERVISOR_AUTOSTART_="$ARGS_MATCH_VALUE" || _SUPERVISOR_AUTOSTART_="true"
		args_match "$@" "--autorestart" && _SUPERVISOR_AUTORESTART_="$ARGS_MATCH_VALUE" || _SUPERVISOR_AUTORESTART_="true"
		args_match "$@" "--extend|-e" && _SUPERVISOR_EXTEND_="$ARGS_MATCH_VALUE" || _SUPERVISOR_EXTEND_=""
		args_match "$@" "--name" && _SUPERVISOR_NAME_="$ARGS_MATCH_VALUE" || _SUPERVISOR_NAME_="$1"
		[ -z "$_SUPERVISOR_COMMAND_" ] && return 1
		cat <<-EOF > "$_APP_SUPERVISOR_CONF_FILE_"
		[program:$_SUPERVISOR_NAME_]
		priority=$_SUPERVISOR_PRIORITY_
		directory=$_SUPERVISOR_DIRECTORY_
		command=$_SUPERVISOR_COMMAND_
		user=$_SUPERVISOR_USER_
		autostart=$_SUPERVISOR_AUTOSTART_
		autorestart=$_SUPERVISOR_AUTORESTART_
		$_SUPERVISOR_EXTEND_
		EOF
	fi
	SUPERVISOR_RELOAD="1"
	return 0
}

supervisor_status() {
	[ -z "$1" ] && return 1
	has_package "supervisor" || return 1
	SUPERVISOR_STATUS=$(supervisorctl status|awk "(\$1~/^$1$/){print \$2}")
	[ -z "$SUPERVISOR_STATUS" ] && return 1
	echo "$SUPERVISOR_STATUS"
	return 0 
}

supervisor_restart() {
	has_package "supervisor" || return 1
	if [ -z "$1" ]; then
		supervisorctl restart && return 0
	else
		supervisorctl restart "$1" && return 0
	fi
	return 1
}

supervisor_reload() {
	has_package "supervisor" || return 1
	if pidof supervisord &>/dev/null; then
		supervisorctl update
	elif ps x | grep "supervisord" | grep -qv "grep" 2>/dev/null; then
		supervisorctl update
	else
		$INITD_ROOT/supervisor reload || $INITD_ROOT/supervisor restart
	fi
}

nginx_reload() {
	has_package "nginx" || return 1
	if pidof nginx &>/dev/null; then
		nginx -s reload
	else
		$INITD_ROOT/nginx restart
	fi
}

frp_server_add() {
	[ -z "$FRP_SERVER_BIN" ] && FRP_SERVER_BIN=$(which frps)
	[ -x "$FRP_SERVER_BIN" ] || {
		log_err "$(string_with_args "$LANG_HAVE_TO_INSTALL_APP_FIRST" "frp")" && return 1
	}
	get_address "$FRP_SERVER"
	FRP_SERVER_IP=${ADDRESS_IP:-0.0.0.0}
	FRP_SERVER_PORT=${ADDRESS_PORT:-7000}
	FRP_DASHBOARD_PORT=${FRP_DASHBOARD_PORT:-7500}
	FRP_CONF_NAME="frps_${FRP_SERVER_IP}_${FRP_SERVER_PORT}"
	FRP_CONF="$FRP_CONF_ROOT/${FRP_CONF_NAME}.ini"
	frp_server_conf
	frp_server_supervisor 2>/dev/null
	return 0
}

frp_server_conf() {
	mkdir_p "$FRP_CONF_ROOT"
	cat <<-EOF > "$FRP_CONF"
	[common]
	bind_addr = $FRP_SERVER_IP
	bind_port = $FRP_SERVER_PORT
	kcp_bind_port = $FRP_SERVER_PORT

	dashboard_port = 7500
	dashboard_user = admin
	dashboard_pwd = admin

	# privilege_token = $(date +%s)
	# privilege_allow_ports = 2000-3000,3001,3003,4000-50000
	# subdomain_host = frps.com
	EOF
}

frp_server_supervisor() {
	supervisor_add "$FRP_CONF_NAME" --command "frps -c $FRP_CONF"
	return $?
}

frp_client_add() {
	[ -z "$FRP_CLIENT_BIN" ] && FRP_CLIENT_BIN=$(which frpc)
	[ -x "$FRP_CLIENT_BIN" ] || {
		log_err "$(string_with_args "$LANG_HAVE_TO_INSTALL_APP_FIRST" "frp")" && return 1
	}
	[ -z "$FRP_SERVER" -o -z "$FRP_LOCAL" ] && return 1
	get_address "$FRP_SERVER" || return 1
	FRP_SERVER_IP="$ADDRESS_IP"
	FRP_SERVER_PORT="${ADDRESS_PORT:-7000}"
	is_port "$FRP_SERVER_PORT" || return 1
	get_address "$FRP_LOCAL" || return 1
	FRP_LOCAL_IP="${ADDRESS_IP:-127.0.0.1}"
	FRP_LOCAL_PORT="$ADDRESS_PORT"
	FRP_REMOTE_PORT="${FRP_REMOTE_PORT:-$FRP_LOCAL_PORT}"
	FRP_TYPE=${FRP_TYPE:-tcp}
	[ -z "$FRP_LOCAL_PORT" -o -z "$FRP_REMOTE_PORT" -o -z "$FRP_SERVER_IP" -o -z "$FRP_SERVER_PORT" ] && return 1
	check_port_status "$FRP_SERVER_IP:$FRP_SERVER_PORT" >/dev/null
	[ "$?" = "52" ] || {
		log_err "server is not online ($FRP_SERVER_IP:$FRP_SERVER_PORT)" && return 1
	}
	FRP_REMOTE_PORT_OFFSET=0
	if echo "$FRP_REMOTE_PORT" | grep -Eq '^[1-9][0-9]*-[1-9][0-9]*$'; then
		FRP_REMOTE_PORT_END=$(echo "$FRP_REMOTE_PORT" | awk -F'-' '{print $2}')
		FRP_REMOTE_PORT=$(echo "$FRP_REMOTE_PORT" | awk -F'-' '{print $1}')
		FRP_REMOTE_PORT_OFFSET=$((FRP_REMOTE_PORT_END-FRP_REMOTE_PORT))
	elif echo "$FRP_REMOTE_PORT" | grep -Eq '^[1-9][0-9]*\+$'; then
		FRP_REMOTE_PORT=$(echo "$FRP_REMOTE_PORT" | tr -d '+')
		FRP_REMOTE_PORT_OFFSET=11
	fi
	FRP_REMOTE_PORT_IS_OK="0"
	while [ "$FRP_REMOTE_PORT_OFFSET" -ge 0 ]
	do
		check_port_status "$FRP_SERVER_IP:$FRP_REMOTE_PORT" >/dev/null || {
			log_info "will use remote port: $FRP_SERVER_IP:$FRP_REMOTE_PORT" && FRP_REMOTE_PORT_IS_OK="1" && break
		} || {
			log_err "$(string_with_args "$LANG_HAS_BEEN_USING" "$FRP_SERVER_IP:$FRP_REMOTE_PORT")"
		}
		FRP_REMOTE_PORT=$((FRP_REMOTE_PORT+1))
		FRP_REMOTE_PORT_OFFSET=$((FRP_REMOTE_PORT_OFFSET-1))
	done
	cat <<-EOF
	FRP_SERVER_IP:$FRP_SERVER_IP
	FRP_SERVER_PORT:$FRP_SERVER_PORT
	FRP_TOKEN:$FRP_TOKEN
	------------------------------------------
	FRP_LOCAL_IP:$FRP_LOCAL_IP
	FRP_LOCAL_PORT:$FRP_LOCAL_PORT
	FRP_REMOTE_PORT:$FRP_REMOTE_PORT
	FRP_TYPE:$FRP_TYPE
	EOF
	[ "$FRP_REMOTE_PORT_IS_OK" = "1" ] || return 1
	log_success "$FRP_SERVER_IP:$FRP_REMOTE_PORT >> $FRP_LOCAL_IP:$FRP_LOCAL_PORT ($FRP_TYPE)"
	FRP_CONF_NAME="frpc_${FRP_SERVER_IP}_${FRP_REMOTE_PORT}_${FRP_LOCAL_IP}_${FRP_LOCAL_PORT}"
	FRP_CONF="$FRP_CONF_ROOT/${FRP_CONF_NAME}.ini"
	FRP_PROXY_NAME="${FRP_CONF_NAME}_$(date +%s)"
	if get_external_ip; then
		FRP_PROXY_NAME="${EXTERNAL_IP}_${FRP_CONF_NAME}"
	else
		FRP_PROXY_NAME="${FRP_CONF_NAME}_$(date +%s)"
	fi
	frp_client_conf
	frp_client_supervisor
	return 0
}

frp_client_conf() {
	cat <<-EOF > $FRP_CONF
	[common]
	server_addr = $FRP_SERVER_IP
	server_port = $FRP_SERVER_PORT
	$([ "$FRP_KCP" = "1" ] && echo "protocol = kcp")
	$([ -z "$FRP_TOKEN" ] || echo "token = $FRP_TOKEN")

	[$FRP_PROXY_NAME]
	type = $FRP_TYPE
	$([ "$FRP_LOCAL_PORT" = "socks5" ] && echo "# http_proxy / socs5;plugin = socks5" | tr ';' '\n' || \
	echo "local_ip = $FRP_LOCAL_IP;local_port = $FRP_LOCAL_PORT" | tr ';' '\n')
	remote_port = $FRP_REMOTE_PORT
	use_encryption = true
	use_compression = true
	EOF
}

frp_client_supervisor() {
	supervisor_add "$FRP_CONF_NAME" --command "$FRP_CLIENT_BIN -c $FRP_CONF"
	return $?
}

frp_remove() {
	FRP_CONF="$FRP_CONF_ROOT/${1}.ini"
	FRP_SUPERVISOR="$SUPERVISOR_CONF_ROOT/${1}.conf"
	[ -f "$FRP_CONF" ] && rm -f "$FRP_CONF"
	[ -f "$FRP_SUPERVISOR" ] && rm -f "$FRP_SUPERVISOR" && SUPERVISOR_RELOAD="1"
	return 0
}

frp_list() {
	i=0
	FRP_LIST=$(ls $FRP_CONF_ROOT | grep -E "\.ini$" | sed -E "s/\.ini$//")
	if [ -z "$1" ]; then
		FRP_LIST=$(while read FRP_NAME
		do
			[ -f "$FRP_CONF_ROOT/${FRP_NAME}.ini" ] && {
				i=$((i+1))
				echo "[$i]    $FRP_NAME    $(supervisor_status "$FRP_NAME")"
			}
		done<<-EOF
		$FRP_LIST
		EOF
		)
		string_by_columns "$FRP_LIST" "    " "+2" "ll"
	else
		FRP_LIST=$(echo "$FRP_LIST" | grep -E "^$1\$")
		[ -z "$FRP_LIST" ] || {
			echo "[$i] $1    $(supervisor_status "$1")"
			echo "- $FRP_CONF_ROOT/${1}.ini"
			cat "$FRP_CONF_ROOT/${1}.ini"
		}
	fi
	# ps aux | grep -E "(frpc|frps) "
	return 0
}

frp_version() {
	while read _FRP_VERSION_
	do
		echo "${_FRP_VERSION_}"$([ "$FRP_VERSION" = "$_FRP_VERSION_" ] && echo " *")
	done <<-EOF
	$(ls $FRP_ROOT -1 2>/dev/null)
	EOF
}

nfs_reload() {
	if has_package "exportfs"; then
		exportfs -r && return 0
	elif [ -d "/etc/init.d/nfs-kernel-server" ]; then
		/etc/init.d/nfs-kernel-server restart && return 0
	fi
	return 1
}

nfs_add_share() {
	# Windows /data *(rw,sync,insecure)
	sed -i "|^/data/download|d" "$NFS_CONF"
	echo "/data/download 192.168.1.0/24(rw,sync,insecure)" >> "$NFS_CONF"
	nfs_reload
}

geoip_update() {
	require_pkg "jq $PKG_MMDB" || return 1
	args_match "$@" "--key|-k" && __LICENSE_KEY__="$ARGS_MATCH_VALUE"
	__LICENSE_KEY__="${__LICENSE_KEY__:-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}"
	_FAILED_=0
	__CACHE_DIR__="$APP_CACHE_DIR/mmdb"
	[ -d "$__CACHE_DIR__" ] || mkdir -p "$__CACHE_DIR__"
	# ip data is older than maxmind.com
	[ -z "$__LICENSE_KEY__" ] && DB_RELEASE_DATE=$(c_curl -skL https://github.com/P3TERX/GeoLite.mmdb/releases/latest | grep -Eo '<h1[^>]+>[^<]+' | awk -F'>' '{print $NF}')
	while read DB
	do
		__DOWNLOADED__="0"
		DB_NAME="$DB.mmdb"
		DB_FILE="$GEOIP_ROOT/$DB_NAME"
		if [ -z "$__LICENSE_KEY__" ]; then
			download_file "https://github.com/P3TERX/GeoLite.mmdb/raw/download/$DB_NAME" "${DB_FILE}.tmp" && {
				mv "${DB_FILE}.tmp" "$DB_FILE" && __DOWNLOADED__="1"
			}
		else
			rm -rf "$__CACHE_DIR__/$DB.tar.gz" >/dev/null 2>&1
			download_file "https://download.maxmind.com/app/geoip_download?edition_id=${DB}&suffix=tar.gz&license_key=${__LICENSE_KEY__}" "$__CACHE_DIR__/$DB.tar.gz" && {
				tar_extract_remove "$__CACHE_DIR__/$DB.tar.gz" "$GEOIP_ROOT" "$DB_NAME" && __DOWNLOADED__="1"
			}
		fi
		[ "$__DOWNLOADED__" = "1" ] && {
			grep -q "$DB_NAME" "$GEOIP_VERSION_FILE" && sed -Ei "/^$DB_NAME /d" "$GEOIP_VERSION_FILE" 2>/dev/null
			DB_VERSION="$DB_NAME $(md5sum $DB_FILE | awk '{print $1}') $DB_RELEASE_DATE"
			echo "$DB_VERSION" >> "$GEOIP_VERSION_FILE"
		} || _FAILED_="1"
	done <<-EOF
	GeoLite2-ASN
	GeoLite2-City
	GeoLite2-Country
	EOF
	DB=$(c_curl -skL "https://db-ip.com/db/download/ip-to-city-lite" | grep -Eo "https?://[^\"^']+mmdb.gz")
	DB_NAME="$GEOIP_DB_CITY_LITE_NAME"
	DB_URL="$DB"
	DB_URL_OUTPUT="$APP_CACHE_DIR/$(echo $DB | awk -F'/' '{print $NF}')"
	DB_FILE="$GEOIP_ROOT/${DB_NAME}.mmdb"
	download_file "$DB_URL" "$DB_URL_OUTPUT" && {
		c_gzip -kfd "$DB_URL_OUTPUT" && mv "$(c_gzip -ql $DB_URL_OUTPUT | awk '{print $NF}')" "$DB_FILE"
		rm -f "$DB_URL_OUTPUT"
		DB_MD5=$(md5sum $DB_FILE | awk '{print $1}')
		DB_VERSION="$DB_NAME $DB_MD5 $(echo "$DB" | grep -Eo "[0-9]+-[0-9]+")"
		grep -q "$DB_NAME" "$GEOIP_VERSION_FILE" && sed -Ei "/^$DB_NAME /d" "$GEOIP_VERSION_FILE" 2>/dev/null
		echo "$DB_VERSION" >> "$GEOIP_VERSION_FILE"
	}
	cat "$GEOIP_VERSION_FILE"
	return 1
}

geoip_format_normal() {
	[ -z "$1" ] && return 1
	GEOIP_JSON=$(echo "$1" | tr -d "\n" | sed -E -e 's/<[^>]*>/,/g' -e 's/[[:blank:]]*([{}:,])[[:blank:]]*/\1/g' -e 's/,}/}/g' -e 's/}"/},"/g' -e "s/([a-z]{2})-([A-Z]{2})/\1_\2/g")
	[ -z "$GEOIP_JSON" ] && return 1
	return 0
}

geoip_format_json() {
	GEOIP_JSON_LANG=${2:-en}
	GEOIP_JSON_LANG_REGULAR="(if .$GEOIP_JSON_LANG? then .$GEOIP_JSON_LANG else .en end)"
	echo "$1" | jq "{
		\"ip\":.ip, 
		\"country_name\":(.registered_country?+.country?|.names?|$GEOIP_JSON_LANG_REGULAR),
		\"country_code\":(.registered_country?+.country?|.iso_code?),
		\"city\":.city?|.names?|$GEOIP_JSON_LANG_REGULAR,
		\"province\":.subdivisions?|.[0]|.names?|$GEOIP_JSON_LANG_REGULAR,
		\"latitude\":.location?|.latitude?|tostring,
		\"longitude\":.location?|.longitude?|tostring,
		\"as\":(if .autonomous_system_number? then \"AS\"+(.autonomous_system_number|tostring)+(.|.autonomous_system_organization?|\" - \"+.) else null end)
	}"
}

geoip_query() {
	GEOIP_QUERY_IP="$1"
	GEOIP_OUTPUT_FORMAT="${2:-json}"
	[ -z "$GEOIP_QUERY_IP" ] && return 1
	echo "$GEOIP_QUERY_IP" | grep -Eqi '^AS[0-9]+' && {
		GEOIP_QUERY_IP=$(echo "$GEOIP_QUERY_IP" | tr '[:lower:]' '[:upper:]')
		# Cloudflare: AS13335
		# https://www.cloudflare.com/cdn-cgi/trace
		c_curl -skL "https://ipinfo.io/widget/demo/${GEOIP_QUERY_IP}?dataset=asn" -H "referer: https://ipinfo.io/products/asn-api"
		return $?
	}
	has_package "$PKG_MMDB" >/dev/null 2>&1 || {
		c_curl -skL "https://ipinfo.io/widget/demo/${GEOIP_QUERY_IP}?dataset=geolocation" -H "referer: https://ipinfo.io/products/ip-geolocation-api" | jq '.data'
		return $?
	}
	is_ip "$GEOIP_QUERY_IP" || {
		is_domain "$GEOIP_QUERY_IP" && {
			GEOIP_QUERY_IP=$(c_dig "$GEOIP_QUERY_IP" +short | head -n1)
		}
		is_ip "$GEOIP_QUERY_IP" || {
			log_err "${LANG_NOT_VALID_IP}: $GEOIP_QUERY_IP"
			return 1
		}
	}
	[ -f "$GEOIP_DB_CITY" ] && [ -f "$GEOIP_DB_COUNTRY" ] && [ -f "$GEOIP_DB_ASN" ] && GEOIP_DB_OK="1"
	[ "$GEOIP_DB_OK" = "1" ] || {
		log_warn "$(string_with_args "$LANG_HAVE_TO_INSTALL_APP_FIRST" "geoip")"
		return 1
	}
	MMDB_BIN=$(which "mmdblookup")
	GEOIP_DATA_CITY=$($MMDB_BIN --file "$GEOIP_DB_CITY" --ip "$GEOIP_QUERY_IP" 2>/dev/null)
	geoip_format_normal "$GEOIP_DATA_CITY" && GEOIP_JSON_CITY="$GEOIP_JSON"
	GEOIP_DATA_ASN=$($MMDB_BIN --file "$GEOIP_DB_ASN" --ip "$GEOIP_QUERY_IP" 2>/dev/null)
	geoip_format_normal "$GEOIP_DATA_ASN" && GEOIP_JSON_ASN="$GEOIP_JSON"
	GEOIP_JSON_IP="{\"ip\":\"$GEOIP_QUERY_IP\"}"
	GEOIP_JSON=$(echo "$GEOIP_JSON_IP$GEOIP_JSON_CITY$GEOIP_JSON_ASN"|sed -e "s/}{/,/g")
	if [ "$GEOIP_OUTPUT_FORMAT" = "json" ]; then
		geoip_format_json "$GEOIP_JSON"
	elif [ "$GEOIP_OUTPUT_FORMAT" = "raw" ]; then
		echo "$GEOIP_JSON"
	else
		GEOIP_DATA=$(geoip_format_json "$GEOIP_JSON" | awk -F':' '/[a-z]/ {gsub(/^ | ?"|,/,"",$0); print $1"    : "$2}')
		string_by_columns "$GEOIP_DATA" "    " "+2" "rl"
		#echo "$GEOIP_DATA" | awk -F':' '/ip|country|city|province|latitude|longitude|as/ {gsub(/^ | ?"|,/,"",$0); TAB="	"; if (length($1)<8) TAB="		"; print $1TAB": "$2;}'
	fi
}

cloudflare_get_ip_ranges() {
	c_curl -skL "https://www.cloudflare.com/ips-v4"
	c_curl -skL "https://www.cloudflare.com/ips-v6"
}

cloudflare_warp_get_ip_ranges() {
	require_pkg "jq" || return 1
	_JSON_=$(geoip_query "AS13335")
	if args_match "$@" "-6"; then
		__IP_LIST__=$(echo "$_JSON_" | jq -r '.prefixes6[] | select( .id | contains("CLOUDFLARENET") ) | .netblock')
	else
		__IP_LIST__=$(echo "$_JSON_" | jq -r '.prefixes[] | select( .id | contains("CLOUDFLARENET") ) | .netblock')
	fi
	args_match "$@" "--geoip" && {
		echo "$__IP_LIST__" | while read IP
		do
			__IP__=$(echo "$IP" | awk -F'/' '{print $1}')
			# class_geoip geoip "$__IP__" | jq -r '.country_code'
			# # jq -r '[.country_code, .country_name, .city] | join("|")'
			echo "$IP|"$(class_geoip geoip $(echo "$IP" | awk -F'/' '{print $1}') | jq -r '[.country_code, .country_name, .city] | join("|")')
		done
	} || echo "$__IP_LIST__"
}

cloudflare_warp_get_best_ips() {
	args_match "$@" "-4" && __IPV4__=1
	args_match "$@" "-6" && __IPV6__=1
	args_match "$@" "-6" || args_match "$@" "-4" || __IPV4__=1 && __IPV6__=1
	get_pkg_arch "x86_64,x64,amd64:amd64" "i386,i686:386" "armv8,armv8l,arm64,aarch64:arm64" "armv7l:arm" >/dev/null || return 1
	__IPV4_FILE__="$__CACHE_DIR__/ipv4.txt"
	__IPV4_RESULT_FILE__="$__CACHE_DIR__/result_ipv4.csv"
	__IPV6_FILE__="$__CACHE_DIR__/ipv6.txt"
	__IPV6_RESULT_FILE__="$__CACHE_DIR__/result_ipv6.csv"
	mkdir -p "$__CACHE_DIR__"
	__BIN__="$__CACHE_DIR__/warpendpoint"
	[ -x "$__BIN__" ] || {
		curl -L -o $__BIN__ --retry 2 "https://gitlab.com/Misaka-blog/warp-script/-/raw/main/files/warp-yxip/warp-linux-${PKG_ARCH}" || return 1
		chmod +x $__BIN__
	}
	ulimit -n 102400
	[ "$__IPV4__" = "1" ] && {
		if args_match "$@" "--fast|-f"; then
			IPS_RANGES_V4="162.159.192,162.159.193,162.159.195,162.159.204,188.114.96,188.114.97,188.114.98,188.114.99"
			# IPS_RANGES_V4="162.159.192,162.159.193,162.159.195,188.114.96,188.114.97,188.114.98,188.114.99"
			# __IPS_V4__=$(echo "$IPS_RANGES_V4" | tr ',' '\n' | awk -vT=$(echo "$IPS_RANGES_V4"|tr ',' '\n'|wc -l) 'BEGIN{srand()} {
			# 	for (i=1;i<=(100/T);i++) {
			# 		A=int(rand()*256); printf("%s.%i\n",$0,A)
			# 	}
			# }' | sort -u)
			__IPS_V4__=$(echo "$IPS_RANGES_V4" | tr ',' '\n' | awk -vT=$(echo "$IPS_RANGES_V4"|tr ',' '\n'|wc -l) 'BEGIN{srand()} {
				for (i=1;i<=254;i++) {
					print $0"."i
				}
			}' | sort -u)
		elif args_match "$@" "--all|-a"; then
			__IPS_V4__=$(cloudflare_warp_get_ip_ranges | awk -F'/' '{gsub(/[0-9]+$/, "", $1); print $1}' | sort -u | awk '{
				for (i=1;i<=254;i++) {
					print $0 i
				}
			}')
		else
			__IPS_V4__=$(cloudflare_warp_get_ip_ranges | awk -F'/' '{gsub(/[0-9]+$/, "", $1); print $1}' | sort -u | awk '{
				for (i=1;i<=10;i++) {
					A=int(rand()*256); printf("%s%i\n",$0,A)
				}
			}')
		fi
		echo "$__IPS_V4__" > $__IPV4_FILE__
		$__BIN__ -file $__IPV4_FILE__ -output $__IPV4_RESULT_FILE__ -max 500
		[ -x $(which nmap) ] && {
			__IPV4_NMAP_RESULT_FILE__="${__IPV4_RESULT_FILE__}.nmap.txt"
			rm $__IPV4_NMAP_RESULT_FILE__
			cat $__IPV4_RESULT_FILE__ | awk -F',' '$2=="0.00%"{print $1}' | while read S
			do
				S_IP=$(echo "$S" | awk -F':' '{print $1}')
				S_PORT=$(echo "$S" | awk -F':' '{print $2}')
				nmap -p $S_PORT $S_IP | grep -q open && echo "$S" >> $__IPV4_NMAP_RESULT_FILE__
			done
		}
	}
	[ "$__IPV6__" = "1" ] && {
		IPS_RANGES_V6="2606:4700:d0,2606:4700:d1"
		__IPS_V6__=$(echo "$IPS_RANGES_V6" | tr ',' '\n' | awk -vT=$(echo "$IPS_RANGES_V4"|tr ',' '\n'|wc -l) 'BEGIN{srand()} {
			for (i=1;i<=100/T;i++) {
				A=int(rand()*65536); B=int(rand()*65536); C=int(rand()*65536); D=int(rand()*65536); printf("[%s::%x:%x:%x:%x]\n",$0,A,B,C,D)
			}
		}' | sort -u)
		echo "$__IPS_V6__" > $__IPV6_FILE__
		$__BIN__ -file $__IPV6_FILE__ -output $__IPV6_RESULT_FILE__ -max 500
	}
	[ "$__IPV4__" = "1" ] && string_by_columns "$(cat $__IPV4_RESULT_FILE__ | awk -F',' '$3!="timeout ms" {print} ' | sort -t, -nk2 -nk3 | uniq | head -10 | awk -F',' '{print $1"    "$2"    "$3}')" "    " "+4"
	[ "$__IPV6__" = "1" ] && string_by_columns "$(cat $__IPV6_RESULT_FILE__ | awk -F',' '$3!="timeout ms" {print} ' | sort -t, -nk2 -nk3 | uniq | head -10 | awk -F',' '{print $1"    "$2"    "$3}')" "    " "+4"
}

cloudflare_warp_wgcf_register() {
	get_pkg_arch "x86_64,x64,amd64:amd64" "i386,i686:386" "armv8,armv8l,arm64,aarch64:arm64" "armv7l:armv7" >/dev/null
	__BIN__="$__CACHE_DIR__/wgcf"
	__CONFIG_FILE__="$__CACHE_DIR__/wgcf-account.toml"
	[ -x "$__BIN__" ] || {
		__URL__=$(github_releases_url "ViRb3/wgcf" | grep -E "linux_$PKG_ARCH")
		
		chmod +x $__BIN__
	}
	$__BIN__ register --config $__CONFIG_FILE__ --accept-tos
}

cloudflare_warp_wgcf_docker() {
	__WGCF_CACHE_DIR__="$APP_CACHE_DIR/wgcf"
	has_package "docker" || return 1
	case "$2" in
		"create"|"c")
			args_match "$@" "--number|-n" && __DOCKER_TOTAL__="$ARGS_MATCH_VALUE"
			echo "$__DOCKER_TOTAL__" | grep -Eq '^[1-9][0-9]*$' || __DOCKER_TOTAL__="1"
			__DOCKER_C__="$__DOCKER_TOTAL__"
			while [ "$__DOCKER_C__" -gt 0 ]
			do
				__WGCF_INDEX__=0
				while true
				do
					__WGCF_INDEX__=$((__WGCF_INDEX__+1))
					__WGCF_NAME__=$(echo "$__WGCF_INDEX__" | awk '{S=$0; for (i=4-length($0); i>0; i--) {S="0"S}; print "wgcf"S }')
					__WGCF_CONF_DIR__="$__WGCF_CACHE_DIR__/$__WGCF_NAME__"
					[ -d "$__WGCF_CONF_DIR__" ] || {
						mkdir -p $__WGCF_CONF_DIR__ >/dev/null 2>&1
						docker run --rm -d \
							--name ${__WGCF_NAME__} \
							--sysctl net.ipv6.conf.all.disable_ipv6=0 \
							--privileged --cap-add net_admin \
							-v /lib/modules:/lib/modules \
							-v ${__WGCF_CONF_DIR__}:/wgcf \
							neilpang/wgcf-docker >&2
						[ "$?" = "0" ] && echo "$__WGCF_NAME__" || rm -rf "$__WGCF_CONF_DIR__"
						break
					}
				done <<-EOF
				$(ls -d ${__WGCF_CACHE_DIR__}/wgcf* 2>/dev/null| grep -E '/wgcf[0-9]+$')
				EOF
				__DOCKER_C__=$((__DOCKER_C__-1))
			done
			;;
		"remove"|"rm")
			__WGCF_NAME__="$3"
			echo "$__WGCF_NAME__" | grep -Eq '^[0-9]{1,4}$' && __WGCF_NAME__=$(echo "$__WGCF_INDEX__" | awk '{S=$0; for (i=4-length($0); i>0; i--) {S="0"S}; print "wgcf"S }')
			docker stop "$__WGCF_NAME__"
			;;
		"list"|"ls")
			docker ps -a -f ancestor=neilpang/wgcf-docker
			;;
		"clean")
			while read _D_
			do
				docker inspect $(echo "$_D_" | awk -F'/' '{print $NF}') >/dev/null 2>&1 || rm -rf "$_D_"
			done <<-EOF
			$(ls -d ${__WGCF_CACHE_DIR__}/wgcf* 2>/dev/null| grep -E '/wgcf[0-9]+$')
			EOF
			;;
		"usage")
			cat <<-EOF
			get warp ip
			docker run --rm --network container:wgcf0001  curlimages/curl curl -skL ipinfo.io
			EOF
			;;
	esac
}

cloudflare_warp_warpgo_init() {
	get_pkg_arch "x86_64,x64,amd64:amd64" "i386,i686:386" "armv8,armv8l,arm64,aarch64:arm64" "armv7l:armv7" >/dev/null
	__BIN__="$__CACHE_DIR__/warp-go"
	args_match "$@" "--device-name|-n" && __DEVICE_NAME__="$ARGS_MATCH_VALUE" || __DEVICE_NAME__="$(cat /proc/sys/kernel/hostname)"
	[ -z "$__DEVICE_NAME__" ] && __DEVICE_NAME__=$(date +%s | md5sum | awk '{print $1}')
	args_match "$@" "--config|-c" && __CONF__="$ARGS_MATCH_VALUE" || __CONF__="$__CACHE_DIR__/warp.conf"
	args_match "$@" "--team|-t" && __TEAM_NAME__="$ARGS_MATCH_VALUE"
	args_match "$@" "--email|-e" && __TEAM_EMAIL__="$ARGS_MATCH_VALUE"
	args_match "$@" "--license|-l" && __WARP_PLUS_LICENSE__="$ARGS_MATCH_VALUE"
	[ -x "$__BIN__" ] || {
		__URL__=$(gitlab_releases_url "ProjectWARP/warp-go" | grep -E "linux_$PKG_ARCH\.")
		download_file "$__URL__" "$__CACHE_DIR__" && {
			tar_extract_remove "$__CACHE_DIR__/$DOWNLOAD_FILE_NAME" "$__CACHE_DIR__" "warp-go" && {
				chmod +x "$__BIN__"
			}
		}
	}
	$__BIN__ -v >/dev/null 2>&1 && CF_WARPGO_BIN="$__BIN__" && return 0
	return 1
}

cloudflare_warp_warpgo_register() {
	cloudflare_warp_warpgo_init "$@" || return 1
	__HEADER__=$(cat <<-EOF
	$(draw_line "=")
	               Warp Login App
	$(draw_line "=")
	EOF
	)
	# Team
	[ -z "$__TEAM_NAME__" ] || {
		echo "$__TEAM_EMAIL__" | grep -Eq '^[^@]+@[-0-3a-z.]+$' || {
			while true
			do
				cat <<-EOF
				$__HEADER__
				Get a login code emailed to you
				$(draw_line "-")
				EOF
				read -p "Email:" __TEAM_EMAIL__
				echo "$__TEAM_EMAIL__" | grep -Eq '^[^@]+@[-0-3a-z.]+$' && break
			done
		}
		__TEAM_API_URL__="https://web--public--warp-team-api--coia-mfs4.code.run"
		__S1_URL__="$__TEAM_API_URL__"
		__S1_RES__=$(c_curl -si "$__S1_URL__" --data-raw "teamName=${__TEAM_NAME__}")
		echo "$__S1_RES__" | grep -Eqi '^location:.*/login/' || echo "$__S1_RES__" && return 1
		__COOKIE_CF_AppSession__=$(echo "$__S1_RES__" | grep -Eoi 'set-cookie:\s*CF_AppSession=[^;]+' | sed -E 's/set-cookie:\s*//g')
		__S2_URL__=$(echo "$__S1_RES__" | grep -E '^location:' | tr -d ' ' | awk -F':' '{print $2}' | tr -d '\r\n' | sed -E 's|/login/|/verify-code/|')
		__S2_RES__=$(c_curl -si "${__TEAM_API_URL__}${__S2_URL__}" --data-raw "email=$(echo $__TEAM_EMAIL__|sed -e 's/@/%40/')&client_id=&connector_id=&connector_type=&redirect_url=")
		echo "$__S2_RES__" | grep -Eqi '^location:.*/verify-code/' || echo "$__S2_RES__" && return 1
		__S3_URL__=$(echo "$__S2_RES__" | grep -E '^location:' | tr -d ' ' | awk -F':' '{print $2}' | tr -d '\r\n')
		__S4_DATA_NONCE__=$(echo "$__S3_URL__" | grep -Eo 'nonce=[0-9a-zA-Z]+')
		while true
		do
			__EMAIL_CODE__=""
			cat <<-EOF
			$__HEADER__
			A code has been emailed to you ($__TEAM_EMAIL__).
			[R]esend email
			[E]xit
			$(draw_line "-")
			EOF
			read -p "Enter code (eg. 665066):" __EMAIL_CODE__
			if echo "$__EMAIL_CODE__" | tr -d ' ' |grep -Eq '^[0-9]{6}$'; then
				__EMAIL_CODE__=$(echo "$__EMAIL_CODE__" | tr -d ' ')
				__S4_RES__=$(c_curl -si "${__TEAM_API_URL__}/cdn-cgi/access/callback/${__TEAM_NAME__}.cloudflareaccess.com" --cookie "$__COOKIE_CF_AppSession__" --data-raw "code=${__EMAIL_CODE__}&${__S4_DATA_NONCE__}")
				__S5_URL__=$(echo "$__S4_RES__" | grep -E '^location:' | tr -d ' ' | awk -F':' '{print $2}' | tr -d '\r\n')
				__S5_COOKIE__=$(echo "$__S4_RES__" | grep -Eoi 'set-cookie:\s*[^;]+' | sed -E 's/set-cookie:\s*//g' | tr '\n' ';')
				__S5_RES__=$(c_curl -si --cookie "$__S5_COOKIE__$__COOKIE_CF_AppSession__" "${__TEAM_API_URL__}${__S5_URL__}")
				__S6_URL__=$(echo "$__S5_RES__" | grep -E '^location:' | tr -d ' ' | awk -F':' '{print $2}' | tr -d '\r\n')
				__S6_RES__=$(c_curl -sL --cookie "$__S5_COOKIE__$__COOKIE_CF_AppSession__" "${__TEAM_API_URL__}${__S6_URL__}")
				echo "$__S6_RES__" | grep -iq 'Team Token' && __TEAM_TOKEN__=$(echo "$__S6_RES__" | tail -n1) && break
				echo "$__S4_RES__"
			elif echo "$__EMAIL_CODE__" | grep -Eq '^[rR]$'; then
				c_curl "${__TEAM_API_URL__}/cdn-cgi/access/resend-code/${__TEAM_NAME__}.cloudflareaccess.com?${__S4_DATA_NONCE__}"
			elif echo "$__EMAIL_CODE__" | grep -Eq '^[eE]$'; then
				break
			fi
		done
		[ -z "$__TEAM_TOKEN__" ] && echo "[ERR] Failed to generate team token." && return 1
		$CF_WARPGO_BIN --register --config "$__CONF__" --device-name "$__DEVICE_NAME__" --team-config "${__TEAM_TOKEN__}"
		# echo "$__TEAM_TOKEN__"
		return $?
	}
	# Warp Plus
	[ -z "$__WARP_PLUS_LICENSE__" ] || {
		$CF_WARPGO_BIN --register --config "$__CONF__" --device-name "$__DEVICE_NAME__" --license $__WARP_PLUS_LICENSE__
		return $?
	}
	$CF_WARPGO_BIN --register --config "$__CONF__" --device-name "$__DEVICE_NAME__"
	return $?
}

cloudflare_warp_warpgo_conf() {
	cloudflare_warp_warpgo_init "$@" || return 1
	echo "file: $__CONF__" >&2
	cat $__CONF__
}

cloudflare_warp_warpgo_wireguard() {
	cloudflare_warp_warpgo_init "$@" || return 1
	__WIREGUARD_CONF__=$(echo $__CONF__ | awk '{gsub(/\.conf$/,"",$0); print $0".wireguard.conf"}')
	$CF_WARPGO_BIN -config $__CONF__ -export-wireguard $__WIREGUARD_CONF__ >/dev/null || return 1
	echo "wireguard conf: $__WIREGUARD_CONF__" >&2
	cat $__WIREGUARD_CONF__
	return 0
}

cloudflare_warp_plus() {
	args_match "$@" "--device-id|-i" && __DEVICE_ID__="$ARGS_MATCH_VALUE"
	# [ -z "$__DEVICE_ID__" ] && __DEVICE_ID__=$(c_curl -si "https://warp.plus/GEXF1" | grep -Eoi "referrer=[^=]+$" | awk -F'=' '{print $2}')
	[ -z "$__DEVICE_ID__" ] && echo "Please set device id with '--device-id|-i'" >&2 && return 1
	__INSTALL_ID__=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 22)
	__URL__="https://api.cloudflareclient.com/v0a$(shuf -i 100-999 -n 1)/reg"
	__RES__=$(c_curl -X POST -m 10 \
		-sA "okhttp/3.12.1" \
		-H 'content-type: application/json' \
		-H 'Host: api.cloudflareclient.com' \
		--data "{\"key\": \"$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 43)=\",\"install_id\": \"${__INSTALL_ID__}\",\"fcm_token\": \"APA91b${__INSTALL_ID__}$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 134)\",\"referrer\": \"$__DEVICE_ID__\",\"warp_enabled\": false,\"tos\": \"$(date -u +%FT%T.$(tr -dc '0-9' </dev/urandom | head -c 3)Z)\",\"type\": \"Android\",\"locale\": \"en_US\"}" \
		"$__URL__")
	[ -z "$(echo "$__RES__" | jq -r '.id')" ] && return 1
	echo "success" >&2
	return 0
}

cloudflare_warp_plus_register() {
	_BASE_KEYS_="1w38jO2c-W8y195VU-Bw041o8V,H94b52wz-1I7sc90Z-9YAN1R46,S27m19Tu-895xO0kX-R4ht8J65,6n0dZK49-z982C0YH-5cbV0r42,14SL78aD-95U7Qg6r-ur10N3g5"
	_BASE_KEY_=$(echo "$_BASE_KEYS_" | awk -F',' 'BEGIN{srand()} {RAN=rand()*NF+1; gsub(/\..*/,"",RAN); print $(RAN)}')
	_COMMON_HEADERS_='"CF-Client-Version": "a-6.11-2223", "Host": "api.cloudflareclient.com", "User-Agent": "okhttp/3.12.1"'
	_BASE_URL_="https://api.cloudflareclient.com/v0a2223"
	_OPTION_HEADER_=$(echo "$_COMMON_HEADERS_"| sed -E -e 's/", *"/"\n"/g' | sed -E -e 's/"//g' -e 's/(.*)/-H "\1"/' | tr '\n' ' ')
	_RES_=$(eval "c_curl -o- -X POST $_OPTION_HEADER_ ${_BASE_URL_}/reg")
	echo "$_RES_" | jq
	_DATA_ID_=$(echo "$_RES_" | jq -r '.id')
	_DATA_LICENSE_=$(echo "$_RES_" | jq -r '.account | .license')
	_DATA_TOKEN_=$(echo "$_RES_" | jq -r '.token')
	_RES_=$(eval "c_curl -o- -X POST $_OPTION_HEADER_ ${_BASE_URL_}/reg")
	echo "$_RES_" | jq
	_DATA_REF_ID_=$(echo "$_RES_" | jq -r '.id')
	_DATA_REF_TOKEN_=$(echo "$_RES_" | jq -r '.token')
	_RES_=$(c_curl -X PATCH -d "{\"referrer\":\"${_DATA_REF_ID_}\"}" -H "Content-Type: application/json; charset=UTF-8" -H "Authorization: Bearer ${_DATA_TOKEN_}" ${_BASE_URL_}/reg/${_DATA_ID_})
	_RES_=$(c_curl -X PUT -d "{\"license\":\"${_BASE_KEY_}\"}" -H "Content-Type: application/json; charset=UTF-8" -H "Authorization: Bearer ${_DATA_TOKEN_}" ${_BASE_URL_}/reg/${_DATA_ID_}/account)
	_RES_=$(c_curl -X PUT -d "{\"license\":\"${_DATA_LICENSE_}\"}" -H "Content-Type: application/json; charset=UTF-8" -H "Authorization: Bearer ${_DATA_TOKEN_}" ${_BASE_URL_}/reg/${_DATA_ID_}/account)
	_RES_=$(c_curl -H "Authorization: Bearer ${_DATA_TOKEN_}" ${_BASE_URL_}/reg/${_DATA_ID_}/account)
	echo "$_RES_" | jq
	_WARP_PLUS_LICENSE_=$(echo "$_RES_" | jq '.license')
	_RES_=$(c_curl -X DELETE -H "Authorization: Bearer ${_DATA_REF_TOKEN_}" ${_BASE_URL_}/reg/${_DATA_REF_ID_})
	_RES_=$(c_curl -X DELETE -H "Authorization: Bearer ${_DATA_TOKEN_}" ${_BASE_URL_}/reg/${_DATA_ID_})
}

cloudflare_speedtest() {
	# https://speed.cloudflare.com/locations
	_PKG_TMP_ROOT_="$APP_CACHE_DIR/CloudflareSpeedTest"
	_DL_URL_=$(github_releases_url "XIU2/CloudflareSpeedTest" | grep "linux_$(get_pkg_arch "x86_64:amd64").*\.tar.gz")
	[ -z "$_DL_URL_" ] && return 1
	download_file "$_DL_URL_" "$_PKG_TMP_ROOT_" || return 1
	tar_extract_remove "$_PKG_TMP_ROOT_/$DOWNLOAD_FILE_NAME" "$_PKG_TMP_ROOT_" || return 1
	# $_PKG_TMP_ROOT_/CloudflareST -tp 443 -url https://jp.cloudflarest.link -sl 3 -tl 200 -dn 10 -cfcolo KIX
	return 0
}

ping_by_itdog() {
	[ -z "$1" ] && return 1
	log_debug "checking $1 ..."
	_PINK_RESULT_=$(curl -skL "https://www.itdog.cn/ping/$1" | \
		tr -d '\n\t' | \
		sed -E -e 's/<tr/\n<tr/g' -e 's/(<\/tr>)/\1\n/g' -e 's/> +</></g' -e 's/ {2,999}//g' | \
		grep '^<tr' | \
		sed -E -e 's/<(span|i)[^>]*>[^<]*<\/(span|i)>//g' -e 's/<img[^>]*>//g' -e 's/<\/?tr[^>]*>//g' -e 's/<\/(td|th)><(td|th)[^>]*>/::::/g' -e 's/<\/?(td|th)[^>]*>//g')
	echo "$_PINK_RESULT_"
}

send_to_telegram() {
	# Telegram Robot API Document: https://core.telegram.org/api#bot-api
	echo ""
}

send_to_wecom() {
	# WeCom Robot API Document: https://developer.work.weixin.qq.com/document/path/91770
	# Notice: limit send 20 messages per minute.
	args_match "$@" "(--content|-c)" && SEND_CONTENT="$ARGS_MATCH_VALUE"
	args_match "$@" "(--type|-t)" && SEND_TYPE="$ARGS_MATCH_VALUE"
	args_match "$@" "(--to-users|-u)" && SEND_TO_USERS="$ARGS_MATCH_VALUE"
	# Group Chat Robot
	args_match "$@" "(--key|-K)" && SEND_KEY="$ARGS_MATCH_VALUE"
	# Self-built App
	args_match "$@" "(--corpid|-C)" && SEND_CORPID="$ARGS_MATCH_VALUE"
	args_match "$@" "(--app-secret|-S)" && SEND_APP_SECRET="$ARGS_MATCH_VALUE"
	args_match "$@" "(--app-id|-A)" && SEND_APP_ID="$ARGS_MATCH_VALUE"
	[ -z "$SEND_KEY" ] && SEND_KEY="$WECOM_KEY"
	[ -z "$SEND_APP_ID" ] || [ -z "$SEND_CORPID" ] || [ -z "$SEND_APP_SECRET" ] || {
		SEND_APP_TOKEN=$(c_curl -skL "'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=${SEND_CORPID}&corpsecret=${SEND_APP_SECRET}'" | tr -d '\n' | grep -Eo '"access_token":\s*"[^"]+"' | awk -F'"' '{print $4}')
		[ -z "$SEND_APP_TOKEN" ] && return 1
		SEND_FROM="app"
		SEND_PUSH_URL="https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=${SEND_APP_TOKEN}"
		SEND_DATA_APP_ID="\"agentid\" : ${SEND_APP_ID},"
		SEND_DATA_USERS="\"touser\" : \"${SEND_TO_USERS:-@all}\","
	}
	[ -z "$SEND_PUSH_URL" ] && {
		[ -z "$SEND_KEY" ] && return 1
		SEND_FROM="robot"
		SEND_PUSH_URL="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=${SEND_KEY}"
	}
	# echo "$SEND_PUSH_URL"
	# exit
	# Message
	SEND_TYPE="${SEND_TYPE:-text}"
	[ "$SEND_TYPE" = "md" ] && SEND_TYPE="markdown"
	[ "$SEND_TYPE" = "img" ] && SEND_TYPE="image"
	SEND_DATA_CONTENT="\"content\": \"$SEND_CONTENT\""
	[ "$SEND_TYPE" = "news" ] && {
		# SEND_CONTENT: { title, description, url, picurl }
		SEND_DATA_CONTENT="\"articles\":[$SEND_CONTENT]"
	}
	[ "$SEND_TYPE" = "template_card" ] && {
		# card_type: text_notice / news_notice
		SEND_DATA_CONTENT="$SEND_CONTENT"
	}
	[ "$SEND_TYPE" = "image" ] && {
		[ "$SEND_FROM" = "robot" ] && {
			if echo "$SEND_CONTENT" | grep -Eq 'https?://'; then
				SEND_DATA_BASE64=$(c_curl -skL "'$SEND_CONTENT'" | base64 | tr -d '\n')
				SEND_DATA_BASE64_MD5=$(echo "$SEND_DATA_BASE64" | base64 -d | md5sum | awk '{print $1}')
			else
				SEND_DATA_BASE64=$(base64 "$SEND_CONTENT" | tr -d '\n')
				SEND_DATA_BASE64_MD5=$(md5sum "$SEND_CONTENT" | awk '{print $1}')
			fi
			SEND_DATA_CONTENT="\"base64\": \"$SEND_DATA_BASE64\", \"md5\": \"$SEND_DATA_BASE64_MD5\""
		}
		[ "$SEND_FROM" = "app" ] && {
			SEND_DATA_FILE_RES=$(c_curl -skL "'https://qyapi.weixin.qq.com/cgi-bin/media/uploadimg?access_token=${SEND_APP_TOKEN}'" -F "media=@${SEND_CONTENT}")
			SEND_DATA_MEDIA_URL=$(echo "$SEND_DATA_FILE_RES" | grep -Eo '"url":\s*"[^"]+"' | awk -F'"' '{print $4}')
		}
	}
	[ "$SEND_TYPE" = "file" ] && {
		# File size limit set from 5B to 20M. The file will be deleted after 3 days.
		[ -f "$SEND_CONTENT" ] || return 1
		[ "$SEND_FROM" = "robot" ] && SEND_UPLOAD_API="https://qyapi.weixin.qq.com/cgi-bin/webhook/upload_media?key=${SEND_KEY}&type=file"
		[ "$SEND_FROM" = "app" ] && SEND_UPLOAD_API="https://qyapi.weixin.qq.com/cgi-bin/media/upload?access_token=${SEND_APP_TOKEN}&type=file"
		SEND_DATA_FILE_RES=$(c_curl -skL "'$SEND_UPLOAD_API'" -F "media=@${SEND_CONTENT}")
		SEND_DATA_MEDIA_ID=$(echo "$SEND_DATA_FILE_RES" | grep -Eo '"media_id":\s*"[^"]+"' | awk -F'"' '{print $4}')
		[ -z "$SEND_DATA_MEDIA_ID" ] && echo "[ERR] Failed to get WeCom App Access Token" >&2 && return 1
		SEND_DATA_CONTENT="\"media_id\": \"${SEND_DATA_MEDIA_ID}\""
		[ "$SEND_FROM" = "app" ] && {
			# image:jpg,png / voice:amr / video:mp4
			if echo "$SEND_CONTENT" | grep -Eq '\.(jpg|jpeg|png|gif|svg|webp)$'; then
				SEND_TYPE="image"
			elif echo "$SEND_CONTENT" | grep -Eq '\.(amr)$'; then
				SEND_TYPE="voice"
			elif echo "$SEND_CONTENT" | grep -Eq '\.(mp4)$'; then
				SEND_TYPE="video"
			fi
		}
	}
	[ "$SEND_FROM" = "robot" ] && {
		[ -z "$SEND_TO_USERS" ] || {
			SEND_TO_USERS_FIELD_NAME="mentioned_list"
			echo "$SEND_TO_USERS" | grep -Eq '[0-9]{11}' && SEND_TO_USERS_FIELD_NAME="mentioned_mobile_list"
			SEND_DATA_CONTENT="$SEND_DATA_CONTENT, \"$SEND_TO_USERS_FIELD_NAME\": ["$(echo "$SEND_TO_USERS" | sed -E 's/,/", "/g')"],"
		}
	}
	SEND_DATA=$(cat <<-EOF
	{
		$SEND_DATA_USERS
		$SEND_DATA_APP_ID
		"msgtype": "$SEND_TYPE",
		"$SEND_TYPE": {
			$SEND_DATA_CONTENT
		}
	}
	EOF
	)
	echo "$SEND_DATA" >&2
	c_curl "'$SEND_PUSH_URL'" \
		-H "'Content-Type: application/json'" \
   	-d "'$SEND_DATA'"
}

image_pick_color() {
	args_match "$@" "(--file|-f)" && {
		IMAGE_PICK_FILE="$ARGS_MATCH_VALUE"
	}
	args_match "$@" "(--pixel|-p)" && {
		IMAGE_PICK_PIXELS=$(echo "$ARGS_MATCH_VALUE" | awk -F"$DELIMITER" '{for (i=1;i<=NF;i++) {P=P==""?"%[pixel:p{"$i"}]":P",%[pixel:p{"$i"}]"}} END{print P}')
		echo "PIXEL: $IMAGE_PICK_PIXELS"
	}
	# convert rose: -format "%[pixel:p{40,50}]" info:
	convert "$IMAGE_PICK_FILE" -format "$IMAGE_PICK_PIXELS" info:
}

speedtest_filter() {
	SPEEDTEST_SERVERS=$(speedtest-cli --list 2>/dev/null)
	[ -z "$SPEEDTEST_COUNTRY" ] || SPEEDTEST_SERVERS=$(echo "$SPEEDTEST_SERVERS" | grep -Ei "\(.*, $SPEEDTEST_COUNTRY\)")
	[ -z "$SPEEDTEST_CITY" ] || SPEEDTEST_SERVERS=$(echo "$SPEEDTEST_SERVERS" | grep -Ei "\(.*$SPEEDTEST_CITY.*,[^,]*\)")
	[ -z "$SPEEDTEST_ISP" ] || SPEEDTEST_SERVERS=$(echo "$SPEEDTEST_SERVERS" | grep -Ei "[0-9]+\) [^(]*$SPEEDTEST_ISP")
	[ -z "$SPEEDTEST_ID" ] || SPEEDTEST_SERVERS=$(echo "$SPEEDTEST_SERVERS" | grep -Ei "^ *$SPEEDTEST_ID\)")
	SPEEDTEST_SERVERS_COUNT=$(echo "$SPEEDTEST_SERVERS" | wc -l)
	[ -z "$SPEEDTEST_SERVERS" ] && return 1
	return 0
}

speedtest_list() {
	speedtest_filter && echo "$SPEEDTEST_SERVERS"
	echo ""
	string_with_args "$LANG_FOUND_RESULT" "$SPEEDTEST_SERVERS_COUNT"
}

speedtest_test() {
	speedtest_filter || return 1
	string_by_columns "Ping    Download    Upload    Location / ISP" "    " "16" "ll"
	while read SERVER
	do
		[ -z "$SERVER" ] || {
			eval $(echo "$SERVER" | awk -F'(\)|\()' '{
				for (i=1;i<=NF;i++) {gsub(/^ +/,"",$i); gsub(/ +$/,"",$i);gsub(/(\[|\])/,"",$i)}
				{print "SERVER_ID=\""$1"\";SERVER_ISP=\""$2"\";SERVER_LOCATE=\""$3"\";SERVER_DISTANCE=\""$4"\""}
			}')
			# echo "$SERVER"
			SPEEDTEST_RESULT=$(speedtest-cli --server "$SERVER_ID" $SPEEDTEST_OPTION)
			eval $(echo "$SPEEDTEST_RESULT" | awk -F':' '{gsub(/^ +/,"",$2); gsub(/ .*/,"",$2)}
			tolower($1)~/ping/ {PING=$2}
			tolower($1)~/download/ {DOWN=$2>0?(int($2*100/8))/100:0}
			tolower($1)~/upload/ {UP=$2>0?(int($2*100/8))/100:0}
			END{print "SPEEDTEST_PING=\""PING"\"; SPEEDTEST_DOWNLOAD=\""DOWN"\";SPEEDTEST_UPLOAD=\""UP"\""}')
			string_by_columns "$SPEEDTEST_PING ms    $SPEEDTEST_DOWNLOAD MB/s    $SPEEDTEST_UPLOAD MB/s    $SERVER_LOCATE ($SERVER_ISP)" "    " "16" "ll"
		}
	done<<-EOF
	$SPEEDTEST_SERVERS
	EOF
}

disktest_test() {
	DISKTEST_SIZE=${1:-1g}
	DISKTEST_BLOCK_SIZE="64k"
	DISKTEST_SIZE=$(echo "$DISKTEST_SIZE" | tr '[:upper:]' '[:lower:]')
	echo "$DISKTEST_SIZE" | grep -Eq '^[0-9.]*(k|m|g)b?$' || return 1
	DISKTEST_SIZE=$(echo "$DISKTEST_SIZE" | tr -d 'b' | awk '$0~/k/{gsub("k","",$0); SIZE=int($0)} $0~/m/{gsub("m","",$0); SIZE=int($0*1024)} $0~/g/{gsub("g","",$0); SIZE=int($0*1024*1024)} END{if (SIZE>0) {print SIZE}}')
	[ -z "$DISKTEST_SIZE" ] && return 1
	DISKTEST_COUNT=$(echo "$DISKTEST_SIZE" | awk '{print int($0/64)}')
	[ "$DISKTEST_COUNT" -lt 1 ] && return 1
	[ "$DISKTEST_MEM" = "1" ] && DISKTEST_FILE="/dev/shm/disktest"
	dd if=/dev/zero of=${DISKTEST_FILE} bs=${DISKTEST_BLOCK_SIZE} count=${DISKTEST_COUNT} conv=fdatasync status=progress
	rm -f ${DISKTEST_FILE} 2>/dev/null
}

openai_test() {
	__RES__=$(curl -skL 'https://chat.openai.com/' \
		-H 'authority: chat.openai.com' \
		-H 'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7' \
		-H 'accept-language: en-US,en;q=0.9,zh-CN;q=0.8,zh-TW;q=0.7,zh;q=0.6' \
		-H 'cache-control: no-cache' \
		-H 'pragma: no-cache' \
		-H 'sec-ch-ua: "Google Chrome";v="111", "Not(A:Brand";v="8", "Chromium";v="111"' \
		-H 'sec-ch-ua-mobile: ?0' \
		-H 'sec-ch-ua-platform: "Linux"' \
		-H 'sec-fetch-dest: document' \
		-H 'sec-fetch-mode: navigate' \
		-H 'sec-fetch-site: same-site' \
		-H 'sec-fetch-user: ?1' \
		-H 'upgrade-insecure-requests: 1' \
		-H 'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36' \
		--compressed)
	echo "$__RES__" | grep -iq 'Access denied' && echo "[ERR] Your IP was blocked by openai.com" >&2 && return 2
	echo "$__RES__" | grep -iq 'checking your browser' && echo "[OK] Your IP is ok." >&2 && return 0
	return 1
}

tmux_api() {
	has_package "tmux" || return 1
	[ -z "$1" ] && return 1
	eval $(echo "$1" | awk -F'/' '{print "__TMUX_PATH_A__=\""$1"\"; __TMUX_PATH_B__=\""$2"\"; __TMUX_PATH_C__=\""$3"\"; __TMUX_PATH_D__=\""$4"\""}')
	shift
	case "$__TMUX_PATH_A__" in
		"sessions")
			__TMUX_SESSIONS_INFO__=$(tmux list-sessions 2>/dev/null)
			__TMUX_SESSIONS__=$(echo "$__TMUX_SESSIONS_INFO__" | awk -F':' '{print $1}')
			if [ -z "$__TMUX_PATH_B__" -a -z "$__TMUX_PATH_C__" ]; then
				echo "$__TMUX_SESSIONS__"
			else
				if [ "$__TMUX_PATH_B__" = "info" -a -z "$__TMUX_PATH_C__" ]; then
					__TMUX_PATH_D__="$__TMUX_PATH_C__"
					__TMUX_PATH_C__="info"
				elif [ "$__TMUX_PATH_B__" = "run" -a -z "$__TMUX_PATH_C__" ]; then
					__TMUX_PATH_D__="$__TMUX_PATH_C__"
					__TMUX_SESSIONS__=$$
					__TMUX_PATH_C__="run"
				elif echo "$__TMUX_PATH_B__" | grep -q '\+$'; then
					__TMUX_SESSION_PREFIX__=$(echo "$__TMUX_PATH_B__" | tr -d '+')
					__LAST_INDEX__=$(echo "$__TMUX_SESSIONS__" | grep -E "^${__TMUX_SESSION_PREFIX__}[0-9]+$" | tail -n1 | grep -Eo '[1-9][0-9]+')
					[ -z "$__LAST_INDEX__" ] && __LAST_INDEX__="1" || __LAST_INDEX__=$((__LAST_INDEX__+1))
					__TMUX_SESSIONS__="${__TMUX_SESSION_PREFIX__}${__LAST_INDEX__}"
				elif echo "$__TMUX_PATH_B__" | grep -q '\*$'; then
					__TMUX_SESSION_PREFIX__=$(echo "$__TMUX_PATH_B__" | tr -d '*')
					__TMUX_SESSIONS__=$(echo "$__TMUX_SESSIONS__" | grep -E "^${__TMUX_SESSION_PREFIX__}.*")
				else
					__TMUX_SESSIONS__="$__TMUX_PATH_B__"
				fi
				case "$__TMUX_PATH_C__" in
					"info")
						while read __TMUX_SESSION__
						do
							echo "$__TMUX_SESSIONS_INFO__" | awk -F':' -v NAME="$__TMUX_SESSION__" '($1==NAME){print $0}'
						done <<-EOF
						$__TMUX_SESSIONS__
						EOF
						;;
					"run")
						__TMUX_CMD__=$(echo "$@" | tr '\n' '; ' | awk '{gsub(/; *$/,"",$0); print $0}')
						[ -z "$__TMUX_SESSIONS__" ] && __TMUX_SESSIONS__=$$
						while read __TMUX_SESSION__
						do
							[ -z "$__TMUX_SESSION__" ] || {
								tmux has-session -t "$__TMUX_SESSION__" >/dev/null 2>&1 || tmux new-session -d -s "$__TMUX_SESSION__"
								tmux send-keys -t "$__TMUX_SESSION__" "$__TMUX_CMD__ " ENTER
							}
						done <<-EOF
						$__TMUX_SESSIONS__
						EOF
						[ -z "$__TMUX_PATH_D__" ] || {
							[ "$__TMUX_PATH_D__" -gt 0 ] && sleep $__TMUX_PATH_D__ && tmux_api "$__TMUX_PATH_A__/$__TMUX_PATH_B__/capture"
						}
						;;
					"stop")
						while read __TMUX_SESSION__
						do
							[ -z "$__TMUX_SESSION__" ] || {
								tmux has-session -t "$__TMUX_SESSION__" && tmux send-keys -t "$__TMUX_SESSION__" C-c && echo "$__TMUX_SESSION__"
							}
						done <<-EOF
						$__TMUX_SESSIONS__
						EOF
						;;
					"kill")
						while read __TMUX_SESSION__
						do
							[ -z "$__TMUX_SESSION__" ] || {
								tmux kill-session -t "$__TMUX_SESSION__" && echo "$__TMUX_SESSION__"
							}
						done <<-EOF
						$__TMUX_SESSIONS__
						EOF
						;;
					"clear")
						while read __TMUX_SESSION__
						do
							[ -z "$__TMUX_SESSION__" ] || {
								tmux clear-history -t "$__TMUX_SESSION__" && echo "$__TMUX_SESSION__"
							}
						done <<-EOF
						$__TMUX_SESSIONS__
						EOF
						;;
					"capture"|"cap")
						__TMUX_START_LINE__="-"
						__TMUX_END_LINE__="-"
						[ -z "$2" ] || {
							[ "$2" -gt 0 ] && __TMUX_START_LINE__="-$2"
						}
						while read __TMUX_SESSION__
						do
							[ -z "$__TMUX_SESSION__" ] || {
								tmux capture-pane -t "$__SESSION__" -p -S $__TMUX_START_LINE__ -E $__TMUX_END_LINE__ 2>/dev/null
							}
						done <<-EOF
						$__TMUX_SESSIONS__
						EOF
						;;
					*)
						[ -z "$__TMUX_PATH_C__" ] && {
							__TMUX_TOTAL__="0"
							while read __TMUX_SESSION__
							do
								tmux has-session -t "$__TMUX_SESSION__" >/dev/null 2>&1 && __TMUX_TOTAL__=$((__TMUX_TOTAL__+1))
							done <<-EOF
							$__TMUX_SESSIONS__
							EOF
							echo "$__TMUX_TOTAL__"
							[ "$__TMUX_TOTAL__" = "0" ] && return 1
						}
				esac
			fi
			;;
	esac
	return 0
}

info_cpu() {
	if has_package "lscpu"; then
		CPU_INFO=$(lscpu | awk -F':' '{gsub(/[\t ]+$/,"",$1); gsub(/^[\t ]+/,"",$2); print $1"    : "$2}')
	else
		CPU_INFO=$(cat "/proc/cpuinfo" | awk -F':' 'BEGIN{IGNORECASE=1}
		{gsub(/[ \t]+$/,"",$1); gsub(/^[ \t]+/,"",$2)}
		$1~/model name|system type/ {DIFF=($2==PREV?0:1);PREV=$2}
		$1~/model name|system type|cpu MHz|cache size|flags|bogomips|machine|cpu model|implemented/ {if (DIFF==1) {gsub(/( +|\t+)$/,"",$1); gsub(/^ +/,"",$2); print $1"    : "$2}}
		$0=="" && DIFF==1 {print "-"}')
		CPU_INFO=$(cat <<-EOF
		$CPU_INFO
		cpu cores    : $(get_cpu_cores)
		EOF
		)
	fi
	string_by_columns "$CPU_INFO" "    " "+2" "ll"
}

info_disk() {
	df | grep "^/" | awk '{print $1"    "int($3/1024)"/"int($2/1024)"MB     "int($3/$2*100)"%"}'
}

info_hardware() {
	inxi -Fzxx
}

info_audio() {
	AUDIO: inxi -A
	aplay -l
	sudo lspci -vvv -s 00:1f.3
}

info_kallsyms() {
	cat /proc/kallsyms
}

info_all() {
	INFO_UPTIME=$(awk '{print int($1/(3600*24))" days, "int(($1%(3600*24))/3600)" hours, "int(($1%3600)/60)" mins"}' "/proc/uptime")
	INFO_LOAD_AVERAGE=$(cat /proc/loadavg)
	INFO_SERVER_TIME=$(date +"%F %r %Z%:::z")
	INFO_MEMORY_USED=$(free | awk 'NR==2{print int($3/1024)"/"int($2/1024)"MB ("int($3/$2*100)"%)"}')
	INFO_SWAP_USED=$(free | awk 'NR==3{if ($2>0) {print int($3/1024)"/"int($2/1024)"MB ("int($3/$2*100)"%)"} else {print "N/A"}}')
	INFO_DISK_USED=$(df /|awk '$6=="/"{print int($3/1024)"/"int($2/1024)"MB ("int($3/$2*100)"%)"}')
	INFO=$(cat <<-EOF
	$LANG_OS_VERSION    : $OS_NAME $OS_VERSION $([ -z "$OS_CODENAME" ] || echo "($OS_CODENAME)") / $OS_ARCH
	$LANG_OS_BASED_ON    : $OS_BASE
	$LANG_KERNEL_VERSION    : $KERNEL_VERSION_INSTALLED
	$LANG_VIRT_TYPE    : $(get_virt_type)
	$LANG_CPU    : $(cat /proc/cpuinfo | awk -F':' '$1~/model name|system type/ {gsub(/^ /,"",$2); NAME=($2!=PREV&&NAME!=""?NAME", "$2:$2); PREV=$2} END{print NAME}') ($(get_cpu_cores)c)
	$LANG_MEMORY_USED    : $INFO_MEMORY_USED
	$LANG_SWAP_USED    : $INFO_SWAP_USED
	$LANG_DISK_USED    : $INFO_DISK_USED
	$LANG_UP_TIME    : $INFO_UPTIME
	$LANG_LOAD_AVERAGE    : $INFO_LOAD_AVERAGE
	$LANG_SERVER_TIME    : $INFO_SERVER_TIME
	EOF
	)
	string_by_columns "$INFO" "    " "+2" "ll"
}

this_update() {
	THIS_MD5_SERVER=$(c_curl -skL "$APP_BIN_URL" | md5sum - | awk '{print $1}')
	[ -z "$THIS_MD5_SERVER" ] && log_err "$LANG_FAIL_TO_GET md5" && return 1
	[ -f "$0" ] && {
		THIS_MD5_CURR=$(md5sum "$0" | awk '{print $1}')
		[ "$THIS_MD5_CURR" = "$THIS_MD5_SERVER" ] && log_date "$(string_with_args "$LANG_ALREADY_UP_TO_DATE" "$APP_NAME")" && return 1
	}
	c_curl -skL "$APP_BIN_URL" -o "$APP_CACHE_DIR/$APP_NAME" && {
		THIS_MD5_CACHE=$(md5sum "$APP_CACHE_DIR/$APP_NAME" | awk '{print $1}')
		[ -z "$THIS_MD5_CACHE" ] || [ -z "$THIS_MD5_SERVER" ] || {
			[ "$THIS_MD5_CACHE" = "$THIS_MD5_SERVER" ] || {
				log_err "$LANG_MD5_WAS_NOT_MATCH"
				return 1
			}
			[ -f "$0" ] && {
				[ "$0" = "$APP_BIN_PATH" ] || {
					cp -f "$APP_CACHE_DIR/$APP_NAME" "$0" && chmod +x "$0"
					return 0
				}
			}
			mkdir_p "$APP_ROOT"
			cp -f "$APP_CACHE_DIR/$APP_NAME" "$APP_ROOT/$APP_NAME" && chmod +x "$APP_ROOT/$APP_NAME" && ln -sf "$APP_ROOT/$APP_NAME" "$APP_BIN_PATH" && log_date "$(string_with_args "$LANG_HAS_BEEN_UPDATED" "$APP_NAME")" return 0
		}
	}
	return 1
}

this_install() {
	if [ -f "$0" ]; then
		[ "$0" = "$APP_BIN_PATH" ] || {
			mkdir_p "$APP_ROOT"
			cp -f "$0" "$APP_ROOT/$APP_NAME" && chmod +x "$APP_ROOT/$APP_NAME" && ln -sf "$APP_ROOT/$APP_NAME" "$APP_BIN_PATH" && return 0
		}
	else
		this_update && return 0
	fi
	return 1
}

show_help() {
	string_by_columns "$1" "    " "+2" "ll"
}

class_install() {
	if [ $# = 0 ]; then
		show_help "$(cat <<-EOF

		$0 install(i) PACKAGES
		PACKAGE    package name
		@PACKAGE    install by OS package manager
		PACKAGE:VERSION    specify package version
		eg. frp:0.48.0 nginx @aria2
		EOF
		)"
	else
		_INSTALL_PACKAGES_=""
		while [ $# -gt 0 ]
		do
			echo "$1" | grep -q '^@' && _INSTALL_PACKAGES_="$_INSTALL_PACKAGES_ $(echo "$1" | tr -d '@')" || install_package "$1"
			[ $? = 255 ] && _INSTALL_PACKAGES_="$_INSTALL_PACKAGES_ $1"
			shift
		done
		[ -z "$_INSTALL_PACKAGES_" ] || pkg_install "$_INSTALL_PACKAGES_"
	fi
}

class_remove() {
	_REMOVE_PACKAGES_="$(echo "$1" | grep -E "^[a-zA-Z0-9][-a-zA-Z0-9_]+" | head -n1 | grep -Eo "[a-zA-Z0-9][-a-zA-Z0-9_]+")"
	pkg_remove "$_REMOVE_PACKAGES_"
}

class_repo() {
	args_match "$@" "(--add|-a)" && {
		repo_add "$ARGS_MATCH_VALUE"
	}
	args_match "$@" "(--rm|-r)" && {
		repo_remove "$ARGS_MATCH_VALUE"
	}
}

class_build() {
	BUILD_PRESET="aria2|redis|rethinkdb|nginx|openresty|libluajit|libmaxminddb|libdrizzle|libsodium|rclone|tcping"
	BUILD_PACKAGE="$1"
	[ -z "$BUILD_PACKAGE" ] || {
		args_match "$@" "(--latest|-l)" && BUILD_LATEST="1"
		args_match "$@" "(--version|-v)" && BUILD_SHOW_VERSION_ONLY="1"
		echo "$BUILD_PACKAGE" | grep -Eq "^($BUILD_PRESET)$" && eval "build_$BUILD_PACKAGE" && return 0
	}
	show_help "$(cat <<-EOF

	$0 build(i) [package] [...options]
	* package
	$(echo "$BUILD_PRESET" | sed 's/|/ \/ /g')

	* option
	[--stable|-s]    Build stable version (Default)
	[--latest|-l]    Build latest version
	[--replace|-r]    Replace exist version
	[--version|-v]    Show version only
	EOF
	)"
}

class_bbr() {
	SYSCTL_TITLE="bbr"
	SYSCTL_DEC="$LANG_BBR_DEC"
	SYSCTL_KEY="net.ipv4.tcp_congestion_control"
	SYSCTL_VALUE="bbr"
	SYSCTL_OS_REQUIRE="ubuntu:12 debian:7 alpine:3.4 el:6 fc:6"
	SYSCTL_KERNEL_REQUIRE="4.9"
	SYSCTL_CONF_EXT=$(cat<<-EOF
	net.core.default_qdisc = fq
	EOF
	)
	class_sysctl "$1"
}

class_tfo() {
	SYSCTL_TITLE="tfo"
	SYSCTL_DEC="$LANG_TFO_DEC"
	SYSCTL_KEY="net.ipv4.tcp_fastopen"
	SYSCTL_VALUE="3"
	SYSCTL_OS_REQUIRE=""
	SYSCTL_KERNEL_REQUIRE="3.7"
	SYSCTL_CONF_EXT=""
	class_sysctl "$1"
}

class_sysctl() {
	[ -z "$SYSCTL_TITLE" ] && return 1
	[ -z "$SYSCTL_KEY" -o -z "$SYSCTL_VALUE" ] && return 1
	SYSCTL_TITLE_UPPER=$(echo "$SYSCTL_TITLE" | tr "[:lower:]" "[:upper:]")
	SYSCTL_FILE="$SYSCTL_ROOT/00-${SYSCTL_TITLE}.conf"
	SYSCTL_INFO=$(sysctl $SYSCTL_KEY)
	echo "$SYSCTL_INFO"
	[ -z "$SYSCTL_OS_REQUIRE" ] || {
		has_os_version "$SYSCTL_OS_REQUIRE" || {
			echo "$SYSCTL_TITLE_UPPER $LANG_OS_REQUIRE $SYSCTL_OS_REQUIRE ($OS_TYPE:$OS_VERSION)" && return 1
		}
	}
	[ -z "$SYSCTL_KERNEL_REQUIRE" ] || {
		require_kernel_version "$SYSCTL_KERNEL_REQUIRE" || {
			echo "$SYSCTL_TITLE_UPPER $LANG_REQUIRE_MIN_VERSION $SYSCTL_KERNEL_REQUIRE ($KERNEL_VERSION_INSTALLED)" && return 1
		}		
	}
	SYSCTL_STATUS="$(echo "$SYSCTL_INFO" | awk -F'=' '{gsub(" ","",$2); print $2}')"
	SYSCTL_MARK_BEGIN="#--- $SYSCTL_TITLE_UPPER BEGIN ---"
	SYSCTL_MARK_END="#--- $SYSCTL_TITLE_UPPER END ---"
	
	if [ "$SYSCTL_STATUS" = "$SYSCTL_VALUE" ]; then
		echo "$SYSCTL_TITLE_UPPER: $LANG_ENABLED"
		args_match "$@" "(--disable|-d)" && {
			sysctl_disable || return 1
		}
	else
		echo "$SYSCTL_TITLE_UPPER: $LANG_DISABLED"
		args_match "$@" "(--enable|-e)" && {
			sysctl_enable || return 1
		}
	fi
	show_help "$(cat <<-EOF

	$APP_NAME $SYSCTL_TITLE [option]
	[--enable|-e]    $LANG_ENABLE $SYSCTL_DEC
	[--disable|-d]    $LANG_DISABLE $SYSCTL_DEC
	EOF
	)"
}

class_kernel() {
	case "$1" in
		"update"|"u")
			kernel_update
			return $?
			;;
		"build"|"b")
			kernel_build
			return $?
			;;
		"remote"|"r")
			kernel_remote
			return $?
			;;
	esac
	echo "$LANG_KERNEL_VERSION: $KERNEL_VERSION_INSTALLED"
	cat <<-EOF

	$APP_NAME kernel [option]
	[--update|-u]    $LANG_HELP_KERNEL_UPDATE_TO_LATEST
	EOF
}

class_firewall() {
	if args_match "$@" "(--flush|-F)"; then
		sudo iptables -P INPUT ACCEPT
		sudo iptables -P FORWARD ACCEPT
		sudo iptables -P OUTPUT ACCEPT
		sudo iptables -F
	elif args_match "$@" "(--list|-L)"; then
		iptables -L -n
	elif args_match "$@" "(--disable|-D)"; then
		# pkg_remove netfilter-persistent
		[ -d "/etc/iptables" ] && mv /etc/iptables /etc/iptables.disabled
		# reboot
	elif args_match "$@" "(--enable|-E)"; then
		# pkg_remove netfilter-persistent
		[ -d "/etc/iptables.disabled" ] && mv /etc/iptables.disabled /etc/iptables
		# reboot
	elif args_match "$@" "(--accept|-A)"; then
		while read __PORT__
		do
			[ -z "$__PORT__" ] || iptables -I INPUT -p tcp --dport $__PORT__ -j ACCEPT
		done <<-EOF
		$(echo "$ARGS_MATCH_VALUE" | tr ',' '\n')
		EOF
	fi
}

class_random() {
	random_string "$@" || show_help "$(cat <<-EOF

	$0 random(rand) [options]
	* options
	[--length|-l]    $LANG_RANDOM_LENGTH
	[--digit|-D]    $LANG_RANDOM_DIGIT
	[--upper|-U]    $LANG_RANDOM_UPPER
	[--lower|-L]    $LANG_RANDOM_LOWER
	[--symbol|-S]    $LANG_RANDOM_SYMBOL
	[--only-with|-o]    $LANG_RANDOM_ONLY_WITH

	e.g.
	$APP_NAME rand -l 16 -U -L
	$APP_NAME rand -l 8 "abAB12"
	EOF
	)"
	return 1
}

class_date() {
	case "$1" in
		"human"|"h")
			echo "$2" | awk '{
				if ($0 >= 0) {
					D=$0/86400; H=$0/3600; M=$0/60; S=$0; OUT=""
					if (D>1) {gsub(/\.[0-9]+/,"",D); H=($0%86400)/3600; OUT=D"d"}
					if (H>1) {gsub(/\.[0-9]+/,"",H); M=($0%3600)/60; OUT=OUT", "H"h"}
					if (M>1) {gsub(/\.[0-9]+/,"",M); S=($0%60); OUT=OUT", "M"m"}
					OUT=OUT", "S"s";
					gsub(/^,\s*/,"",OUT);
				}
			} END{print OUT}'
			;;
		"timezone"|"tz")
			timedatectl set-timezones Asia/Shanghai
			timedatectl list-timezones
			;;
	esac
}

class_inotify() {
	[ -z "$(ls /proc/sys/fs/inotify/)" ] && return 1
	require_pkg "inotify-tools"
	inotifywait -mrq --timefmt '%y/%m/%d %H:%M' --format  '%T %w%f %e' --event delete,modify,create,attrib  /data/web | while read  date time file event
	do
		case $event in
			MODIFY|CREATE|MOVE|MODIFY,ISDIR|CREATE,ISDIR|MODIFY,ISDIR)
			echo $event'-'$file'-'$date'-'$time >> /var/log/web_watch.log
			;;
			MOVED_FROM|MOVED_FROM,ISDIR|DELETE|DELETE,ISDIR)
			echo $event'-'$file'-'$date'-'$time /var/log/web_watch.log
			;;
		esac
	done
}

class_logout() {
	# https://fostips.com/log-out-command-linux-desktops/
	# KDE Plasma
	qdbus org.kde.ksmserver /KSMServer logout 0 0 0
	echo ""
}

class_frp() {
	args_match "$@" "(--server|-s)"; FRP_SERVER="$ARGS_MATCH_VALUE"
	args_match "$@" "(--token|-T)"; FRP_TOKEN="$ARGS_MATCH_VALUE"
	args_match "$@" "(--version|-v)"; FRP_VERSION="$ARGS_MATCH_VALUE"
	[ -z "$FRP_VERSION"] && FRP_VERSION=$(ls "$FRP_ROOT" | head -n1 | awk '{gsub(/^[a-zA-Z]+/,"",$0); print $0}')
	[ -d "$FRP_ROOT/v$FRP_VERSION" ] && FRP_DIR="$FRP_ROOT/v$FRP_VERSION"
	case "$1" in
		"client")
			[ -x "$FRP_DIR/frpc" ] && FRP_CLIENT_BIN="$FRP_DIR/frpc"
			args_match "$@" "(--local|-l)"; FRP_LOCAL="$ARGS_MATCH_VALUE"
			args_match "$@" "(--remote-port|-p)"; FRP_REMOTE_PORT="$ARGS_MATCH_VALUE"
			args_match "$@" "(--type|-t)"; FRP_TYPE="$ARGS_MATCH_VALUE"
			frp_client_add
			;;
		"server")
			[ -x "$FRP_DIR/frps" ] && FRP_SERVER_BIN="$FRP_DIR/frps"
			frp_server_add
			;;
		"install")
			install_frp
			;;
		"version")
			frp_version
			;;
		"delete"|"del")
			frp_remove
			;;
		"list"|"ls")
			frp_list
			;;
	esac
	_CODE_="$?"
	# echo "CODE: $_CODE_"
	# return $_CODE_
	[ "$_CODE_" = "0" ] || show_help "$(cat <<-EOF

	$0 [client / server / install / version / delete(del) / list(ls)] [options]
	* options
	[--server|-s]    server (eg. frphost:7000)
	[--token|-T]    server token
	[--local|-l]    local service (eg. 127.0.0.1:8080)
	[--remote-port|-p]    remote port (eg. 8080, 8080+, 8080-8090)
	    default: same as local service port
	[--type|-t]    type (eg. tcp)
	[--version|-v]    specify a frp version to run
	EOF
	)"
	return $_CODE_
}

class_nfs() {
	if args_match "$@" "(--install|-i)"; then
		nfs_install
	elif args_match "$@" "(--add-share|-a)"; then
		nfs_add_share
	elif args_match "$@" "(--mount|-m)"; then
		nfs_mount
	elif args_match "$@" "(--list|-l)"; then
		nfs_list
	elif args_match "$@" "(--remove|-r)"; then
		nfs_remove
	fi
	show_help "$(cat <<-EOF

	$APP_NAME nfs [action] [option]
	* action
	[--install|-i]    
	[--add-share|-a]    
	[--mount|-m]    
	[--list|-l]    
	[--remove|-r]    
	EOF
	)"
}

class_aria2() {
	if args_match "$@" "(--bt-tracker|-b)"; then
		aria2_bt_tracker && aria2_restart
	fi
}

class_geoip() {
	GEOIP_ROOT="$WWW_ROOT/geoip"
	GEOIP_VERSION_FILE="$GEOIP_ROOT/version.txt"
	GEOIP_DB_CITY_LITE_NAME="dbip-city-lite"
	GEOIP_DB_CITY="$GEOIP_ROOT/GeoLite2-City.mmdb"
	# [ -f "$GEOIP_ROOT/${GEOIP_DB_CITY_LITE_NAME}.mmdb" ] && GEOIP_DB_CITY="$GEOIP_ROOT/${GEOIP_DB_CITY_LITE_NAME}.mmdb"
	GEOIP_DB_COUNTRY="$GEOIP_ROOT/GeoLite2-Country.mmdb"
	GEOIP_DB_ASN="$GEOIP_ROOT/GeoLite2-ASN.mmdb"
	case "$1" in
		"china")
			c_curl -skL 'http://ftp.apnic.net/apnic/stats/apnic/delegated-apnic-latest' | grep 'ipv4' | grep 'CN' | awk -F'|' '{ printf("%s/%d\n", $4, 32-log($5)/log(2)) }'
			;;
		"update")
			geoip_update "$@"
			;;
		"version"|"ver")
			cat <<-EOF
			$(cat "$GEOIP_VERSION_FILE" 2>/dev/null)
			EOF
			;;
		"help")
			show_help "$(cat <<-EOF
			[IP/AS] [options]    Query with IP Address / AS No. (eg. AS13335) 
			    --format(-f) [raw, json(default)]
			update    Update IP DB
			version|ver    Show DB version
			help    show this
			EOF
			)"
			;;
		*)
			args_match "$@" "(--format|-f)" && GEOIP_OUTPUT_FORMAT="$ARGS_MATCH_VALUE"
			while true
			do
				[ "$#" = "0" ] && break
				GEOIP_QUERY_IP=$(echo "$1" | grep -Eoi "^(as[0-9]+|[0-9]{1,3}(\.[0-9]{1,3}){3})$")
				[ -z "$GEOIP_QUERY_IP" ] || break
				shift
			done
			[ -z "$GEOIP_QUERY_IP" ] && get_external_ip && GEOIP_QUERY_IP="$EXTERNAL_IP"
			geoip_query "$GEOIP_QUERY_IP"
			;;
	esac
}

class_proxy() {
	PROXY_ROOT_DIR="$APP_CACHE_DIR/proxy"
	[ -d "$PROXY_ROOT_DIR" ] && mkdir -p "$PROXY_ROOT_DIR"
	case "$1" in
		"update"|"up")
			[ -f "$PROXY_ROOT_DIR/start.sh" ] || {
				github_download_branch "monosans/proxy-scraper-checker" "" --unzip "$PROXY_ROOT_DIR" || return 1
			}
			sh -c "cd $PROXY_ROOT_DIR && sh start.sh"
			;;
	esac
}

class_warp() {
	__CACHE_DIR__="$APP_CACHE_DIR/warp"
	case "$1" in
		"ip")
			cloudflare_warp_get_ip_ranges "$@"
			;;
		"best")
			cloudflare_warp_get_best_ips "$@"
			;;
		"register"|"reg")
			cloudflare_warp_warpgo_register "$@"
			;;
		"conf")
			cloudflare_warp_warpgo_conf "$@"
			;;
		"wireguard"|"wg")
			cloudflare_warp_warpgo_wireguard "$@"
			;;
		"plus"|"+")
			cloudflare_warp_plus "$@"
			# cloudflare_warp_plus_register
			;;
		"docker")
			cloudflare_warp_wgcf_docker "$@"
			;;
		*)
			show_help "$(cat <<-EOF
			$0 warp(wp) [command] [options]
			* command
			register(reg)    register warp / team account
			wireguard(wg)    export wireguard configuration
			* options
			--config(-c) CONFIG_PATH
			--device-name(-n) DEVICE_NAME    default: hostname
			--device-id(-d) DEVICE_ID
			--team(-t) TEAM_NAME    team name (Cloudflare Zero Trust)
			--email(-e) EMAIL    email for receiving code
			--license(-l) WARP_PLUS_LICENSE    Register for WARP and upgrade to WARP+
			EOF
			)"
			;;
	esac
}

class_cloudflare() {
	case "$1" in
		"ip")
			cloudflare_get_ip_ranges
			;;
		"trace")
			c_curl -skL "https://cloudflare.com/cdn-cgi/trace"
			;;
	esac
}

class_lxc() {
	#https://linuxcontainers.org/lxc/manpages/

	# Creates a /dev/video0 device in container p1 based on the matching device on the host.
	lxc-device -n p1 add /dev/video0
	# Moves eth0 from the host as eth1 in p1.
	lxc-device -n p1 add eth0 eth1
}

class_baloo_file() {
	case "$1" in
		"disable")
			mv /usr/bin/baloo_file_extractor /usr/bin/baloo_file_extractor.bak
			ln -s /bin/true /usr/bin/baloo_file_extractor
			mv /usr/bin/baloo_file /usr/bin/baloo_file.bak
			ln -s /bin/true /usr/bin/baloo_file
			;;
		"enable")
			mv /usr/bin/baloo_file_extractor.bak /usr/bin/baloo_file_extractor
			mv /usr/bin/baloo_file.bak /usr/bin/baloo_file
			;;
	esac
}

class_send() {
	args_match "$@" "(--provider|-p)" && SEND_PROVIDER="$ARGS_MATCH_VALUE"
	SEND_PROVIDER=${SEND_PROVIDER:-wecom}
	case "$SEND_PROVIDER" in
		"wecom")
			send_to_wecom "$@"
			;;
	esac
}

class_image() {
	has_package "imagemagick" || {
		log_err "$(string_with_args "$LANG_HAVE_TO_INSTALL_APP_FIRST" "imagemagick")"
		return 1
	}
	case "$1" in
		"pick")
			image_pick_color "$@"
			;;
	esac
}

class_speedtest() {
	has_package "speedtest-cli" || {
		log_err "$(string_with_args "$LANG_HAVE_TO_INSTALL_APP_FIRST" "speedtest")"
		return 1
	}
	SPEEDTEST_TIMEOUT="5"
	SPEEDTEST_OPTION="--timeout $SPEEDTEST_TIMEOUT --simple"
	args_match "$@" "(--json|-j)" && SPEEDTEST_JSON="1"
	args_match "$@" "(--country|-C)" && SPEEDTEST_COUNTRY="$ARGS_MATCH_VALUE"
	args_match "$@" "(--city|-c)" && SPEEDTEST_CITY="$ARGS_MATCH_VALUE"
	args_match "$@" "(--isp|-i)" && SPEEDTEST_ISP="$ARGS_MATCH_VALUE"
	args_match "$@" "(--id|-d)" && SPEEDTEST_ID="$ARGS_MATCH_VALUE"
	if args_match "$@" "(--list|-l)"; then
		speedtest_list
	elif args_match "$@" "(--test|-t)"; then
		args_match "$@" "(--download|-d)" && SPEEDTEST_DOWNLOAD="1"
		args_match "$@" "(--upload|-u)" && SPEEDTEST_UPLOAD="1"
		if [ "$SPEEDTEST_DOWNLOAD" = "1" -a "$SPEEDTEST_UPLOAD" = "1" ]; then
			SPEEDTEST_OPTION=$SPEEDTEST_OPTION
		elif [ "$SPEEDTEST_DOWNLOAD" = "1" ]; then
			SPEEDTEST_OPTION="$SPEEDTEST_OPTION --no-upload"
		elif [ "$SPEEDTEST_UPLOAD" = "1" ]; then
			SPEEDTEST_OPTION="$SPEEDTEST_OPTION --no-download"
		fi
		args_match "$@" "(--https|-h)" && SPEEDTEST_OPTION="$SPEEDTEST_OPTION --secure"
		args_match "$@" "(--single|-s)" && SPEEDTEST_OPTION="$SPEEDTEST_OPTION --single"
		speedtest_test
	else
		show_help "$(cat <<-EOF

		$APP_NAME speedtest [action] [option] [option...
		* action
		[--test|-t]    $LANG_SPEEDTEST_TEST
		[--list|-l]    $LANG_SPEEDTEST_LIST

		* option
		[--country|-C]    $LANG_SPEEDTEST_MATCH_COUNTRY
		[--city|-c]    $LANG_SPEEDTEST_MATCH_CITY
		[--isp|-i]    $LANG_SPEEDTEST_MATCH_ISP
		[--id|-d]    $LANG_SPEEDTEST_MATCH_ID
		[--download|-d]    $LANG_SPEEDTEST_DOWNLOAD_ONLY
		[--upload|-u]    $LANG_SPEEDTEST_UPLOAD_ONLY
		[--single|-s]    $LANG_SPEEDTEST_SINGLE
		[--https|-h]    $LANG_SPEEDTEST_HTTPS
		[--json|-j]    $LANG_OUTPUT_AS_JSON
		EOF
		)"
	fi
}

class_disktest() {
	DISKTEST_FILE=~/disktest
	args_match "$@" "(--memory|-m)" && {
		DISKTEST_MEM="1"
	}
	args_match "$@" "(--size|-s)" && {
		DISKTEST_SIZE="$ARGS_MATCH_VALUE"
	}
	disktest_test "$DISKTEST_SIZE" && return 0
	show_help "$(
		cat<<-EOF

		$APP_NAME disktest [option]

		* option
		[--size|-s]    $LANG_DISKTEST_SIZE
		[--memory|-m]    $LANG_DISKTEST_MEMORY
		EOF
	)"
}

class_info() {
	_CODE_="0"
	args_match "$@" "(--field|-f)" && {
		case "$ARGS_MATCH_VALUE" in
			"cpu")
				info_cpu; return 0
				;;
			"disk")
				info_disk; return 0
				;;
			"hardware")
				info_hardware; return 0
				;;
			"kallsyms")
				info_kallsyms; return 0
				;;
			*)
				_CODE_="255"
				;;
		esac
	}
	args_match "$@" "(--help|-h)" && _CODE_="255"
	[ "$_CODE_" = 255 ] && 	show_help "$(cat<<-EOF

		$0 info [options]
		* options
		[--field|-f]    field [cpu / disk]
		EOF
	)" && return 0
	info_all
}

class_tmux() {
	tmux_api "$@"
}

class_github() {
	case "$1" in
		"action"|"a")
			shift
			github_action_api "$@"
			;;
		*)
			show_help "$(cat <<-EOF
			$0 github action help
			EOF
			)"
	esac
}

class_config() {
	config_set "$@"
}

class_this() {
	if args_match "$@" "(--update|-u)"; then
		this_update
	elif args_match "$@" "(--install|-i)"; then
		this_install
	else
		show_help "$(cat <<-EOF

		$APP_NAME this [action]
		* action
		[--update|-u]    $LANG_HELP_THIS_UPDATE
		[--install|-i]    $LANG_HELP_THIS_INSTALL
		EOF
		)"
	fi
}

class_end() {
	[ "$REBOOT" = "1" ] && {
		input_yes_no "REBOOT" "$LANG_CONFIRM_REBOOT_NOW ?" "y"
		[ "$REBOOT" = "1" ] && reboot && exit 0
	}
	[ "$SUPERVISOR_RELOAD" = "1" ] && supervisor_reload &>/dev/null
	[ "$NGINX_RESTART" = "1" ] && nginx_reload &>/dev/null
}

class_help() {
	show_help "$(cat <<-EOF
	================================================================
	$APP_NAME Version $APP_VERSION
	Usage: ${APP_NAME} [action] [--option=value] [-option value...

	[action]
	install    Install packages
	remove    Remove packages
	build    Build package
	bbr    Enable Google TCP BBR
	tfo    Enable TCP Fast Open
	kernel    Linux Kernel update
	frp    Fast Reverse Proxy
	geoip    Find the location of an IP address
	speedtest    Network speed test
	random    Generate a random string
	info    Show info
	config    Config
	this    Install / Update $APP_NAME

	* help for an action, just type: $APP_NAME [action]
	----------------------------------------------------------------
	- $APP_NAME_FULL by leen
	- Website $APP_URL
	EOF
	)"
	return 0
}

# is_root
get_os_info || exit 1
define_pkg
init_config
lang
[ -z "$1" ] || {
	ACTION="$1"
	shift
}
case "$ACTION" in
	"install"|"i")
		class_install "$@"
		;;
	"remove"|"rm")
		class_remove "$@"
		;;
	"repo"|"r")
		class_repo "$@"
		;;
	"build"|"b")
		class_build "$@"
		;;
	"bbr")
		class_bbr "$@"
		;;
	"tfo")
		class_tfo "$@"
		;;
	"kernel")
		class_kernel "$@"
		;;
	"firewall"|"fw")
		class_firewall "$@"
		;;
	"frp")
		class_frp "$@"
		;;
	"nfs")
		class_nfs "$@"
		;;
	"aria2")
		class_aria2 "$@"
		;;
	"send")
		class_send "$@"
		;;
	"image")
		class_image "$@"
		;;
	"geoip")
		class_geoip "$@"
		;;
	"proxy")
		class_proxy "$@"
		;;
	"cloudflare"|"cf")
		class_cloudflare "$@"
		;;
	"warp"|"wp")
		class_warp "$@"
		;;
	"speedtest")
		class_speedtest "$@"
		;;
	"disktest")
		class_disktest "$@"
		;;
	"random"|"rand")
		class_random "$@"
		;;
	"date")
		class_date "$@"
		;;
	"logout")
		class_logout "$@"
		;;
	"tmux")
		class_tmux "$@"
		;;
	"github"|"git")
		class_github "$@"
		;;
	"info")
		class_info "$@"
		;;
	"config")
		class_config "$@"
		;;
	"this")
		class_this "$@"
		;;
	"test"|"t")
		ping_by_itdog "$@"
		;;
	*)
		class_help
		;;
esac
class_end
